<?php
/**
 * Plugin Name:       TFSC Server Location Test Probe
 * Description:       Authenticated, allowlisted website probes executed from this WordPress server.
 * Version:           0.1.2
 * Update URI:        https://github.com/TheFieldServiceCompany/server-location-test-probe-wordpress
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Rudi van Lieshout
 * License:           GPL-2.0-or-later
 * Text Domain:       server-location-test-probe
 */

defined( 'ABSPATH' ) || exit;

define( 'SLTP_VERSION', '0.1.2' );
define( 'SLTP_FILE', __FILE__ );
define( 'SLTP_DIR', plugin_dir_path( __FILE__ ) );

require_once SLTP_DIR . 'includes/class-sltp-plugin.php';
require_once SLTP_DIR . 'includes/class-sltp-request-budget.php';
require_once SLTP_DIR . 'includes/class-sltp-probe.php';
require_once SLTP_DIR . 'includes/class-sltp-rest.php';
require_once SLTP_DIR . 'includes/class-sltp-admin.php';

register_activation_hook( __FILE__, array( 'SLTP_Plugin', 'activate' ) );
add_action( 'plugins_loaded', array( 'SLTP_Plugin', 'instance' ) );
