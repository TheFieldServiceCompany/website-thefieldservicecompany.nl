<?php
defined( 'ABSPATH' ) || exit;

/** Short database lock makes transient budget increments atomic across workers. */
final class SLTP_Request_Budget {
 const LOCK = '_sltp_budget_lock';
 public static function payload_allowed( $value, $maximum = 65536 ) {
  $stack = [ [ $value, 0 ] ]; $bytes = 0; $items = 0;
  while ( $stack ) {
   [ $part, $depth ] = array_pop( $stack );
   if ( ++$items > 1000 || $depth > 16 ) { return false; }
   if ( is_array( $part ) ) {
    foreach ( $part as $key => $child ) {
     $bytes += strlen( (string) $key ) + 8;
     if ( $bytes > $maximum || count( $stack ) > 1000 ) { return false; }
     $stack[] = [ $child, $depth + 1 ];
    }
   } elseif ( is_scalar( $part ) || null === $part ) { $bytes += strlen( (string) $part ) + 4; }
   else { return false; }
   if ( $bytes > $maximum ) { return false; }
  }
  return true;
 }
 public static function consume( $identity, $limit, $window, $global_limit = 30 ) {
  global $wpdb;
  $lock = wp_json_encode( [ 'token' => wp_generate_uuid4(), 'at' => time() ] );
  // add_option uses an upsert in core; INSERT IGNORE must choose one owner.
  $acquire = function () use ( $wpdb, $lock ) {
   return 1 === (int) $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')", self::LOCK, $lock ) );
  };
  if ( ! $acquire() ) {
   $old = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name=%s", self::LOCK ) );
   $decoded = json_decode( (string) $old, true );
   if ( ! is_array( $decoded ) || (int) ( $decoded['at'] ?? 0 ) >= time() - 30 ) { return false; }
   $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", self::LOCK, $old ) );
   wp_cache_delete( self::LOCK, 'options' ); wp_cache_delete( 'notoptions', 'options' );
   if ( ! $acquire() ) { return false; }
  }
  try {
   $window = max( 1, (int) $window ); $bucket = (int) floor( time() / $window );
   $keys = [ 'sltp_budget_' . hash( 'sha256', (string) $identity ) => max( 1, (int) $limit ), 'sltp_budget_global' => max( 1, (int) $global_limit ) ];
   $counts = [];
   foreach ( $keys as $key => $cap ) {
    $state = get_transient( $key );
    $counts[$key] = is_array( $state ) && ( $state['bucket'] ?? null ) === $bucket ? (int) $state['count'] : 0;
    if ( $counts[$key] >= $cap ) { return false; }
   }
   foreach ( $counts as $key => $count ) { set_transient( $key, [ 'bucket' => $bucket, 'count' => $count + 1 ], $window ); }
   return true;
  } finally {
   $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", self::LOCK, $lock ) );
   wp_cache_delete( self::LOCK, 'options' ); wp_cache_delete( 'notoptions', 'options' );
  }
 }
}
