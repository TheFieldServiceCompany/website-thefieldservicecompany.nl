<?php

defined( 'ABSPATH' ) || exit;

final class SLTP_Probe {
	const MAX_REDIRECTS = 3;
	const MAX_BYTES = 2097152;
	const MAX_SECONDS = 20;

	private $allowed_hosts;
	private $budget_active = false;
	private $deadline = 0.0;
	private $remaining_bytes = 0;
	private $budget_error = '';

	public function __construct( $allowed_hosts = null ) {
		$this->allowed_hosts = null === $allowed_hosts ? SLTP_Plugin::get_allowed_hosts() : SLTP_Plugin::sanitize_hosts( $allowed_hosts );
	}

	public function probe( $url, $method = 'GET' ) {
		$owner = ! $this->budget_active;
		if ( $owner ) { $this->begin_budget(); }
		try { return $this->perform_probe( $url, $method ); }
		finally { if ( $owner ) { $this->budget_active = false; } }
	}

	private function begin_budget() {
		$this->budget_active = true;
		$this->deadline = microtime( true ) + self::MAX_SECONDS;
		$this->remaining_bytes = self::MAX_BYTES;
		$this->budget_error = '';
	}

	private function accept_chunk( $data ) {
		if ( microtime( true ) >= $this->deadline ) { $this->budget_error = 'work_budget_exceeded'; return 0; }
		$length = strlen( $data );
		if ( $length > $this->remaining_bytes ) { $this->budget_error = 'response_too_large'; return 0; }
		$this->remaining_bytes -= $length;
		return $length;
	}

	private function perform_probe( $url, $method ) {
		$method      = 'HEAD' === strtoupper( (string) $method ) ? 'HEAD' : 'GET';
		$current_url = $this->validate_url( $url );
		if ( is_wp_error( $current_url ) ) {
			return $current_url;
		}

		$started = microtime( true );
		$hops    = array();

		for ( $redirects = 0; $redirects <= self::MAX_REDIRECTS; $redirects++ ) {
			$result = $this->request_once( $current_url, $method );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			$hops[] = array(
				'url'        => $current_url,
				'status'     => $result['status'],
				'primary_ip' => $result['primary_ip'],
			);

			if ( $result['status'] < 300 || $result['status'] >= 400 || empty( $result['headers']['location'] ) ) {
				$result['url']              = $current_url;
				$result['redirects']        = $hops;
				$result['total_elapsed_ms'] = (int) round( ( microtime( true ) - $started ) * 1000 );
				return $result;
			}

			$next = WP_Http::make_absolute_url( $result['headers']['location'], $current_url );
			$next = $this->validate_url( $next );
			if ( is_wp_error( $next ) ) {
				return new WP_Error( 'unsafe_redirect', 'Redirectdoel geweigerd: ' . $next->get_error_message() );
			}

			$current_url = $next;
		}

		return new WP_Error( 'too_many_redirects', 'Meer dan drie redirects zijn geweigerd.' );
	}

	public function probe_sequence( $url, $attempts = 2, $delay_ms = 500 ) {
		$this->begin_budget();
		try { return $this->perform_sequence( $url, $attempts, $delay_ms ); }
		finally { $this->budget_active = false; }
	}

	private function perform_sequence( $url, $attempts, $delay_ms ) {
		$attempts = min( 3, max( 2, absint( $attempts ) ) );
		$delay_ms = min( 2000, max( 0, absint( $delay_ms ) ) );
		$results  = array();

		for ( $i = 0; $i < $attempts; $i++ ) {
			$result = $this->probe( $url, 'GET' );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$results[] = $result;
			if ( $i + 1 < $attempts && $delay_ms > 0 ) {
				usleep( $delay_ms * 1000 );
			}
		}

		return array(
			'attempts' => $results,
			'summary'  => $this->summarize_sequence( $results ),
		);
	}

	public function validate_url( $url ) {
		$url = esc_url_raw( trim( (string) $url ), array( 'https' ) );
		if ( ! $url ) {
			return new WP_Error( 'invalid_url', 'Alleen een geldige HTTPS-URL is toegestaan.' );
		}

		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || 'https' !== strtolower( (string) ( $parts['scheme'] ?? '' ) ) || empty( $parts['host'] ) ) {
			return new WP_Error( 'invalid_url', 'Alleen een geldige HTTPS-URL is toegestaan.' );
		}

		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) || ( isset( $parts['port'] ) && 443 !== (int) $parts['port'] ) ) {
			return new WP_Error( 'unsafe_url', 'Inloggegevens en afwijkende poorten zijn niet toegestaan.' );
		}

		$host = SLTP_Plugin::normalize_host( $parts['host'] );
		if ( ! $host || ! in_array( $host, $this->allowed_hosts, true ) ) {
			return new WP_Error( 'host_not_allowed', 'Dit domein staat niet op de allowlist.' );
		}

		$ips = $this->resolve_public_ips( $host );
		if ( is_wp_error( $ips ) ) {
			return $ips;
		}

		$path  = isset( $parts['path'] ) ? '/' . ltrim( $parts['path'], '/' ) : '/';
		$query = isset( $parts['query'] ) && '' !== $parts['query'] ? '?' . $parts['query'] : '';
		return 'https://' . $host . $path . $query;
	}

	private function request_once( $url, $method ) {
		if ( microtime( true ) >= $this->deadline ) { return new WP_Error( 'work_budget_exceeded', 'Het totale tijdsbudget van de probe is bereikt.' ); }
		if ( ! function_exists( 'curl_init' ) ) {
			return new WP_Error( 'curl_unavailable', 'De PHP cURL-extensie ontbreekt.' );
		}

		$parts = wp_parse_url( $url );
		$host  = strtolower( (string) $parts['host'] );
		$ips   = $this->resolve_public_ips( $host );
		if ( is_wp_error( $ips ) ) {
			return $ips;
		}
		$remaining_ms = (int) floor( ( $this->deadline - microtime( true ) ) * 1000 );
		if ( $remaining_ms < 1 ) { return new WP_Error( 'work_budget_exceeded', 'Het totale tijdsbudget van de probe is bereikt.' ); }

		$resolved_ip = $ips[0];
		$resolve_ip  = false !== strpos( $resolved_ip, ':' ) ? '[' . $resolved_ip . ']' : $resolved_ip;
		$headers     = array();
		$downloaded  = 0;
		$curl        = curl_init();

		if ( false === $curl ) {
			return new WP_Error( 'curl_init_failed', 'cURL kon niet worden gestart.' );
		}

		curl_setopt( $curl, CURLOPT_URL, $url );
		curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, false );
		curl_setopt( $curl, CURLOPT_CONNECTTIMEOUT_MS, min( 5000, $remaining_ms ) );
		curl_setopt( $curl, CURLOPT_TIMEOUT_MS, $remaining_ms );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, true );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 2 );
		curl_setopt( $curl, CURLOPT_ENCODING, '' );
		curl_setopt( $curl, CURLOPT_USERAGENT, 'TFSC-NL-Location-Probe/' . SLTP_VERSION );
		curl_setopt( $curl, CURLOPT_HTTPHEADER, array( 'Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.5' ) );
		curl_setopt( $curl, CURLOPT_RESOLVE, array( $host . ':443:' . $resolve_ip ) );

		if ( 'HEAD' === $method ) {
			curl_setopt( $curl, CURLOPT_NOBODY, true );
		}

		curl_setopt(
			$curl,
			CURLOPT_WRITEFUNCTION,
			function ( $handle, $data ) use ( &$downloaded ) {
				$accepted = $this->accept_chunk( $data );
				$downloaded += $accepted;
				return $accepted;
			}
		);

		curl_setopt(
			$curl,
			CURLOPT_HEADERFUNCTION,
			function ( $handle, $line ) use ( &$headers ) {
				$length = strlen( $line );
				if ( 0 === stripos( $line, 'HTTP/' ) ) {
					$headers = array();
					return $length;
				}

				$separator = strpos( $line, ':' );
				if ( false !== $separator ) {
					$name    = strtolower( trim( substr( $line, 0, $separator ) ) );
					$allowed = array( 'location', 'server', 'cache-control', 'age', 'content-type', 'content-length', 'x-qc-cache', 'x-qc-pop', 'x-litespeed-cache', 'cf-cache-status', 'cf-ray' );
					if ( in_array( $name, $allowed, true ) ) {
						$headers[ $name ] = substr( trim( substr( $line, $separator + 1 ) ), 0, 2048 );
					}
				}

				return $length;
			}
		);

		if ( defined( 'CURLOPT_PROTOCOLS' ) && defined( 'CURLPROTO_HTTPS' ) ) {
			curl_setopt( $curl, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS );
			curl_setopt( $curl, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS );
		}

		$success = curl_exec( $curl );
		$status  = (int) curl_getinfo( $curl, CURLINFO_RESPONSE_CODE );
		$error   = false === $success ? curl_error( $curl ) : '';
		$result  = array(
			'ok'             => false !== $success,
			'method'         => $method,
			'status'         => $status,
			'headers'        => $headers,
			'primary_ip'     => (string) curl_getinfo( $curl, CURLINFO_PRIMARY_IP ),
			'download_bytes' => $downloaded,
			'timing_ms'       => array(
				'dns'     => (int) round( curl_getinfo( $curl, CURLINFO_NAMELOOKUP_TIME ) * 1000 ),
				'connect' => (int) round( curl_getinfo( $curl, CURLINFO_CONNECT_TIME ) * 1000 ),
				'tls'     => (int) round( curl_getinfo( $curl, CURLINFO_APPCONNECT_TIME ) * 1000 ),
				'first_byte' => (int) round( curl_getinfo( $curl, CURLINFO_STARTTRANSFER_TIME ) * 1000 ),
				'total'   => (int) round( curl_getinfo( $curl, CURLINFO_TOTAL_TIME ) * 1000 ),
			),
		);
		curl_close( $curl );

		if ( $this->budget_error ) {
			return new WP_Error( $this->budget_error, 'Het byte- of tijdsbudget van de probe is bereikt.' );
		}
		if ( false === $success ) {
			return new WP_Error( 'request_failed', $error ? $error : 'De aanvraag is mislukt.' );
		}

		return $result;
	}

	private function resolve_public_ips( $host ) {
		$records = dns_get_record( $host, DNS_A | DNS_AAAA );
		$ips     = array();

		foreach ( is_array( $records ) ? $records : array() as $record ) {
			$ip = isset( $record['ip'] ) ? $record['ip'] : ( $record['ipv6'] ?? '' );
			if ( $ip ) {
				$ips[] = $ip;
			}
		}

		$ips = array_values( array_unique( $ips ) );
		if ( ! $ips ) {
			return new WP_Error( 'dns_failed', 'Het domein heeft geen bruikbaar A- of AAAA-record.' );
		}

		$flags = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
		foreach ( $ips as $ip ) {
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP, $flags ) ) {
				return new WP_Error( 'unsafe_dns', 'Het domein verwijst naar een privé- of gereserveerd IP-adres.' );
			}
		}

		return $ips;
	}

	private function summarize_sequence( $results ) {
		$states = array();
		$pops   = array();
		foreach ( $results as $result ) {
			$headers  = $result['headers'];
			$states[] = $headers['x-qc-cache'] ?? ( $headers['cf-cache-status'] ?? ( $headers['x-litespeed-cache'] ?? 'unknown' ) );
			if ( ! empty( $headers['x-qc-pop'] ) ) {
				$pops[] = $headers['x-qc-pop'];
			}
		}

		return array(
			'cache_states' => $states,
			'pops'         => array_values( array_unique( $pops ) ),
			'warmed'       => count( $states ) >= 2 && 'hit' === strtolower( (string) end( $states ) ),
		);
	}
}
