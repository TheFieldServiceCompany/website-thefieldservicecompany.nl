<?php

defined( 'ABSPATH' ) || exit;

final class SLTP_Admin {
	const PAGE = 'server-location-test-probe';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_sltp_save_hosts', array( $this, 'save_hosts' ) );
		add_action( 'admin_post_sltp_generate_token', array( $this, 'generate_token' ) );
	}

	public function menu() {
		add_management_page( 'TFSC Location Test Probe', 'TFSC Location Test Probe', 'manage_options', self::PAGE, array( $this, 'render' ) );
	}

	public function save_hosts() {
		$this->authorize( 'sltp_save_hosts' );
		$hosts = SLTP_Plugin::sanitize_hosts( wp_unslash( $_POST['hosts'] ?? '' ) );
		update_option( SLTP_Plugin::OPTION_HOSTS, $hosts, false );
		$this->redirect( 'Allowlist opgeslagen.' );
	}

	public function generate_token() {
		$this->authorize( 'sltp_generate_token' );
		$token = SLTP_Plugin::generate_token();
		set_transient( SLTP_Plugin::TOKEN_TRANSIENT . get_current_user_id(), $token, 5 * MINUTE_IN_SECONDS );
		$this->redirect( 'Nieuwe probe-sleutel gemaakt. Kopieer hem nu.' );
	}

	private function authorize( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Onvoldoende rechten.', 'server-location-test-probe' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce );
	}

	private function redirect( $notice ) {
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'sltp_notice' => $notice ), admin_url( 'tools.php' ) ) );
		exit;
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$hosts  = SLTP_Plugin::get_allowed_hosts();
		$token  = get_transient( SLTP_Plugin::TOKEN_TRANSIENT . get_current_user_id() );
		$notice = isset( $_GET['sltp_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['sltp_notice'] ) ) : '';
		if ( $token ) {
			delete_transient( SLTP_Plugin::TOKEN_TRANSIENT . get_current_user_id() );
		}
		?>
		<div class="wrap">
			<h1>TFSC Location Test Probe</h1>
			<?php if ( $notice ) : ?><div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div><?php endif; ?>
			<p>Voert begrensde, geauthenticeerde HTTPS-metingen uit vanaf deze WordPress-server.</p>
			<p><strong>MCP endpoint:</strong> <code><?php echo esc_html( rest_url( SLTP_REST::NAMESPACE . '/mcp' ) ); ?></code></p>
			<?php if ( $token ) : ?>
				<div class="notice notice-warning"><p>Deze sleutel wordt maar één keer getoond.</p><p><input class="large-text code" readonly value="<?php echo esc_attr( $token ); ?>" onclick="this.select()"></p></div>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="sltp_save_hosts">
				<?php wp_nonce_field( 'sltp_save_hosts' ); ?>
				<h2>Domein-allowlist</h2>
				<textarea name="hosts" rows="7" class="large-text code"><?php echo esc_textarea( implode( "\n", $hosts ) ); ?></textarea>
				<p class="description">Eén hostnaam per regel. Alleen HTTPS op poort 443; IP-adressen zijn niet toegestaan.</p>
				<?php submit_button( 'Allowlist opslaan' ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="sltp_generate_token">
				<?php wp_nonce_field( 'sltp_generate_token' ); ?>
				<?php submit_button( SLTP_Plugin::token_is_configured() ? 'Probe-sleutel vervangen' : 'Probe-sleutel maken', 'secondary' ); ?>
			</form>
		</div>
		<?php
	}
}
