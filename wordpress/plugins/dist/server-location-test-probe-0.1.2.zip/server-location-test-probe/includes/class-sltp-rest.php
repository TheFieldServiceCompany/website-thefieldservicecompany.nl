<?php

defined( 'ABSPATH' ) || exit;

final class SLTP_REST {
	const NAMESPACE = 'server-location-test-probe/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'permission_callback' => array( $this, 'can_manage' ),
				'callback'            => array( $this, 'status' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/token',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'permission_callback' => array( $this, 'can_manage' ),
				'callback'            => array( $this, 'generate_token' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/probe',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'permission_callback' => array( $this, 'can_manage' ),
				'callback'            => array( $this, 'admin_probe' ),
				'args'                => array(
					'url'    => array( 'type' => 'string', 'required' => true ),
					'method' => array( 'type' => 'string', 'enum' => array( 'GET', 'HEAD' ), 'default' => 'GET' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/mcp',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'permission_callback' => array( $this, 'can_use_mcp' ),
				'callback'            => array( $this, 'mcp' ),
			)
		);
	}

	public function can_manage() {
		return current_user_can( 'manage_options' );
	}

	public function can_use_mcp( WP_REST_Request $request ) {
		if ( ! SLTP_Plugin::token_is_configured() ) {
			return new WP_Error( 'probe_not_configured', 'De probe-sleutel is nog niet ingesteld.', array( 'status' => 503 ) );
		}

		if ( ! SLTP_Plugin::request_has_valid_token( $request ) ) {
			return new WP_Error( 'probe_unauthorized', 'Ongeldige probe-sleutel.', array( 'status' => 401 ) );
		}

		return true;
	}

	public function status() {
		return rest_ensure_response(
			array(
				'version'          => SLTP_VERSION,
				'allowed_hosts'    => SLTP_Plugin::get_allowed_hosts(),
				'token_configured' => SLTP_Plugin::token_is_configured(),
				'mcp_endpoint'     => rest_url( self::NAMESPACE . '/mcp' ),
			)
		);
	}

	public function generate_token() {
		return rest_ensure_response(
			array(
				'token'       => SLTP_Plugin::generate_token(),
				'display_once' => true,
			)
		);
	}

	public function admin_probe( WP_REST_Request $request ) {
		$result = ( new SLTP_Probe() )->probe( $request['url'], $request['method'] );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public function mcp( WP_REST_Request $request ) {
		if ( strlen( $request->get_body() ) > 65536 ) {
			return $this->rpc_error( null, -32600, 'Request body exceeds 64 KiB.', 413 );
		}

		$rpc = json_decode( $request->get_body(), true );
		if ( ! is_array( $rpc ) || '2.0' !== ( $rpc['jsonrpc'] ?? '' ) || empty( $rpc['method'] ) ) {
			return $this->rpc_error( $rpc['id'] ?? null, -32600, 'Invalid JSON-RPC request.', 400 );
		}

		$id     = $rpc['id'] ?? null;
		$method = (string) $rpc['method'];
		$params = isset( $rpc['params'] ) && is_array( $rpc['params'] ) ? $rpc['params'] : array();

		if ( 'notifications/initialized' === $method || 'notifications/cancelled' === $method ) {
			return new WP_REST_Response( null, 202 );
		}

		if ( 'initialize' === $method ) {
			return $this->rpc_result(
				$id,
				array(
					'protocolVersion' => $this->select_protocol_version( $params['protocolVersion'] ?? '' ),
					'capabilities'    => array( 'tools' => array( 'listChanged' => false ) ),
					'serverInfo'      => array( 'name' => 'tfsc-nl-location-probe', 'version' => SLTP_VERSION ),
					'instructions'    => 'Use the probe tools to measure allowlisted HTTPS URLs from the Dutch WordPress server.',
				)
			);
		}

		if ( 'ping' === $method ) {
			return $this->rpc_result( $id, new stdClass() );
		}

		if ( 'tools/list' === $method ) {
			return $this->rpc_result( $id, array( 'tools' => $this->tools() ) );
		}

		if ( 'tools/call' === $method ) {
			if ( ! SLTP_Plugin::consume_rate_limit( $request ) ) {
				return $this->tool_error( $id, 'Rate limit bereikt; probeer het over één minuut opnieuw.' );
			}

			return $this->call_tool( $id, $params );
		}

		return $this->rpc_error( $id, -32601, 'Method not found.' );
	}

	private function tools() {
		return array(
			array(
				'name'        => 'probe_url_from_netherlands',
				'description' => 'Request one allowlisted HTTPS URL from the Dutch WordPress server and return cache, CDN, IP and timing evidence.',
				'inputSchema' => array(
					'type'                 => 'object',
					'properties'           => array(
						'url'    => array( 'type' => 'string', 'format' => 'uri', 'description' => 'Allowlisted HTTPS URL to request.' ),
						'method' => array( 'type' => 'string', 'enum' => array( 'GET', 'HEAD' ), 'default' => 'GET' ),
					),
					'required'             => array( 'url' ),
					'additionalProperties' => false,
				),
				'annotations' => array( 'readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => true ),
			),
			array(
				'name'        => 'test_cache_transition_from_netherlands',
				'description' => 'Request one allowlisted HTTPS URL two or three times from the Dutch server to observe cache MISS-to-HIT behavior and the selected PoP.',
				'inputSchema' => array(
					'type'                 => 'object',
					'properties'           => array(
						'url'      => array( 'type' => 'string', 'format' => 'uri' ),
						'attempts' => array( 'type' => 'integer', 'minimum' => 2, 'maximum' => 3, 'default' => 2 ),
						'delay_ms' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 2000, 'default' => 500 ),
					),
					'required'             => array( 'url' ),
					'additionalProperties' => false,
				),
				'annotations' => array( 'readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => true ),
			),
		);
	}

	private function call_tool( $id, $params ) {
		$name      = isset( $params['name'] ) ? (string) $params['name'] : '';
		$arguments = isset( $params['arguments'] ) && is_array( $params['arguments'] ) ? $params['arguments'] : array();
		$url       = isset( $arguments['url'] ) ? (string) $arguments['url'] : '';
		$probe     = new SLTP_Probe();

		if ( 'probe_url_from_netherlands' === $name ) {
			$method = isset( $arguments['method'] ) ? strtoupper( (string) $arguments['method'] ) : 'GET';
			if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) ) {
				return $this->tool_error( $id, 'method moet GET of HEAD zijn.' );
			}
			$result = $probe->probe( $url, $method );
		} elseif ( 'test_cache_transition_from_netherlands' === $name ) {
			$result = $probe->probe_sequence( $url, $arguments['attempts'] ?? 2, $arguments['delay_ms'] ?? 500 );
		} else {
			return $this->tool_error( $id, 'Onbekend tool.' );
		}

		if ( is_wp_error( $result ) ) {
			return $this->tool_error( $id, $result->get_error_message() );
		}

		return $this->rpc_result(
			$id,
			array(
				'content'           => array( array( 'type' => 'text', 'text' => wp_json_encode( $result, JSON_UNESCAPED_SLASHES ) ) ),
				'structuredContent' => $result,
				'isError'           => false,
			)
		);
	}

	private function tool_error( $id, $message ) {
		return $this->rpc_result(
			$id,
			array(
				'content' => array( array( 'type' => 'text', 'text' => (string) $message ) ),
				'isError' => true,
			)
		);
	}

	private function select_protocol_version( $requested ) {
		$supported = array( '2025-03-26', '2025-06-18', '2025-11-25' );
		return in_array( $requested, $supported, true ) ? $requested : '2025-11-25';
	}

	private function rpc_result( $id, $result ) {
		return rest_ensure_response( array( 'jsonrpc' => '2.0', 'id' => $id, 'result' => $result ) );
	}

	private function rpc_error( $id, $code, $message, $http_status = 200 ) {
		return new WP_REST_Response(
			array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => (int) $code, 'message' => (string) $message ) ),
			$http_status
		);
	}
}
