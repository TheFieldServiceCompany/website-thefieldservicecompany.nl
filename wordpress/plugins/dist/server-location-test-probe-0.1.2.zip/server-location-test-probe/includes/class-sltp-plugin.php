<?php

defined( 'ABSPATH' ) || exit;

final class SLTP_Plugin {
	const OPTION_HOSTS      = 'sltp_allowed_hosts';
	const OPTION_TOKEN_HASH = 'sltp_token_hash';
	const TOKEN_TRANSIENT   = 'sltp_new_token_';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		new SLTP_REST();
		if ( is_admin() ) {
			new SLTP_Admin();
		}
	}

	public static function activate() {
		if ( false === get_option( self::OPTION_HOSTS, false ) ) {
			$host = self::normalize_host( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
			add_option( self::OPTION_HOSTS, $host ? array( $host ) : array(), '', false );
		}
	}

	public static function get_allowed_hosts() {
		$hosts = get_option( self::OPTION_HOSTS, array() );
		return self::sanitize_hosts( is_array( $hosts ) ? $hosts : array() );
	}

	public static function sanitize_hosts( $value ) {
		$items = is_array( $value ) ? $value : preg_split( '/\r\n|\r|\n/', (string) $value );
		$hosts = array();

		foreach ( $items as $item ) {
			$host = self::normalize_host( $item );
			if ( $host && ! filter_var( $host, FILTER_VALIDATE_IP ) ) {
				$hosts[] = $host;
			}
		}

		return array_values( array_unique( $hosts ) );
	}

	public static function normalize_host( $value ) {
		$host = strtolower( trim( (string) $value ) );
		$host = rtrim( $host, '.' );

		if ( '' === $host || strlen( $host ) > 253 || ! preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/', $host ) ) {
			return '';
		}

		return $host;
	}

	public static function generate_token() {
		$token = 'sltp_' . bin2hex( random_bytes( 32 ) );
		update_option( self::OPTION_TOKEN_HASH, hash( 'sha256', $token ), false );
		return $token;
	}

	public static function token_is_configured() {
		$hash = get_option( self::OPTION_TOKEN_HASH, '' );
		return is_string( $hash ) && 64 === strlen( $hash );
	}

	public static function request_has_valid_token( WP_REST_Request $request ) {
		$provided = trim( (string) $request->get_header( 'x-tfsc-probe-key' ) );
		if ( '' === $provided ) {
			$authorization = trim( (string) $request->get_header( 'authorization' ) );
			if ( 0 === stripos( $authorization, 'Bearer ' ) ) {
				$provided = trim( substr( $authorization, 7 ) );
			}
		}

		$expected = (string) get_option( self::OPTION_TOKEN_HASH, '' );
		return '' !== $provided && 64 === strlen( $expected ) && hash_equals( $expected, hash( 'sha256', $provided ) );
	}

	public static function consume_rate_limit( WP_REST_Request $request, $limit = 30 ) {
		if ( ! self::request_has_valid_token( $request ) ) { return false; }
		// Header names, Bearer case and whitespace never create a new identity.
		return SLTP_Request_Budget::consume( (string) get_option( self::OPTION_TOKEN_HASH, '' ), min( 30, max( 1, absint( $limit ) ) ), MINUTE_IN_SECONDS );
	}
}
