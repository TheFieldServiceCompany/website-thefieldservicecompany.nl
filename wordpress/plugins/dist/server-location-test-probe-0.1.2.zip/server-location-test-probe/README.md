# Server Location Test Probe for WordPress

## Security release 0.1.2 — 7 November 2026

The rate limit now uses the verified token identity, so Bearer spelling, whitespace and switching key headers cannot reset it. Invalid tokens cannot consume a valid token's budget. A short database lock serializes counter updates; a busy lock fails closed. The fixed-window limit remains 30 tool calls per minute, including a global limit.

One probe or its full two/three-attempt sequence shares a 2 MiB decoded body budget and a 20-second transfer deadline across redirects and attempts. A callback aborts oversized transfers. cURL receives the remaining deadline rather than a fresh timeout per redirect. DNS resolution is still a blocking system operation, so this is not an operating-system-level hard deadline on resolver stalls.

Version 0.1.2 retains the existing allowlist and token hash; no token rotation is required. The unique Update URI identifies this private plugin but does not itself implement automatic release distribution.

This repository contains two connected components:

1. a WordPress plugin that performs tightly restricted HTTPS probes from the WordPress server;
2. a portable Codex/ChatGPT plugin package in [`codex-extension/`](codex-extension/) that exposes those probes as tools.

The production endpoint is designed for `thefieldservicecompany.nl`, hosted in the Netherlands. It can independently measure HTTP status, request timings, connected IP, LiteSpeed cache state, QUIC.cloud cache state and PoP, and Cloudflare cache state.

## Security model

- HTTPS only, port 443 only.
- Explicit hostname allowlist managed by a WordPress administrator.
- IP literals, URL credentials, fragments, private IPs and reserved IPs are rejected.
- DNS is validated and the request is pinned to a validated public address.
- Redirects are followed manually and validated again, up to three times.
- No incoming visitor cookies or authorization headers are forwarded.
- Response headers are allowlisted and bounded.
- MCP calls require a separate generated key and are rate-limited.
- Request bodies and arbitrary HTTP methods are not supported.

## Tools

- `probe_url_from_netherlands`
- `test_cache_transition_from_netherlands`

The second tool performs two or three sequential GET requests so a cache transition such as `miss → hit` can be observed from the Dutch server location.
