# TFSC Form Bridge

## Beveiligingsrelease 0.5.6 — 7 november 2026

Documenten worden uitsluitend uit de servermatige uploadlijst van de builderadapter overgenomen. Losse bestandsverwijzingen uit ingestuurde velden worden genegeerd. Nieuwe documenten krijgen een privé-HMAC-bewijs dat de inzending, het bronveld, de positie en de exacte bestandsverwijzing bindt. De worker en B2-client controleren dit bewijs vóór verwerking. De niet-autoloadende sleutel en de bewijsgegevens horen bij de databasebackup; sleutelverlies leidt tot weigeren en handmatige controle, niet tot vertrouwen op losse oude paden.

Oude wachtende documenten zonder bewijs worden voor beoordeling behouden. Installeer pas nadat de actieve documentwachtrij gecontroleerd is. Beoordeel eventuele legacy-items afzonderlijk; onderteken ze niet automatisch op basis van hun aangeleverde pad. Afgeronde documenten worden niet opnieuw verwerkt.

Serverdiagnoses krijgen eigen ID’s. Browsermeldingen krijgen aparte gebeurtenissen en kunnen de serverstatus niet overschrijven. Correlatie blijft als data beschikbaar. Vroege diagnostiek heeft een aparte grens van 30 pogingen per afzender/formulier per vast tijdvak van tien minuten, browserfouten tien en samen maximaal 300 per tijdvak. Een korte databaselock beschermt tellerupdates tegen gelijktijdige wijzigingen. Bij een bezette lock of bereikt budget wordt diagnostiek overgeslagen; de formulierverwerking wordt niet afgebroken. De invoercontrole begrenst veld-/bestandsmetadata zonder de grootte van een echt multipart-document als logpayload te tellen.

Een unieke Update URI voorkomt verwarring met WordPress.org-pakketten. Er is hiermee nog geen automatische distributie van onze releases ingericht.

## Herkomstregistratie 0.5.5 — live 31 oktober 2026

Bewaart de eerste pagina, externe binnenkomstreferrer en UTM-campagne per browsertab. Bij een inzending worden die als bronmetadata meegegeven naast de formulierpagina en vorige pagina. Er wordt geen blijvende bezoekers-ID toegevoegd. Een gemarkeerde test blijft als internal_test herkenbaar. Ontbrekende historische binnenkomst wordt niet gereconstrueerd.

Supabase bewaart deze herkomst bij de broninzending, los van de rotatie van WordPress Diagnostics. Deze wijziging introduceert geen automatische verwijdering van CRM-data.

Zie [live verificatie](docs/FORM-ORIGIN-REPORTING-2026-10-31.md).

## Beveiligde diagnostiek

Versie `0.5.4` begrenst de publieke browserdiagnostiek per `REMOTE_ADDR` en
actief formulier, weigert diagnosepayloads boven 64 KiB en kapt opgeslagen
velden af op vaste technische limieten. Diagnostiek wordt standaard 30 dagen
bewaard, dagelijks in batches opgeruimd en tot standaard 5.000 regels begrensd.
De beheerder kan alleen een eindige bewaartermijn en een gecontroleerde
recordlimiet kiezen. Nonce- en actieve-mappingcontroles blijven verplicht.

## Herstel kandidaatdocumenten vóór matching

Versie `0.5.3` bewaart een kandidaatdocument ook wanneer een website-inzending
nog handmatig moet worden beoordeeld. Het document wordt eerst aan de immutable
submission gekoppeld en pas bij de expliciete keuze in **Website inbox** aan het
juiste kandidaatprofiel. Oudere outboxregels met
`candidate_document_target_missing` zijn opnieuw verwerkbaar. Outbox en
Diagnostics tonen het ingevulde e-mailadres om foutregels herkenbaar te maken.

## Technische foutdiagnostiek

Versie `0.5.1` breidt de diagnostische route voor actief gekoppelde
Elementor-formulieren uit tot een volledige trace. Ook een fout vóór Elementor
Submission of de lokale outbox wordt zichtbaar onder **Gereedschap > TFSC Form
Bridge > Diagnostics**. De log legt formulierwaarden, IP/proxyketen,
browser/clientcontext, pagina/referrer/navigatie, uploadmetadata,
responsebody, serveromgeving, PHP-foutdetails en requestduur vast. Eén
request-ID koppelt de WordPress-poging aan submission-UUID en outbox-ID.
Authenticatiecookies, wachtwoorden, nonces en API-secrets worden niet gelogd. Zie
[`docs/FORM-DIAGNOSTICS.md`](docs/FORM-DIAGNOSTICS.md).

Eigen WordPress-koppeling voor formulierinzendingen van The Field Service
Company naar de bestaande Supabase-database en het Appsmith-CRM.

## Status

`LIVE — 5 KOPPELINGEN ACTIEF, ALLE VIJF ROUTES END-TO-END BEWEZEN`

De plugin bevat formulierdetectie, een veilige instelbare
veldmapping, Elementor- en Bricks-adapters, normalisatie, een lokale outbox en
automatische beveiligde aflevering met retries. De Supabase-intaketabellen,
canonieke CRM-verwerking, Edge Function en kandidaat-/vacaturedocumentroutes
naar Backblaze B2 zijn lokaal ontworpen en synthetisch getest.

Versie `0.3.0` is op 20 oktober 2026 op live WordPress geïnstalleerd en
geactiveerd voor beoordeling van de beheerinterface. De installatie ontdekte
12 Elementor-formulierinstanties. Alle 12 koppelingen staan uit, alle mappings
staan op `Niet versturen`, de lokale outbox is leeg en zowel de beveiligde
ontvanger als Backblaze zijn niet geconfigureerd. Er wordt daarom niets naar
Supabase of Backblaze verzonden. De bestaande AFI-route is niet gewijzigd.

Versie `0.3.1` maakt de 12 formulierinstanties overzichtelijk via inklapbare
formulierkaarten. Iedere kaart toont status, formuliertype, veldental en
mappingversie zonder dat de volledige veldtabel zichtbaar hoeft te zijn. De
beheerder kan formulieren doorzoeken en steeds één formulier tegelijk openen.
Deze versie is op 20 oktober 2026 live geïnstalleerd; alle koppelingen bleven
uitgeschakeld.

Versie `0.3.2` scheidt gevonden bronformulieren van daadwerkelijk ingerichte
koppelingen. Het hoofdscherm toont alleen ingerichte of zojuist geselecteerde
koppelingen. Via `Nieuwe koppeling` opent een formulierkiezer met duidelijke
bronpagina, formulierbouwer en veldental. De plugin maakt daarbij geen nieuw
Elementor-formulier aan; hij koppelt een bestaand formulier aan het CRM-model.
Deze versie is op 20 oktober 2026 live geïnstalleerd. De eerste opgeslagen
mapping is `form_solliciteren_20240226` als `Sollicitatie op vacature`, met
kandidaatprofiel aan en bedrijf/bedrijfscontact uit. De koppeling zelf blijft
uitgeschakeld. Voornaam, achternaam, woonplaats, mobiel, e-mail, cv, LinkedIn,
vacaturenummer en privacyakkoord zijn aan de vastgelegde CRM-doelen gekoppeld;
vacaturenaam, vacaturelink, bedrijfsnaam en dienstverband staan op
`Niet versturen`. Na opslaan en herladen bleef de mapping intact, mappingversie
werd `1`, de outbox bleef volledig leeg en ontvanger en Backblaze bleven niet
geconfigureerd.

## Bevestigde scope

- Elementor Pro Forms als huidige formulierbron.
- Bricks Forms als toekomstige formulierbron.
- Eén gedeeld, formulierbouwer-onafhankelijk inzendingsmodel.
- Beveiligde server-side aflevering bij een Supabase Edge Function.
- Unieke submission-ID's en idempotente verwerking.
- Lokale outbox, retries, foutstatussen en herstelbaarheid.
- Instelbare WordPress-veldkoppeling per formulier: `Formulierveld` → veilig
  `CRM-veld` of `Niet versturen`.
- Upload van cv- en vacaturebestanden naar Backblaze B2; Supabase bewaart uitsluitend de
  documentmetadata, versie, relaties en de B2 `object_key`.
- Geen persoonsgegevens of cv-inhoud in GitHub. Het afgeschermde WordPress-
  beheerscherm toont diagnostische formuliergegevens volgens de ingestelde
  bewaartermijn; authenticatiegegevens en documentinhoud worden niet gelogd.
- Appsmith beheert de verwerkte gegevens rechtstreeks in Supabase; Appsmith is
  geen tweede gegevensbestemming.

## Wat nu lokaal werkt

- Automatisch vinden van gepubliceerde Elementor Pro- en Bricks-formulieren.
- Nieuwe formulieren staan standaard uit.
- Per formulier een type kiezen en ieder bronveld koppelen aan een vaste,
  gecontroleerde CRM-doelkeuze of `Niet versturen`.
- Per formulier schakelaars voor het aanmaken van een kandidaatprofiel en een
  nieuw bedrijf/bedrijfscontact; beide waarden vallen onder mappingversies.
- Suggesties voor bekende veld-ID's, zonder die automatisch op te slaan.
- Versienummering van mappingwijzigingen.
- Eén gemeenschappelijke, geschoonde inzendingsenvelop voor beide bouwers.
- Meerdere uploadbestanden per Bricks-veld en meerdere uploadvelden per form.
- Lokale outbox met technische metadata en het ingevulde e-mailadres in het
  afgeschermde WordPress-overzicht.
- HMAC-beveiligde ontvangstfunctie met idempotente registratie in de lokale
  Supabase-migratie.
- Duplicaatveilige omzetting naar persoon, kandidaat, sollicitatie,
  mailinginschrijving, bedrijf, bedrijfscontact en activiteit.
- Automatische outboxaflevering iedere vijf minuten met begrensde retries,
  veilige foutcodes en herstel van vastgelopen afleverpogingen.
- Kandidaat-cv's krijgen een stabiele document-UUID en een PII-vrij objectpad;
  lokale uploadpaden en -URL's worden uit de externe formulier-envelop gehaald.
- Upload via de Backblaze Native API en daarna idempotente registratie in de
  bestaande `documents`, `document_versions` en `document_links`-structuur.
- Een werkgeversinzending met vacaturebijlage maakt één vacature in de
  bestaande status `Draft`. De eerste bestandsnaam zonder extensie wordt de
  voorlopige, later aanpasbare titel; alle bijlagen uit dezelfde inzending
  worden als `job_description` aan die vacature gekoppeld.
- Synthetische tests zonder echte persoonsgegevens: 114 assertions op PHP 7.4
  en 8.3, twaalf Edge-tests op Deno 2.5.4 en de complete migratie-/SQL-testketen
  in een verse PostgreSQL 16-database.

## Live Supabase- en Backblaze-checkpoint — 2026-10-20

De vijf Form Bridge-migraties en Edge Function `tfsc-form-ingest` versie `3`
staan live in project `bpfocgapqsrokmargsjr`. De tabellen en service-role-only
RPC's zijn aanwezig, RLS staat aan en de intake bevat nul inzendingen. Een
synthetische sollicitatie op vacature `885425` doorliep de volledige database-
verwerking binnen een teruggedraaide transactie met status `succeeded`; daarna
stonden er aantoonbaar nul testpersonen, testsollicitaties en intake-items.

De Edge Function heeft een productie-HMAC-secret. Een unsigned live probe wordt
met HTTP `401` afgewezen. WordPress heeft de bijbehorende endpoint- en HMAC-
constanten in `wp-config.php`; de beveiligde verbindingstest geeft HTTP `200` /
`connection_ok` terug.

WordPress heeft daarnaast een aparte Backblaze-sleutel met uitsluitend
write-only toegang tot bucket `tfsc-documents-prod` en prefix `documents/`.
De beheerpagina herkent de configuratie.

Pluginversie `0.3.8` staat live. `form_solliciteren_20240226`,
`verzoek_advies`, `Vacature - Stel je vraag` en `Registratie` zijn actief.
Een eerste synthetische inzending zonder cv is in één poging als `succeeded`
verwerkt, gekoppeld aan vacature `885425` en zichtbaar in Appsmith als
`Submitted`. Een tweede inzending met dezelfde synthetische identiteit en
vacature hergebruikte dezelfde persoon en kandidaat, maakte geen tweede
sollicitatie en ging terecht naar `review` met `application_already_exists`.
Alle zes meegestuurde UTM/GCLID-waarden zijn in Supabase vastgelegd. De lokale
outbox bevat geen wachtende of mislukte items.

Een daaropvolgende synthetische PDF-cv is vanuit WordPress naar de private
Backblaze-bucket geschreven en idempotent in Supabase geregistreerd. Versie
`0.3.7` ondersteunt daarbij de huidige Backblaze API v4-weergave van
bucketrestricties. Migration
`20261020174500_classify_wordpress_candidate_documents.sql` classificeert
Bridge-kandidaatdocumenten als `cv`. De live Appsmith-shortlist toont daardoor
een actieve CV-knop en opent het juiste bestand in de documentviewer.

Op 20 oktober 2026 is vervolgens ook de ontbrekende live Word-route bewezen.
Een volledig synthetische sollicitatie met een geldige `.docx` van 10.779 bytes
is via het openbare Elementor-formulier ingediend. De Bridge verwerkte het
outboxitem in één poging als `succeeded`, maakte één nieuwe kandidaat en één
sollicitatie voor vacature `885425`, legde de drie testcampagnevelden vast en
registreerde het document als `cv` in bucket `tfsc-documents-prod`. De
automatische previewworker zette de DOCX in één poging om naar een benoemde
PDF-preview. De nieuwe kandidaat verscheen daarna in Appsmith **Nieuwe
contacten** met één bijlage; de CV-knop laadde aantoonbaar een
`data:application/pdf;base64`-document uit Backblaze. Daarmee is de keten
WordPress → Supabase → Backblaze → previewworker → Appsmith voor Word-cv's
end-to-end live bewezen.

Daarna is ook `verzoek_advies` als `Adviesaanvraag` geactiveerd. Een volledig
synthetische inzending is in één poging verwerkt tot één persoon, één
kandidaatprofiel, privacybewijs en activiteit `website_advice_request`, zonder
een sollicitatierecord. De kandidaat verscheen als type **Advies** in Appsmith
**Nieuwe contacten**. De live controle bracht tevens aan het licht dat het
Elementor-formulier een legacywaarde `2` als vast vacaturenummer verstuurt en
een meegegeven `?vacaturenummer=` negeert. Daardoor werd de eerste test ten
onrechte als bron aan testvacature `2` gekoppeld. Mappingversie `2` verstuurt
dit veld daarom niet meer; toekomstige algemene adviesaanvragen krijgen geen
verzonnen vacaturecontext. Het synthetische testrecord blijft als controleerbare
historie bestaan.

Als eerste canonieke veldmigratie is `Vacature - Stel je vraag` gepubliceerd
met vaste Engelse `field_id`-waarden. Versie `0.3.8` herkent deze ID's en de
live mapping is na herladen gecontroleerd. De bestaande URL-/requestparameters
zijn bewust gelijk gebleven, zodat vacatureknoppen niet hoeven te worden
aangepast. De openbare inzendingstests met en zonder vacaturecontext zijn nog
niet uitgevoerd.

Daarna is ook `Registratie` met canonieke Engelse kandidaatveld-ID's
gepubliceerd en als `Open registratie/inschrijving` actief gemapt. Kandidaat
staat aan en bedrijf uit. De vaste legacyvelden `vacaturenaam`,
`vacancy_number = 1` en `bedrijfsnaam` worden niet verstuurd; zo kan een open
registratie nooit door de sentinelwaarde `1` aan een echte vacature worden
gekoppeld. De mapping bleef na herladen intact als versie `1`.

De openbare registratie is daarna zonder cv end-to-end getest. De eerste
synthetische proef gebruikte per ongeluk een mobiel nummer van een oudere
testpersoon en ging daardoor terecht naar `review` met
`person_email_conflict`; er zijn voor die inzending geen canonieke
persoonsrecords aangemaakt. Een tweede proef met volledig unieke testgegevens
werd in één poging als `succeeded` verwerkt. Supabase maakte precies één
persoon, kandidaatprofiel met status `New`, primair adres, privacybewijs,
voorkeur `Vast dienstverband`, activiteit `website_open_registration` en open
intake-item aan. Er ontstond geen bedrijf, vacature of sollicitatie. Appsmith
**Nieuwe contacten** toont de inzending als type **Registratie**, status
**Verwerkt** en relatie **Nieuw profiel**; **Open profiel** opent het juiste
kandidaatprofiel. De outbox bevat geen wachtende of mislukte items.

Op 21 oktober 2026 is versie `0.3.9` live gezet om een uploadregressie in
Elementor Pro 4.3.2 op de productiehosting af te vangen. Alleen uploadvelden die
in een actieve mapping expliciet als kandidaat-cv of vacaturebijlage zijn
ingesteld, worden vóór Elementors eigen verplaatsstap gevalideerd en in de
normale afgeschermde Elementor-map klaargezet. De opgeslagen bestandsnaam is
een UUID zonder aangeleverde naam of persoonsgegevens. De plugin laat alle
overige uploadvelden ongemoeid. De nieuwe route is met 64 assertions op PHP
7.4 en PHP 8.3 getest. De live beveiligde verbindingstest geeft opnieuw
`connection_ok`. Openbare DOCX-proeven via Registratie, Solliciteren en
Werkgeverscontact hebben deze uploadroute daarna end-to-end bewezen.

Versie `0.4.0` bewaart voor ieder actief gemapt uploadbestand daarnaast een
eigen afgeschermde werkkopie totdat Backblaze-upload en Supabase-registratie
beide zijn bevestigd. Dit voorkomt dat Elementors tijdelijke kopie vóór de
asynchrone outboxverwerking verdwijnt. Na succesvolle documentregistratie wordt
uitsluitend de Bridge-werkkopie verwijderd. De route is met 64 assertions op
PHP 7.4 en PHP 8.3 getest en op 21 oktober live gezet.

Versie `0.4.1` maakt een later gewijzigde of verwijderde Elementor-/Bricks-
`field_id` zichtbaar met de badge **Mapping controleren** en noemt de verdwenen
bron-ID's in het formulierpaneel. Een nieuw veld blijft altijd op **Niet
versturen** totdat een beheerder bewust een CRM-bestemming kiest. De begrensde
retryplanning is apart testbaar gemaakt: time-outs, HTTP 429, HTTP 422 en 5xx
gaan via backoff; definitieve validatie- en authenticatiefouten stoppen direct.
De versie is met 74 assertions op PHP 7.4 en 8.3 getest; alle PHP-bestanden zijn
syntactisch gecontroleerd en de elf Edge Function-tests slagen op Deno 2.5.4.
Versie `0.4.1` is daarna live geïnstalleerd; alle vijf koppelingen en mappings
bleven actief en de beveiligde verbindingstest gaf opnieuw `connection_ok`.

Versie `0.4.2` volgt voor Backblaze-uploads het officiële herstelcontract. Als
een tijdelijke opslagpod, verbinding, uploadtoken of 5xx-respons de eerste
upload afwijst, haalt de Bridge onmiddellijk één verse upload-URL op en probeert
dezelfde gecontroleerde bytes nogmaals. Pas daarna neemt de bestaande
begrensde WordPress-outboxretry het over. Definitieve 400-, 403-, 405-, 411-
en 415-fouten gaan direct naar handmatige controle. De lokale outbox bewaart
voortaan een veilige technische HTTP-/Backblaze-foutcode, maar nooit een
bestandsnaam, pad, inhoud, sleutel of responsebericht. De `Content-Length` is
exact gebaseerd op de daadwerkelijk gelezen bytes en alle Backblaze-verzoeken
dragen een herkenbare plugin-User-Agent. De route is met 99 assertions op PHP
7.4 en PHP 8.3 getest; alle PHP-bestanden zijn syntactisch gecontroleerd.

Versie `0.4.2` is daarna live geïnstalleerd en met een openbare synthetische
Registratie plus DOCX getest. Backblaze gaf tijdens de eerste outboxpoging ook
op de verse upload-URL een tijdelijke `503 service_unavailable`; de duurzame
outbox leverde na de ingestelde backoff op poging twee volledig af. Supabase
registreerde één canoniek cv-document, versie, Backblaze-file-ID en
kandidaatrelatie zonder reviewcode. De PDF-preview werd aangemaakt en Appsmith
**Nieuwe contacten** toont de registratie met actieve CV-knop. Dit bewijst
zowel de storingsdiagnose als de volledige herstelroute zonder documentverlies.

De daaropvolgende openbare werkgeversproef met een echte synthetische DOCX is
in één poging afgeleverd. Supabase maakte zonder reviewcode persoon,
bedrijfscontact, bedrijf `Codex Testbedrijf Werkgever 2`, activiteit en
Draft-vacature `884980` aan. Het originele DOCX staat privé in Backblaze en is
als `job_description` aan de vacature gekoppeld. Appsmith **Nieuwe contacten**
toont de inzending als **Werkgever / Verwerkt**, met het juiste bedrijf,
vacaturenummer en één bijlage. De eerdere proef van vóór `0.4.0` blijft bewust
als reviewhistorie met `document_path_missing` bestaan.

## Nog bewust niet aangesloten

- De vijf actieve formulierkoppelingen zijn openbaar synthetisch bewezen.
  Mailingregistratie blijft bewust buiten scope omdat de pagina niet meer
  actief wordt gebruikt.

## Zelf een nieuw formulier koppelen

Een nieuw gepubliceerd Elementor Pro-formulier kan zonder unieke plugin-code
via **Nieuwe koppeling** worden getypeerd, veilig gemapt, geactiveerd en getest,
zolang het bestaande CRM-doelen gebruikt. De volledige beheerderswerkwijze,
canonieke veld-ID's, testpoort en stopmomenten staan in
[`docs/NEW-FORM-WORKFLOW.md`](docs/NEW-FORM-WORKFLOW.md).

## Serverconfiguratie

WordPress bewaart nooit een Supabase secret key. Alleen de vaste Edge Function
URL en een apart HMAC-geheim staan server-side in `wp-config.php`:

```php
define( 'TFSC_FORM_BRIDGE_ENDPOINT', 'https://PROJECT.supabase.co/functions/v1/tfsc-form-ingest' );
define( 'TFSC_FORM_BRIDGE_HMAC_SECRET', 'MINIMAAL-32-TEKENS-UIT-EEN-WACHTWOORDGENERATOR' );

define( 'TFSC_B2_APPLICATION_KEY_ID', 'B2-KEY-ID' );
define( 'TFSC_B2_APPLICATION_KEY', 'B2-APPLICATION-KEY' );
define( 'TFSC_B2_BUCKET_ID', 'B2-BUCKET-ID' );
define( 'TFSC_B2_BUCKET_NAME', 'tfsc-documents-prod' );
define( 'TFSC_B2_REGION', 'eu-central-003' );
```

Hetzelfde HMAC-geheim wordt als `TFSC_FORM_BRIDGE_HMAC_SECRET` in de Edge
Function secrets gezet. Zet nooit echte sleutels of geheimen in Git.

De beheerpagina bevat een knop **Verbinding testen**. Die verstuurt alleen een
correct ondertekend `connection_test`-object. Na geslaagde HMAC-controle geeft
de Edge Function HTTP `200` met `connection_ok` terug, nog voordat een database-
client of intakeverwerking wordt gebruikt. Er worden geen formuliergegevens,
persoonsgegevens of CRM-records aangemaakt.

Op 20 oktober 2026 is versie `0.3.4` live geïnstalleerd. Deze versie vervangt de
eerdere proof-via-HTTP-400. De live test gaf `connection_ok` terug en Query
Monitor toonde de Supabase-call als HTTP `200 OK`. De formuliermapping blijft
uitgeschakeld en de outbox leeg.

Versie `0.3.5` voegde **Wachtrij nu verwerken** toe als gecontroleerde
beheerfallback naast de automatische vijfminutenverwerking. Versie `0.3.6`
neemt ontbrekende UTM- en GCLID-waarden over uit de reeds vastgelegde pagina-
URL, omdat Elementor die queryparameters niet als losse AJAX-velden verstuurt.
Beide wijzigingen zijn live geïnstalleerd; de no-CV-route en UTM-opslag zijn
vervolgens end-to-end bewezen.

Versie `0.3.7` verwerkt Backblaze API v4-bucketrestricties en kan uitsluitend
bekende herstelbare B2-configuratiefouten vanuit de beheeractie opnieuw in de
wachtrij zetten. De live kandidaat-cv-route naar Backblaze, Supabase en de
Appsmith-viewer is daarmee end-to-end bewezen.

Versie `0.3.8` breidt de gecontroleerde suggestielaag uit met de canonieke
Engelse formulier-ID's. De plugin blijft suggesties alleen tonen en slaat nooit
automatisch een CRM-doel op. De lokale PHP-test kon op deze werkplek niet
worden uitgevoerd omdat hier geen PHP-binary beschikbaar is; de distributie-
zip is wel integraal gecontroleerd en de live installatie en herlaadtest zijn
geslaagd.

Versie `0.3.9` neemt voor expliciet gemapte documentvelden de uploadstap veilig
over voordat Elementor Pro zelf `move_uploaded_file()` aanroept. Dit voorkomt
dat Elementor Pro 4.3.2 op deze hosting een lege doelbestandsnaam gebruikt.
Extensie, MIME, uploadstatus en grootte worden gecontroleerd; de tijdelijke
bron blijft beschikbaar voor de overige formulieracties en Elementor ontvangt
dezelfde `files`-recordstructuur als bij zijn eigen uploadverwerking.

Versie `0.4.0` scheidt de tijdelijke Elementor-kopie van de eigen Bridge-
werkkopie. De Bridge-kopie staat in de afgeschermde stagingmap met een PII-vrije
bestandsnaam, blijft beschikbaar voor retries en wordt pas verwijderd nadat
Backblaze en Supabase het document hebben bevestigd. De openbare
werkgeversproef leverde de DOCX in één poging af en maakte de verwachte
Draft-vacature met documentrelatie.

Gebruik voor WordPress een aparte Backblaze application key met uitsluitend
`writeFiles`, beperkt tot bucket `tfsc-documents-prod` en prefix `documents/`.
De key krijgt geen lees- of verwijderrechten. Cv-binaries gaan rechtstreeks van
WordPress naar Backblaze; Supabase ontvangt alleen documentmetadata.

## Lokale test

```bash
php tests/run.php
```

## Buiten scope

- Elementor Atomic Forms.
- EngageBay als toekomstig CRM; het blijft alleen legacy- en migratiebron.
- De honderden overige AFI-formulierbronnen en bestemmingen.
- Rechtstreekse verzending vanuit browser-JavaScript naar Supabase.
- Productiedata, formulierinzendingen, cv's, exports, wachtwoorden, licenties
  of API-sleutels in deze repository.

## Documentatie

- [Scope en architectuur](docs/SCOPE.md)
- [AFI 2.10.3 brononderzoek](docs/AFI-REFERENCE.md)
- [Elementor-formulierinventaris 2026-10-20](docs/ELEMENTOR-FORM-INVENTORY-2026-10-20.md)
- [Formuliermapping naar het bestaande CRM-model](docs/FORM-DATA-MAPPING-2026-10-20.md)
- [Besluiten en uitvoeringspoort](docs/DECISIONS.md)

De volledige AFI-plugin is alleen lokaal als technische referentie onderzocht.
Deze directory bevat uitsluitend onze eigen toekomstige connector en de
bijbehorende technische documentatie.

