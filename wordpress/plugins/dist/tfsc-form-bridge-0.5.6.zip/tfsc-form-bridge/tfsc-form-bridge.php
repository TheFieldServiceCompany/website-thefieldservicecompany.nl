<?php
/**
 * Plugin Name: TFSC Form Bridge
 * Description: Betrouwbare, instelbare koppeling van Elementor Pro en Bricks Forms naar het TFSC CRM.
 * Version: 0.5.6
 * Update URI: https://github.com/TheFieldServiceCompany/tfsc-crm-ats
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: The Field Service Company
 * Text Domain: tfsc-form-bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TFSC_FORM_BRIDGE_VERSION', '0.5.6' );
define( 'TFSC_FORM_BRIDGE_FILE', __FILE__ );
define( 'TFSC_FORM_BRIDGE_DIR', plugin_dir_path( __FILE__ ) );

require_once TFSC_FORM_BRIDGE_DIR . 'src/TargetRegistry.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/MappingRepository.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/FormDiscovery.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/UploadProvenance.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/RequestBudget.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/SubmissionNormalizer.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/EnvelopeSanitizer.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/DocumentManifest.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/OutboxRepository.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/DiagnosticRepository.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/BackblazeClient.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/DeliveryWorker.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/Activator.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/ElementorProAdapter.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/ElementorDiagnostics.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/BricksAdapter.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/AdminPage.php';
require_once TFSC_FORM_BRIDGE_DIR . 'src/Plugin.php';

register_activation_hook( __FILE__, array( 'TFSC\\FormBridge\\Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'TFSC\\FormBridge\\Activator', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		TFSC\FormBridge\Plugin::boot();
	}
);
