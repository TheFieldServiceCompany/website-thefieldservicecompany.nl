<?php

namespace TFSC\FormBridge;

final class BricksAdapter {
	/** @var MappingRepository */
	private $mappings;

	/** @var SubmissionNormalizer */
	private $normalizer;

	/** @var OutboxRepository */
	private $outbox;

	/** @var array<string,bool> */
	private static $captured = array();

	public function __construct( MappingRepository $mappings, SubmissionNormalizer $normalizer, OutboxRepository $outbox ) {
		$this->mappings   = $mappings;
		$this->normalizer = $normalizer;
		$this->outbox     = $outbox;
	}

	public function register() {
		add_action( 'bricks/form/custom_action', array( $this, 'capture' ), 50, 1 );
	}

	public function capture( $form ) {
		if ( ! is_object( $form ) || ! method_exists( $form, 'get_fields' ) || ! method_exists( $form, 'get_settings' ) ) {
			return;
		}

		$posted   = (array) $form->get_fields();
		$post_id  = isset( $posted['postId'] ) ? absint( $posted['postId'] ) : 0;
		$form_id  = isset( $posted['formId'] ) ? sanitize_key( $posted['formId'] ) : '';
		$form_key = 'bricks:' . $post_id . ':' . $form_id;

		if ( ! $post_id || '' === $form_id ) {
			return;
		}

		$mapping = $this->mappings->get( $form_key );
		if ( ! is_array( $mapping ) || empty( $mapping['enabled'] ) ) {
			return;
		}

		$guard_key = $form_key . ':' . spl_object_hash( $form );
		if ( isset( self::$captured[ $guard_key ] ) ) {
			return;
		}
		self::$captured[ $guard_key ] = true;

		$settings    = (array) $form->get_settings();
		$field_defs  = $this->field_definitions( isset( $settings['fields'] ) ? $settings['fields'] : array() );
		$fields      = array();
		$system_keys = array( 'postId', 'formId', 'referrer' );

		foreach ( $posted as $key => $value ) {
			if ( in_array( $key, $system_keys, true ) ) {
				continue;
			}

			$field_id = sanitize_key( str_replace( 'form-field-', '', (string) $key ) );
			if ( '' === $field_id ) {
				continue;
			}

			$definition          = isset( $field_defs[ $field_id ] ) ? $field_defs[ $field_id ] : array();
			$fields[ $field_id ] = array(
				'label'    => isset( $definition['label'] ) ? $definition['label'] : $field_id,
				'type'     => isset( $definition['type'] ) ? $definition['type'] : 'text',
				'value'    => $value,
				'required' => ! empty( $definition['required'] ),
			);
		}

		$trusted_files = array();
		if ( method_exists( $form, 'get_uploaded_files' ) ) {
			foreach ( (array) $form->get_uploaded_files() as $key => $uploaded_files ) {
				$field_id = sanitize_key( str_replace( 'form-field-', '', (string) $key ) );
				if ( '' === $field_id ) {
					continue;
				}

				$definition          = isset( $field_defs[ $field_id ] ) ? $field_defs[ $field_id ] : array();
				$trusted_files[ $field_id ] = array_values( (array) $uploaded_files );
				$fields[ $field_id ] = array(
					'label'    => isset( $definition['label'] ) ? $definition['label'] : $field_id,
					'type'     => 'upload',
					'value'    => array_values( (array) $uploaded_files ),
					'required' => ! empty( $definition['required'] ),
				);
			}
		}

		$page_url = isset( $posted['referrer'] ) ? $posted['referrer'] : ( isset( $_SERVER['HTTP_REFERER'] ) ? wp_unslash( $_SERVER['HTTP_REFERER'] ) : '' );
		$source   = array(
			'builder'    => 'bricks',
			'form_key'   => $form_key,
			'form_id'    => $form_id,
			'form_name'  => isset( $settings['name'] ) ? $settings['name'] : '',
			'post_id'    => $post_id,
			'site_url'   => home_url( '/' ),
			'page_title' => get_the_title( $post_id ),
			'page_url'   => $page_url,
			'referrer'   => isset( $_SERVER['HTTP_REFERER'] ) ? wp_unslash( $_SERVER['HTTP_REFERER'] ) : '',
			'remote_ip'  => isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '',
			'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '',
		);

		$envelope = $this->normalizer->normalize( $source, $fields, $mapping, $trusted_files );
		$result   = $this->outbox->enqueue( $envelope );
		if ( is_wp_error( $result ) ) {
			error_log( 'TFSC Form Bridge Bricks capture failed: ' . sanitize_key( $result->get_error_code() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	private function field_definitions( $definitions ) {
		$result = array();
		foreach ( (array) $definitions as $definition ) {
			if ( ! is_array( $definition ) || empty( $definition['id'] ) ) {
				continue;
			}

			$id            = sanitize_key( $definition['id'] );
			$result[ $id ] = array(
				'label'    => isset( $definition['label'] ) ? sanitize_text_field( $definition['label'] ) : $id,
				'type'     => isset( $definition['type'] ) ? sanitize_key( $definition['type'] ) : 'text',
				'required' => ! empty( $definition['required'] ),
			);
		}

		return $result;
	}
}
