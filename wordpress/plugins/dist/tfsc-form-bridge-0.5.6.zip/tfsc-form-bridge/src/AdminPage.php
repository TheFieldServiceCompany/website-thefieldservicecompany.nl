<?php

namespace TFSC\FormBridge;

final class AdminPage {
	/** @var FormDiscovery */
	private $discovery;

	/** @var MappingRepository */
	private $mappings;

	/** @var TargetRegistry */
	private $targets;

	/** @var OutboxRepository */
	private $outbox;

	/** @var DeliveryWorker */
	private $delivery;

	/** @var DiagnosticRepository */
	private $diagnostics;

	public function __construct( FormDiscovery $discovery, MappingRepository $mappings, TargetRegistry $targets, OutboxRepository $outbox, DeliveryWorker $delivery, DiagnosticRepository $diagnostics ) {
		$this->discovery = $discovery;
		$this->mappings  = $mappings;
		$this->targets   = $targets;
		$this->outbox    = $outbox;
		$this->delivery  = $delivery;
		$this->diagnostics = $diagnostics;
	}

	public function register() {
		add_action( 'admin_menu', array( $this, 'add_page' ) );
	}

	public function add_page() {
		add_management_page(
			'TFSC Form Bridge',
			'TFSC Form Bridge',
			'manage_options',
			'tfsc-form-bridge',
			array( $this, 'render' )
		);
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Je hebt onvoldoende rechten voor deze pagina.', 'tfsc-form-bridge' ) );
		}

		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'forms';
		if ( ! in_array( $active_tab, array( 'forms', 'diagnostics' ), true ) ) {
			$active_tab = 'forms';
		}

		$messages = array();
		if ( isset( $_POST['tfsc_form_bridge_action'] ) ) {
			check_admin_referer( 'tfsc_form_bridge_save', 'tfsc_form_bridge_nonce' );
			$action = sanitize_key( wp_unslash( $_POST['tfsc_form_bridge_action'] ) );

			if ( 'refresh' === $action ) {
				$this->discovery->invalidate();
				$messages[] = array( 'success', 'Formulieren zijn opnieuw ingelezen.' );
			} elseif ( 'test_connection' === $action ) {
				$result = $this->delivery->test_connection();
				$messages[] = is_wp_error( $result )
					? array( 'error', $result->get_error_message() )
					: array( 'success', 'Beveiligde verbinding met Supabase werkt. Er zijn geen formulier- of CRM-gegevens aangemaakt.' );
			} elseif ( 'process_outbox' === $action ) {
				$requeued   = $this->outbox->requeue_recoverable_document_reviews();
				$processed  = $this->delivery->run();
				$messages[] = $processed
					? array( 'success', sprintf( '%d wachtrij-item(s) verwerkt%s.', $processed, $requeued ? sprintf( ', waaronder %d heropende documentfout(en)', $requeued ) : '' ) )
					: array( 'info', 'Er stonden geen afleverbare items in de wachtrij.' );
			} elseif ( 'save' === $action ) {
				$messages = array_merge( $messages, $this->save_posted_mappings() );
			} elseif ( 'save_diagnostic_settings' === $action ) {
				$retention = isset( $_POST['diagnostic_retention_days'] ) ? absint( wp_unslash( $_POST['diagnostic_retention_days'] ) ) : DiagnosticRepository::DEFAULT_RETENTION_DAYS;
				$max_records = isset( $_POST['diagnostic_max_records'] ) ? absint( wp_unslash( $_POST['diagnostic_max_records'] ) ) : DiagnosticRepository::DEFAULT_MAX_RECORDS;
				if ( ! in_array( $retention, DiagnosticRepository::allowed_retention_days(), true ) ) {
					$messages[] = array( 'error', 'Ongeldige bewaartermijn.' );
				} elseif ( ! in_array( $max_records, DiagnosticRepository::allowed_max_records(), true ) ) {
					$messages[] = array( 'error', 'Ongeldig maximumaantal logregels.' );
				} else {
					update_option( DiagnosticRepository::RETENTION_OPTION, $retention, false );
					update_option( DiagnosticRepository::MAX_RECORDS_OPTION, $max_records, false );
					$removed   = $this->diagnostics->run_cleanup();
					$messages[] = array( 'success', sprintf( 'Diagnostieklimieten opgeslagen. %d overtollige logregel(s) verwijderd.', $removed ) );
				}
			} elseif ( 'clear_diagnostics' === $action ) {
				$messages[] = $this->diagnostics->clear()
					? array( 'success', 'Het diagnostische log is volledig leeggemaakt.' )
					: array( 'error', 'Het diagnostische log kon niet worden leeggemaakt.' );
			}
		}

		$forms    = $this->discovery->all();
		$mappings = $this->mappings->all();
		$targets  = $this->grouped_targets();
		$form_types = $this->targets->form_types();
		$active_forms = 0;
		$configured_forms = 0;

		foreach ( $forms as $form_key => $form ) {
			$current = isset( $mappings[ $form_key ] ) && is_array( $mappings[ $form_key ] ) ? $mappings[ $form_key ] : array();
			if ( ! empty( $current['form_type'] ) ) {
				++$configured_forms;
			}
			if ( ! empty( $current['enabled'] ) ) {
				++$active_forms;
			}
		}
		?>
		<div class="wrap tfsc-bridge">
			<style>
				.tfsc-bridge { max-width: 1240px; }
				.tfsc-bridge__intro { max-width: 920px; color: #50575e; font-size: 14px; }
				.tfsc-overview { display: grid; grid-template-columns: repeat(3, minmax(150px, 1fr)); gap: 12px; max-width: 720px; margin: 20px 0; }
				.tfsc-overview__item, .tfsc-status-panel { background: #fff; border: 1px solid #c3c4c7; border-radius: 6px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
				.tfsc-overview__item { padding: 14px 16px; }
				.tfsc-overview__value { display: block; margin-bottom: 3px; font-size: 24px; font-weight: 600; line-height: 1; color: #1d2327; }
				.tfsc-overview__label { color: #646970; }
				.tfsc-status-panel { max-width: 1100px; margin: 18px 0; padding: 16px; }
				.tfsc-status-panel h2 { margin: 0 0 12px; }
				.tfsc-status-row { display: flex; flex-wrap: wrap; gap: 10px 24px; align-items: center; }
				.tfsc-status-pill, .tfsc-form-badge { display: inline-flex; align-items: center; border-radius: 999px; padding: 3px 9px; font-size: 12px; font-weight: 600; line-height: 1.5; }
				.tfsc-status-pill--off, .tfsc-form-badge--off { background: #f0f0f1; color: #50575e; }
				.tfsc-status-pill--on, .tfsc-form-badge--on { background: #edfaef; color: #116329; }
				.tfsc-outbox-counts { display: grid; grid-template-columns: repeat(4, minmax(120px, 1fr)); gap: 10px; margin-top: 14px; }
				.tfsc-outbox-count { padding: 10px 12px; background: #f6f7f7; border-radius: 4px; }
				.tfsc-outbox-count strong { display: block; font-size: 18px; }
				.tfsc-form-toolbar { position: sticky; top: 32px; z-index: 20; display: flex; gap: 12px; align-items: center; justify-content: space-between; max-width: 1100px; margin: 20px 0 12px; padding: 12px; background: #f6f7f7; border: 1px solid #c3c4c7; border-radius: 6px; }
				.tfsc-form-toolbar__left { display: flex; gap: 10px; align-items: center; flex: 1; }
				.tfsc-form-search { width: min(420px, 100%); }
				.tfsc-form-list { max-width: 1100px; }
				.tfsc-form-card { margin: 0 0 10px; background: #fff; border: 1px solid #c3c4c7; border-radius: 6px; box-shadow: 0 1px 1px rgba(0,0,0,.04); overflow: hidden; }
				.tfsc-form-card[open] { border-color: #8c8f94; box-shadow: 0 2px 6px rgba(0,0,0,.08); }
				.tfsc-form-card[hidden] { display: none; }
				.tfsc-form-card__summary { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 16px; align-items: center; padding: 15px 18px; cursor: pointer; list-style: none; }
				.tfsc-form-card__summary::-webkit-details-marker { display: none; }
				.tfsc-form-card__summary::before { content: "›"; grid-column: 1; grid-row: 1 / span 2; align-self: center; width: 18px; color: #646970; font-size: 24px; line-height: 1; transition: transform .15s ease; }
				.tfsc-form-card[open] > .tfsc-form-card__summary::before { transform: rotate(90deg); }
				.tfsc-form-card__identity { grid-column: 1; grid-row: 1 / span 2; min-width: 0; padding-left: 28px; }
				.tfsc-form-card__title { display: block; overflow: hidden; font-size: 15px; font-weight: 600; color: #1d2327; text-overflow: ellipsis; white-space: nowrap; }
				.tfsc-form-card__meta { display: block; margin-top: 3px; overflow: hidden; color: #646970; text-overflow: ellipsis; white-space: nowrap; }
				.tfsc-form-card__badges { grid-column: 2; grid-row: 1 / span 2; display: flex; flex-wrap: wrap; gap: 6px; justify-content: flex-end; }
				.tfsc-form-badge { background: #f0f0f1; color: #50575e; }
				.tfsc-form-badge--warning { background: #fcf0c5; color: #594f00; }
				.tfsc-form-card__body { padding: 18px; border-top: 1px solid #dcdcde; }
				.tfsc-mapping-warning { margin: 0 0 16px; padding: 12px 14px; border-left: 4px solid #dba617; background: #fff8e5; color: #1d2327; }
				.tfsc-mapping-warning code { white-space: nowrap; }
				.tfsc-form-settings { display: grid; grid-template-columns: minmax(260px, 1fr) minmax(300px, 1fr); gap: 16px 28px; margin-bottom: 18px; }
				.tfsc-form-settings p { margin: 0; }
				.tfsc-form-settings select { width: 100%; max-width: 420px; }
				.tfsc-field-table select { width: 100%; min-width: 0; }
				.tfsc-form-actions { display: flex; flex-wrap: wrap; gap: 8px 24px; align-items: center; }
				.tfsc-form-actions label { margin: 0; }
				.tfsc-no-results { display: none; max-width: 1100px; padding: 18px; text-align: center; color: #646970; background: #fff; border: 1px dashed #c3c4c7; border-radius: 6px; }
				.tfsc-empty-state { max-width: 1100px; padding: 32px 20px; text-align: center; color: #50575e; background: #fff; border: 1px dashed #a7aaad; border-radius: 6px; }
				.tfsc-empty-state h2 { margin-top: 0; color: #1d2327; }
				.tfsc-form-footer { display: flex; justify-content: space-between; align-items: center; max-width: 1100px; margin-top: 16px; }
				.tfsc-form-picker { width: min(760px, calc(100vw - 48px)); max-height: min(760px, calc(100vh - 80px)); padding: 0; border: 0; border-radius: 8px; box-shadow: 0 12px 48px rgba(0,0,0,.28); }
				.tfsc-form-picker::backdrop { background: rgba(29,35,39,.55); }
				.tfsc-form-picker__header { position: sticky; top: 0; z-index: 2; display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; padding: 20px 22px 16px; background: #fff; border-bottom: 1px solid #dcdcde; }
				.tfsc-form-picker__header h2 { margin: 0 0 4px; }
				.tfsc-form-picker__header p { margin: 0; color: #646970; }
				.tfsc-form-picker__close { min-width: 34px; min-height: 34px; padding: 0; font-size: 22px; line-height: 1; }
				.tfsc-form-picker__body { padding: 18px 22px 22px; }
				.tfsc-picker-search { width: 100%; margin-bottom: 14px; }
				.tfsc-picker-list { display: grid; gap: 8px; }
				.tfsc-picker-item { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 16px; align-items: center; padding: 12px 14px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 5px; }
				.tfsc-picker-item[hidden] { display: none; }
				.tfsc-picker-item__title { display: block; font-weight: 600; color: #1d2327; }
				.tfsc-picker-item__meta { display: block; margin-top: 3px; color: #646970; }
				.tfsc-picker-empty { display: none; padding: 20px; text-align: center; color: #646970; }
				.tfsc-diagnostic-actions { display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: flex-end; margin: 18px 0; padding: 16px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 6px; }
				.tfsc-diagnostic-actions form { margin: 0; }
				.tfsc-diagnostic-actions label { display: block; margin-bottom: 6px; font-weight: 600; }
				.tfsc-diagnostic-table td { vertical-align: top; }
				.tfsc-diagnostic-table details { min-width: 150px; }
				.tfsc-diagnostic-table summary { cursor: pointer; font-weight: 600; color: #2271b1; }
				.tfsc-diagnostic-table pre { max-width: min(980px, 75vw); max-height: 520px; overflow: auto; padding: 12px; white-space: pre-wrap; overflow-wrap: anywhere; background: #1d2327; color: #f6f7f7; border-radius: 4px; }
				.tfsc-diagnostic-url { display: block; max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
				@media (max-width: 782px) {
					.tfsc-overview, .tfsc-outbox-counts { grid-template-columns: 1fr 1fr; }
					.tfsc-form-toolbar { top: 46px; flex-direction: column; align-items: stretch; }
					.tfsc-form-toolbar__left { align-items: stretch; flex-direction: column; }
					.tfsc-form-card__summary { grid-template-columns: 1fr; }
					.tfsc-form-card__badges { grid-column: 1; grid-row: 3; justify-content: flex-start; padding-left: 28px; }
					.tfsc-form-settings { grid-template-columns: 1fr; }
					.tfsc-picker-item { grid-template-columns: 1fr; }
				}
			</style>
			<h1>TFSC Form Bridge</h1>
			<nav class="nav-tab-wrapper" aria-label="TFSC Form Bridge onderdelen">
				<a class="nav-tab <?php echo 'forms' === $active_tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'tools.php?page=tfsc-form-bridge&tab=forms' ) ); ?>">Formulieren</a>
				<a class="nav-tab <?php echo 'diagnostics' === $active_tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'tools.php?page=tfsc-form-bridge&tab=diagnostics' ) ); ?>">Diagnostics</a>
			</nav>

			<?php foreach ( $messages as $message ) : ?>
				<div class="notice notice-<?php echo esc_attr( $message[0] ); ?> is-dismissible"><p><?php echo esc_html( $message[1] ); ?></p></div>
			<?php endforeach; ?>

			<?php if ( 'diagnostics' === $active_tab ) : ?>
				<?php $this->render_diagnostics(); ?>
			</div>
				<?php return; ?>
			<?php endif; ?>

			<p class="tfsc-bridge__intro">
				Elementor Pro- en Bricks-formulieren worden automatisch gevonden. Nieuwe formulieren staan standaard uit.
				Alleen ingeschakelde formulieren worden in de lokale outbox opgenomen. Aflevering start uitsluitend wanneer de beveiligde ontvanger en het gedeelde geheim in de serverconfiguratie staan.
			</p>
			<div class="tfsc-overview" aria-label="Formulieroverzicht">
				<div class="tfsc-overview__item"><span class="tfsc-overview__value"><?php echo esc_html( count( $forms ) ); ?></span><span class="tfsc-overview__label">gevonden formulieren</span></div>
				<div class="tfsc-overview__item"><span class="tfsc-overview__value"><?php echo esc_html( $configured_forms ); ?></span><span class="tfsc-overview__label">ingericht</span></div>
				<div class="tfsc-overview__item"><span class="tfsc-overview__value"><?php echo esc_html( $active_forms ); ?></span><span class="tfsc-overview__label">actieve koppelingen</span></div>
			</div>

			<?php $this->render_status(); ?>

			<dialog class="tfsc-form-picker" id="tfsc-form-picker" aria-labelledby="tfsc-form-picker-title">
				<div class="tfsc-form-picker__header">
					<div>
						<h2 id="tfsc-form-picker-title">Nieuwe koppeling</h2>
						<p>Kies een bestaand Elementor- of Bricks-formulier om in te richten.</p>
					</div>
					<button class="button tfsc-form-picker__close" type="button" aria-label="Sluiten">×</button>
				</div>
				<div class="tfsc-form-picker__body">
					<label class="screen-reader-text" for="tfsc-picker-search">Beschikbare formulieren zoeken</label>
					<input class="regular-text tfsc-picker-search" id="tfsc-picker-search" type="search" placeholder="Zoek op formulier of pagina…" autocomplete="off">
					<div class="tfsc-picker-list">
					<?php foreach ( $forms as $form_key => $form ) : ?>
						<?php
						$token   = sha1( $form_key );
						$current = isset( $mappings[ $form_key ] ) && is_array( $mappings[ $form_key ] ) ? $mappings[ $form_key ] : array();
						if ( ! empty( $current['form_type'] ) ) {
							continue;
						}
						$field_count = isset( $form['fields'] ) && is_array( $form['fields'] ) ? count( $form['fields'] ) : 0;
						$picker_search = strtolower( $form['form_name'] . ' ' . $form['builder'] . ' ' . $form['post_title'] );
						?>
						<div class="tfsc-picker-item" data-search="<?php echo esc_attr( $picker_search ); ?>">
							<span>
								<span class="tfsc-picker-item__title"><?php echo esc_html( $form['form_name'] ); ?></span>
								<span class="tfsc-picker-item__meta"><?php echo esc_html( ucfirst( $form['builder'] ) . ' · ' . $form['post_title'] . ' · ' . $field_count . ' velden' ); ?></span>
							</span>
							<button class="button tfsc-picker-select" type="button" data-card="tfsc-form-<?php echo esc_attr( $token ); ?>">Koppeling maken</button>
						</div>
					<?php endforeach; ?>
					</div>
					<p class="tfsc-picker-empty">Geen beschikbare formulieren gevonden.</p>
				</div>
			</dialog>

			<form method="post">
				<?php wp_nonce_field( 'tfsc_form_bridge_save', 'tfsc_form_bridge_nonce' ); ?>
				<input type="hidden" name="tfsc_form_bridge_action" value="save">
				<div class="tfsc-form-toolbar">
					<div class="tfsc-form-toolbar__left">
						<button class="button" id="tfsc-add-connection" type="button">Nieuwe koppeling</button>
						<label class="screen-reader-text" for="tfsc-form-search">Koppelingen zoeken</label>
						<input class="regular-text tfsc-form-search" id="tfsc-form-search" type="search" placeholder="Zoek in ingerichte koppelingen…" autocomplete="off">
					</div>
					<button class="button button-primary" type="submit">Wijzigingen opslaan</button>
				</div>

				<?php if ( empty( $forms ) ) : ?>
					<div class="notice notice-warning inline"><p>Er zijn geen gepubliceerde Elementor Pro- of Bricks-formulieren gevonden.</p></div>
				<?php endif; ?>

				<div class="tfsc-form-list">
				<?php foreach ( $forms as $form_key => $form ) : ?>
					<?php
					$token              = sha1( $form_key );
					$current            = isset( $mappings[ $form_key ] ) && is_array( $mappings[ $form_key ] ) ? $mappings[ $form_key ] : array();
					$form_type          = isset( $current['form_type'] ) ? $current['form_type'] : '';
					$form_type_label    = isset( $form_types[ $form_type ] ) ? $form_types[ $form_type ] : 'Nog niet ingericht';
					$is_enabled         = ! empty( $current['enabled'] );
					$version            = isset( $current['version'] ) ? (int) $current['version'] : 0;
					$field_count        = isset( $form['fields'] ) && is_array( $form['fields'] ) ? count( $form['fields'] ) : 0;
					$search_text        = strtolower( $form['form_name'] . ' ' . $form['builder'] . ' ' . $form['post_title'] . ' ' . $form_type_label );
					$actions_configured = array_key_exists( 'create_candidate', $current ) || array_key_exists( 'create_company', $current );
					$defaults           = $this->targets->form_type_defaults( $form_type );
					$missing_sources    = MappingRepository::missing_sources( $current, isset( $form['fields'] ) && is_array( $form['fields'] ) ? $form['fields'] : array() );
					?>
					<details class="tfsc-form-card" id="tfsc-form-<?php echo esc_attr( $token ); ?>" data-configured="<?php echo '' !== $form_type ? '1' : '0'; ?>" data-search="<?php echo esc_attr( $search_text ); ?>" <?php echo '' === $form_type ? 'hidden' : ''; ?>>
						<summary class="tfsc-form-card__summary">
							<span class="tfsc-form-card__identity">
								<span class="tfsc-form-card__title"><?php echo esc_html( $form['form_name'] ); ?></span>
								<span class="tfsc-form-card__meta"><?php echo esc_html( ucfirst( $form['builder'] ) . ' · ' . $form['post_title'] ); ?></span>
							</span>
							<span class="tfsc-form-card__badges">
								<span class="tfsc-form-badge <?php echo $is_enabled ? 'tfsc-form-badge--on' : 'tfsc-form-badge--off'; ?>" data-role="enabled-badge"><?php echo esc_html( $is_enabled ? 'Actief' : 'Uit' ); ?></span>
								<span class="tfsc-form-badge" data-role="type-badge"><?php echo esc_html( $form_type_label ); ?></span>
								<?php if ( ! empty( $missing_sources ) ) : ?><span class="tfsc-form-badge tfsc-form-badge--warning">Mapping controleren</span><?php endif; ?>
								<span class="tfsc-form-badge"><?php echo esc_html( $field_count ); ?> velden</span>
								<span class="tfsc-form-badge">Versie <?php echo esc_html( $version ); ?></span>
							</span>
						</summary>
						<div class="tfsc-form-card__body">
							<input type="hidden" name="forms[<?php echo esc_attr( $token ); ?>][form_key]" value="<?php echo esc_attr( $form_key ); ?>">
							<div class="tfsc-form-settings">
							<p>
								<label>
									<input class="tfsc-form-enabled" type="checkbox" name="forms[<?php echo esc_attr( $token ); ?>][enabled]" value="1" <?php checked( $is_enabled ); ?>>
									<strong>Koppeling actief</strong>
								</label>
								<br><small>Alleen een actieve koppeling neemt nieuwe inzendingen op in de lokale outbox.</small>
							</p>
							<p>
								<label for="tfsc-type-<?php echo esc_attr( $token ); ?>"><strong>Soort formulier</strong></label><br>
								<select class="tfsc-form-type" data-configured="<?php echo $actions_configured ? '1' : '0'; ?>" data-token="<?php echo esc_attr( $token ); ?>" id="tfsc-type-<?php echo esc_attr( $token ); ?>" name="forms[<?php echo esc_attr( $token ); ?>][form_type]">
									<option value="">— kies eerst het doel —</option>
									<?php foreach ( $form_types as $type_key => $type_label ) : ?>
										<?php $type_defaults = $this->targets->form_type_defaults( $type_key ); ?>
										<option value="<?php echo esc_attr( $type_key ); ?>" data-create-candidate="<?php echo $type_defaults['create_candidate'] ? '1' : '0'; ?>" data-create-company="<?php echo $type_defaults['create_company'] ? '1' : '0'; ?>" <?php selected( $form_type, $type_key ); ?>><?php echo esc_html( $type_label ); ?></option>
									<?php endforeach; ?>
								</select>
							</p>
							<div class="tfsc-form-actions">
								<label>
									<input class="tfsc-create-candidate" data-token="<?php echo esc_attr( $token ); ?>" type="checkbox" name="forms[<?php echo esc_attr( $token ); ?>][create_candidate]" value="1" <?php checked( $actions_configured ? ! empty( $current['create_candidate'] ) : ! empty( $defaults['create_candidate'] ) ); ?>>
									<strong>Kandidaatprofiel aanmaken</strong>
								</label>
								<label>
									<input class="tfsc-create-company" data-token="<?php echo esc_attr( $token ); ?>" type="checkbox" name="forms[<?php echo esc_attr( $token ); ?>][create_company]" value="1" <?php checked( $actions_configured ? ! empty( $current['create_company'] ) : ! empty( $defaults['create_company'] ) ); ?>>
									<strong>Nieuw bedrijf en bedrijfscontact aanmaken</strong>
								</label>
							</div>
							<p><a href="<?php echo esc_url( $form['edit_url'] ); ?>">Open dit formulier in Elementor</a></p>
							</div>
							<p><small>Beide aanmaakacties zijn per formulier uit te schakelen. Bestaande matches worden nooit blind gedupliceerd.</small></p>

							<?php if ( ! empty( $missing_sources ) ) : ?>
								<div class="tfsc-mapping-warning" role="alert">
									<strong>Veld-ID gewijzigd of verwijderd.</strong>
									De opgeslagen bron<?php echo 1 === count( $missing_sources ) ? '' : 'nen'; ?>
									<?php foreach ( $missing_sources as $index => $missing_source ) : ?><?php echo $index ? ', ' : ''; ?><code><?php echo esc_html( $missing_source ); ?></code><?php endforeach; ?>
									<?php echo 1 === count( $missing_sources ) ? 'bestaat' : 'bestaan'; ?> niet meer in dit formulier. Een nieuw veld wordt nooit automatisch gekoppeld; kies hieronder zelf de juiste CRM-bestemming en sla opnieuw op.
								</div>
							<?php endif; ?>

							<table class="widefat striped tfsc-field-table">
								<thead><tr><th>Formulierveld</th><th>Type</th><th>CRM-bestemming</th></tr></thead>
								<tbody>
								<?php foreach ( $form['fields'] as $field_id => $field ) : ?>
									<?php
									$selected  = isset( $current['field_map'][ $field_id ] ) ? $current['field_map'][ $field_id ] : '';
									$suggested = $this->targets->suggested_target( $field_id, $field['type'], isset( $current['form_type'] ) ? $current['form_type'] : '' );
									?>
									<tr>
										<td><strong><?php echo esc_html( $field['label'] ); ?></strong><br><code><?php echo esc_html( $field_id ); ?></code><?php echo ! empty( $field['required'] ) ? ' — verplicht' : ''; ?></td>
										<td><?php echo esc_html( $field['type'] ); ?></td>
										<td>
											<select name="forms[<?php echo esc_attr( $token ); ?>][field_map][<?php echo esc_attr( $field_id ); ?>]">
												<option value="not_sent">Niet versturen</option>
												<?php foreach ( $targets as $group => $group_targets ) : ?>
													<optgroup label="<?php echo esc_attr( $group ); ?>">
													<?php foreach ( $group_targets as $target_key => $target ) : ?>
														<option value="<?php echo esc_attr( $target_key ); ?>" <?php selected( $selected, $target_key ); ?>><?php echo esc_html( $target['label'] ); ?></option>
													<?php endforeach; ?>
													</optgroup>
												<?php endforeach; ?>
											</select>
											<?php if ( '' !== $suggested && '' === $selected ) : ?>
												<br><small>Suggestie: <?php echo esc_html( $this->targets->get( $suggested )['label'] ); ?> — wordt niet automatisch gekozen.</small>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</details>
				<?php endforeach; ?>
				</div>
				<div class="tfsc-empty-state" <?php echo $configured_forms ? 'hidden' : ''; ?>>
					<h2>Nog geen formulierkoppelingen ingericht</h2>
					<p>Kies via <strong>Nieuwe koppeling</strong> welk bestaand formulier je als eerste wilt instellen.</p>
					<button class="button button-primary" type="button" data-open-picker="1">Nieuwe koppeling</button>
				</div>
				<p class="tfsc-no-results" role="status">Geen formulieren gevonden met deze zoekopdracht.</p>

				<div class="tfsc-form-footer">
					<?php submit_button( 'Wijzigingen opslaan', 'primary', 'submit', false ); ?>
					<span><span data-role="configured-count"><?php echo esc_html( $configured_forms ); ?></span> koppelingen ingericht · <?php echo esc_html( count( $forms ) ); ?> bronformulieren gevonden</span>
				</div>
			</form>
			<script>
			(function () {
				var cards = Array.prototype.slice.call(document.querySelectorAll('.tfsc-form-card'));
				var search = document.getElementById('tfsc-form-search');
				var noResults = document.querySelector('.tfsc-no-results');
				var emptyState = document.querySelector('.tfsc-empty-state');
				var picker = document.getElementById('tfsc-form-picker');
				var pickerSearch = document.getElementById('tfsc-picker-search');
				var pickerItems = Array.prototype.slice.call(document.querySelectorAll('.tfsc-picker-item'));
				var pickerEmpty = document.querySelector('.tfsc-picker-empty');

				function openPicker() {
					pickerSearch.value = '';
					var available = 0;
					pickerItems.forEach(function (item) {
						var selected = item.dataset.selected === '1';
						item.hidden = selected;
						available += selected ? 0 : 1;
					});
					pickerEmpty.style.display = available ? 'none' : 'block';
					if (typeof picker.showModal === 'function') {
						picker.showModal();
					} else {
						picker.setAttribute('open', 'open');
					}
					pickerSearch.focus();
				}

				function closePicker() {
					if (typeof picker.close === 'function') {
						picker.close();
					} else {
						picker.removeAttribute('open');
					}
				}

				document.getElementById('tfsc-add-connection').addEventListener('click', openPicker);
				document.querySelectorAll('[data-open-picker="1"]').forEach(function (button) {
					button.addEventListener('click', openPicker);
				});
				picker.querySelector('.tfsc-form-picker__close').addEventListener('click', closePicker);
				picker.addEventListener('click', function (event) {
					if (event.target === picker) {
						closePicker();
					}
				});

				pickerItems.forEach(function (item) {
					item.querySelector('.tfsc-picker-select').addEventListener('click', function (event) {
						var card = document.getElementById(event.currentTarget.dataset.card);
						card.hidden = false;
						card.dataset.configured = 'draft';
						card.open = true;
						item.dataset.selected = '1';
						item.hidden = true;
						emptyState.hidden = true;
						search.value = '';
						closePicker();
						card.scrollIntoView({ behavior: 'smooth', block: 'start' });
					});
				});

				pickerSearch.addEventListener('input', function () {
					var query = pickerSearch.value.trim().toLowerCase();
					var visible = 0;
					pickerItems.forEach(function (item) {
						var available = item.dataset.selected !== '1';
						var matches = available && (!query || item.dataset.search.indexOf(query) !== -1);
						item.hidden = !matches;
						visible += matches ? 1 : 0;
					});
					pickerEmpty.style.display = visible ? 'none' : 'block';
				});

				cards.forEach(function (card) {
					card.addEventListener('toggle', function () {
						if (!card.open) {
							return;
						}
						cards.forEach(function (otherCard) {
							if (otherCard !== card) {
								otherCard.open = false;
							}
						});
					});

					var enabled = card.querySelector('.tfsc-form-enabled');
					var enabledBadge = card.querySelector('[data-role="enabled-badge"]');
					enabled.addEventListener('change', function () {
						enabledBadge.textContent = enabled.checked ? 'Actief' : 'Uit';
						enabledBadge.classList.toggle('tfsc-form-badge--on', enabled.checked);
						enabledBadge.classList.toggle('tfsc-form-badge--off', !enabled.checked);
					});
				});

				document.querySelectorAll('.tfsc-form-type').forEach(function (select) {
					select.addEventListener('change', function () {
						var option = select.options[select.selectedIndex];
						var card = select.closest('.tfsc-form-card');
						var typeBadge = card.querySelector('[data-role="type-badge"]');
						typeBadge.textContent = select.value ? option.textContent : 'Nog niet ingericht';

						if (select.dataset.configured === '1') {
							return;
						}
						var token = select.dataset.token;
						var candidate = document.querySelector('.tfsc-create-candidate[data-token="' + token + '"]');
						var company = document.querySelector('.tfsc-create-company[data-token="' + token + '"]');
						candidate.checked = option.dataset.createCandidate === '1';
						company.checked = option.dataset.createCompany === '1';
					});
				});

				search.addEventListener('input', function () {
					var query = search.value.trim().toLowerCase();
					var visible = 0;
					var available = 0;
					cards.forEach(function (card) {
						var configured = card.dataset.configured !== '0';
						var matches = configured && (!query || card.dataset.search.indexOf(query) !== -1);
						card.hidden = !matches;
						available += configured ? 1 : 0;
						visible += matches ? 1 : 0;
					});
					noResults.style.display = available && !visible ? 'block' : 'none';
				});
			}());
			</script>

			<form method="post" style="margin-top:24px">
				<?php wp_nonce_field( 'tfsc_form_bridge_save', 'tfsc_form_bridge_nonce' ); ?>
				<input type="hidden" name="tfsc_form_bridge_action" value="refresh">
				<?php submit_button( 'Formulieren opnieuw inlezen', 'secondary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	private function save_posted_mappings() {
		$posted_forms = isset( $_POST['forms'] ) && is_array( $_POST['forms'] ) ? wp_unslash( $_POST['forms'] ) : array();
		$messages     = array();
		$saved        = 0;

		foreach ( $posted_forms as $posted ) {
			if ( ! is_array( $posted ) || empty( $posted['form_key'] ) ) {
				continue;
			}

			$form_key  = (string) $posted['form_key'];
			$form_type = isset( $posted['form_type'] ) ? sanitize_key( $posted['form_type'] ) : '';
			$enabled   = ! empty( $posted['enabled'] );
			$actions   = array(
				'create_candidate' => ! empty( $posted['create_candidate'] ),
				'create_company'   => ! empty( $posted['create_company'] ),
			);
			$field_map = isset( $posted['field_map'] ) && is_array( $posted['field_map'] ) ? $posted['field_map'] : array();

			if ( '' === $form_type ) {
				if ( $enabled || array_filter( $field_map, static function ( $target ) { return is_scalar( $target ) && 'not_sent' !== $target; } ) ) {
					$messages[] = array( 'error', 'Een formulier met gekozen velden mist nog het formuliertype en is niet opgeslagen.' );
				}
				continue;
			}

			$result = $this->mappings->save( $form_key, $form_type, $enabled, $field_map, $actions );
			if ( is_wp_error( $result ) ) {
				$messages[] = array( 'error', $result->get_error_message() );
			} else {
				++$saved;
			}
		}

		if ( $saved ) {
			$messages[] = array( 'success', sprintf( '%d formuliermapping(s) opgeslagen.', $saved ) );
		}

		return $messages;
	}

	private function grouped_targets() {
		$groups = array();
		foreach ( $this->targets->targets() as $key => $target ) {
			$groups[ $target['group'] ][ $key ] = $target;
		}
		return $groups;
	}

	private function render_status() {
		$counts              = $this->outbox->counts();
		$recent              = $this->outbox->recent( 20 );
		$receiver_configured = DeliveryWorker::is_configured();
		$backblaze_configured = BackblazeClient::is_configured();
		?>
		<section class="tfsc-status-panel" aria-labelledby="tfsc-outbox-title">
			<h2 id="tfsc-outbox-title">Lokale outbox</h2>
			<div class="tfsc-status-row">
				<span>Ontvanger <span class="tfsc-status-pill <?php echo $receiver_configured ? 'tfsc-status-pill--on' : 'tfsc-status-pill--off'; ?>"><?php echo esc_html( $receiver_configured ? 'Geconfigureerd' : 'Niet geconfigureerd' ); ?></span></span>
				<span>Backblaze <span class="tfsc-status-pill <?php echo $backblaze_configured ? 'tfsc-status-pill--on' : 'tfsc-status-pill--off'; ?>"><?php echo esc_html( $backblaze_configured ? 'Geconfigureerd' : 'Niet geconfigureerd' ); ?></span></span>
				<form method="post" style="margin:0">
					<?php wp_nonce_field( 'tfsc_form_bridge_save', 'tfsc_form_bridge_nonce' ); ?>
					<input type="hidden" name="tfsc_form_bridge_action" value="test_connection">
					<button class="button" type="submit" <?php disabled( ! $receiver_configured ); ?>>Verbinding testen</button>
				</form>
				<form method="post" style="margin:0">
					<?php wp_nonce_field( 'tfsc_form_bridge_save', 'tfsc_form_bridge_nonce' ); ?>
					<input type="hidden" name="tfsc_form_bridge_action" value="process_outbox">
					<button class="button" type="submit" <?php disabled( ! $receiver_configured ); ?>>Wachtrij nu verwerken</button>
				</form>
			</div>
			<div class="tfsc-outbox-counts">
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['pending'] ) ? $counts['pending'] : 0 ); ?></strong>Wachtend</div>
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['review'] ) ? $counts['review'] : 0 ); ?></strong>Handmatige controle</div>
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['delivered'] ) ? $counts['delivered'] : 0 ); ?></strong>Afgeleverd</div>
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['failed'] ) ? $counts['failed'] : 0 ); ?></strong>Mislukt</div>
			</div>
		<?php if ( ! empty( $recent ) ) : ?>
			<table class="widefat striped" style="margin-top:16px">
				<thead><tr><th>Tijd (UTC)</th><th>E-mail</th><th>Bouwer</th><th>Formuliertype</th><th>Status</th><th>Pogingen</th><th>Foutcode</th></tr></thead>
				<tbody>
				<?php foreach ( $recent as $row ) : ?>
					<tr>
						<td><?php echo esc_html( $row['created_at'] ); ?></td>
						<td><?php echo esc_html( $row['email'] ); ?></td>
						<td><?php echo esc_html( $row['builder'] ); ?></td>
						<td><?php echo esc_html( $row['form_type'] ); ?></td>
						<td><?php echo esc_html( $row['status'] ); ?></td>
						<td><?php echo esc_html( $row['attempts'] ); ?></td>
						<td><?php echo esc_html( $row['last_error_code'] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p><small>Het e-mailadres wordt getoond om inzendingen snel te kunnen herkennen; overige formulierinhoud staat in Diagnostics.</small></p>
		<?php endif; ?>
		</section>
		<?php
	}

	private function render_diagnostics() {
		$counts = $this->diagnostics->counts();
		$recent = $this->diagnostics->recent( 50 );
		$retention = absint( get_option( DiagnosticRepository::RETENTION_OPTION, DiagnosticRepository::DEFAULT_RETENTION_DAYS ) );
		$max_records = absint( get_option( DiagnosticRepository::MAX_RECORDS_OPTION, DiagnosticRepository::DEFAULT_MAX_RECORDS ) );
		?>
		<section class="tfsc-status-panel" aria-labelledby="tfsc-diagnostics-title">
			<h2 id="tfsc-diagnostics-title">Formulierdiagnostiek</h2>
			<p>
				Hier zie je ook Elementor-fouten die optreden vóórdat een inzending in de Form Bridge-outbox komt.
				Voor volledige foutanalyse bewaart dit log de ingevulde formulierwaarden, IP- en proxygegevens, browserinformatie,
				pagina en vorige pagina, navigatiegegevens, uploadmetadata, serveromgeving, ruwe response en eventuele PHP-foutdetails.
				Authenticatiecookies, wachtwoorden, nonces, API-sleutels en andere geheimen worden niet vastgelegd.
			</p>
			<div class="tfsc-diagnostic-actions">
				<form method="post">
					<?php wp_nonce_field( 'tfsc_form_bridge_save', 'tfsc_form_bridge_nonce' ); ?>
					<input type="hidden" name="tfsc_form_bridge_action" value="save_diagnostic_settings">
					<label for="tfsc-diagnostic-retention">Bewaartermijn</label>
					<select id="tfsc-diagnostic-retention" name="diagnostic_retention_days">
						<option value="7" <?php selected( $retention, 7 ); ?>>7 dagen</option>
						<option value="30" <?php selected( $retention, 30 ); ?>>30 dagen</option>
						<option value="90" <?php selected( $retention, 90 ); ?>>90 dagen</option>
						<option value="180" <?php selected( $retention, 180 ); ?>>180 dagen</option>
						<option value="365" <?php selected( $retention, 365 ); ?>>365 dagen</option>
					</select>
					<label for="tfsc-diagnostic-max-records">Maximumaantal regels</label>
					<select id="tfsc-diagnostic-max-records" name="diagnostic_max_records">
						<?php foreach ( DiagnosticRepository::allowed_max_records() as $allowed_max ) : ?>
							<option value="<?php echo esc_attr( $allowed_max ); ?>" <?php selected( $max_records, $allowed_max ); ?>><?php echo esc_html( number_format_i18n( $allowed_max ) ); ?></option>
						<?php endforeach; ?>
					</select>
					<button class="button button-primary" type="submit">Bewaartermijn opslaan</button>
				</form>
				<form method="post" onsubmit="return window.confirm('Weet je zeker dat je alle diagnostische logregels definitief wilt verwijderen?');">
					<?php wp_nonce_field( 'tfsc_form_bridge_save', 'tfsc_form_bridge_nonce' ); ?>
					<input type="hidden" name="tfsc_form_bridge_action" value="clear_diagnostics">
					<button class="button" type="submit">Log volledig leegmaken</button>
				</form>
			</div>
			<div class="tfsc-outbox-counts">
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['started'] ) ? $counts['started'] : 0 ); ?></strong>Gestart</div>
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['succeeded'] ) ? $counts['succeeded'] : 0 ); ?></strong>Geslaagd</div>
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['failed'] ) ? $counts['failed'] : 0 ); ?></strong>Mislukt</div>
				<div class="tfsc-outbox-count"><strong><?php echo esc_html( isset( $counts['fatal'] ) ? $counts['fatal'] : 0 ); ?></strong>Fatale fout</div>
			</div>
			<?php if ( empty( $recent ) ) : ?>
				<p><em>Er zijn nog geen diagnostische formulierverzoeken geregistreerd.</em></p>
			<?php else : ?>
				<table class="widefat striped tfsc-diagnostic-table" style="margin-top:16px">
					<thead><tr><th>Tijd</th><th>E-mail</th><th>Status</th><th>Formulier</th><th>Bezoeker</th><th>Pagina</th><th>Technisch</th><th>Volledige log</th></tr></thead>
					<tbody>
					<?php foreach ( $recent as $row ) : ?>
						<?php
						$error_fields = json_decode( isset( $row['error_fields'] ) ? $row['error_fields'] : '[]', true );
						$upload_errors = json_decode( isset( $row['upload_error_codes'] ) ? $row['upload_error_codes'] : '[]', true );
						$local_time = function_exists( 'get_date_from_gmt' ) ? get_date_from_gmt( $row['created_at'], 'Y-m-d H:i:s' ) : $row['created_at'] . ' UTC';
						$decode = static function ( $value ) {
							$decoded = json_decode( (string) $value, true );
							return is_array( $decoded ) ? $decoded : $value;
						};
						$details = array(
							'request_uuid'     => $row['request_uuid'],
							'submission_uuid'  => $row['submission_uuid'],
							'outbox'           => array( 'id' => $row['outbox_id'], 'status' => $row['outbox_status'] ),
							'timestamps'       => array( 'created_utc' => $row['created_at'], 'updated_utc' => $row['updated_at'], 'local' => $local_time, 'duration_ms' => $row['duration_ms'] ),
							'form'             => array( 'builder' => $row['builder'], 'key' => $row['form_key'], 'type' => $row['form_type'] ),
							'result'           => array( 'source' => $row['source'], 'stage' => $row['stage'], 'status' => $row['status'], 'http_status' => $row['http_status'], 'error_code' => $row['error_code'], 'error_fields' => $error_fields ),
							'visitor'          => array( 'ip_and_proxies' => $row['client_ip'], 'browser' => $row['browser_summary'], 'user_agent' => $row['user_agent'] ),
							'location'         => array( 'form_page' => $row['page_url'], 'previous_page' => $row['previous_url'] ),
							'request'          => $decode( $row['request_data'] ),
							'uploads'          => $decode( $row['upload_details'] ),
							'response_body'    => $row['response_body'],
							'php_fatal'        => $decode( $row['fatal_data'] ),
							'environment'      => $decode( $row['environment_data'] ),
						);
						$details_json = wp_json_encode( $details, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
						?>
						<tr>
							<td><?php echo esc_html( $local_time ); ?></td>
							<td><?php echo esc_html( $row['email'] ); ?></td>
							<td><strong><?php echo esc_html( $row['status'] ); ?></strong><br><small><?php echo esc_html( $row['stage'] ); ?> · <?php echo esc_html( $row['source'] ); ?></small></td>
							<td><strong><?php echo esc_html( $row['form_type'] ); ?></strong><br><small><?php echo esc_html( $row['form_key'] ); ?></small></td>
							<td><strong><?php echo esc_html( $row['browser_summary'] ); ?></strong><br><small><?php echo esc_html( $row['client_ip'] ); ?></small></td>
							<td>
								<?php if ( ! empty( $row['page_url'] ) ) : ?><a class="tfsc-diagnostic-url" href="<?php echo esc_url( $row['page_url'] ); ?>" target="_blank" rel="noreferrer">Formulierpagina</a><?php endif; ?>
								<?php if ( ! empty( $row['previous_url'] ) ) : ?><a class="tfsc-diagnostic-url" href="<?php echo esc_url( $row['previous_url'] ); ?>" target="_blank" rel="noreferrer">Vorige pagina</a><?php endif; ?>
							</td>
							<td>
								HTTP <?php echo esc_html( $row['http_status'] ); ?> · <?php echo esc_html( null === $row['duration_ms'] ? '–' : $row['duration_ms'] . ' ms' ); ?><br>
								<small><?php echo esc_html( $row['error_code'] ); ?><?php echo ! empty( $error_fields ) ? esc_html( ' · velden: ' . implode( ', ', $error_fields ) ) : ''; ?></small><br>
								<small><?php echo esc_html( (int) $row['upload_count'] . ' upload(s), ' . size_format( (int) $row['upload_bytes'] ) ); ?><?php echo ! empty( $upload_errors ) ? esc_html( ' · PHP: ' . implode( ', ', $upload_errors ) ) : ''; ?></small>
							</td>
							<td><details><summary>Open details</summary><pre><?php echo esc_html( false === $details_json ? '{}' : $details_json ); ?></pre></details></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</section>
		<?php
	}
}
