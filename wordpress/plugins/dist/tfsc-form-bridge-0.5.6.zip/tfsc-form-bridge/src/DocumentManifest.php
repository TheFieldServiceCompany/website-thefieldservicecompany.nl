<?php

namespace TFSC\FormBridge;

/**
 * Builds stable document identities without putting a person's name in B2 keys.
 */
final class DocumentManifest {
	public static function from_envelope( array $envelope ) {
		$submission_id = isset( $envelope['submission_id'] ) ? (string) $envelope['submission_id'] : '';
		$files         = isset( $envelope['files'] ) && is_array( $envelope['files'] ) ? $envelope['files'] : array();
		$targets       = isset( $envelope['file_targets'] ) && is_array( $envelope['file_targets'] ) ? $envelope['file_targets'] : array();
		$documents     = array();

		if ( ! self::is_uuid( $submission_id ) ) {
			return array();
		}

		foreach ( $files as $field_id => $field_files ) {
			$target = isset( $targets[ $field_id ] ) ? (string) $targets[ $field_id ] : '';
			if ( ! in_array( $target, array( 'candidate.cv_files', 'company.vacancy_files' ), true ) ) {
				continue;
			}

			foreach ( (array) $field_files as $index => $file ) {
				if ( ! is_array( $file ) ) {
					continue;
				}

				$name = isset( $file['name'] ) ? sanitize_file_name( $file['name'] ) : '';
				$path = isset( $file['path'] ) ? wp_normalize_path( (string) $file['path'] ) : '';
				$url  = isset( $file['url'] ) ? esc_url_raw( (string) $file['url'] ) : '';
				$ext  = sanitize_key( strtolower( pathinfo( $name ? $name : ( $path ? $path : wp_parse_url( $url, PHP_URL_PATH ) ), PATHINFO_EXTENSION ) ) );

				if ( '' === $path && '' === $url ) {
					continue;
				}

				$identity    = $target . '|' . sanitize_key( $field_id ) . '|' . (int) $index;
				$document_id = self::uuid_v5( $submission_id, $identity );
				$documents[] = array(
					'submission_id'    => $submission_id,
					'upload_proof'     => isset( $file['upload_proof'] ) ? (string) $file['upload_proof'] : '',
					'document_id'      => $document_id,
					'target'           => $target,
					'source_field'     => sanitize_key( $field_id ),
					'source_index'     => (int) $index,
					'original_filename' => $name ? $name : 'document.' . $ext,
					'extension'        => $ext,
					'object_key'       => 'documents/' . $document_id . '/v1/original.' . ( $ext ? $ext : 'bin' ),
					'local_path'       => $path,
					'local_url'        => $url,
					'status'           => 'pending',
				);
			}
		}

		return $documents;
	}

	public static function uuid_v5( $namespace, $name ) {
		$hex = str_replace( '-', '', strtolower( (string) $namespace ) );
		if ( 32 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return '';
		}

		$hash = sha1( hex2bin( $hex ) . (string) $name );
		return sprintf(
			'%08s-%04s-%04x-%04x-%12s',
			substr( $hash, 0, 8 ),
			substr( $hash, 8, 4 ),
			( hexdec( substr( $hash, 12, 4 ) ) & 0x0fff ) | 0x5000,
			( hexdec( substr( $hash, 16, 4 ) ) & 0x3fff ) | 0x8000,
			substr( $hash, 20, 12 )
		);
	}

	private static function is_uuid( $value ) {
		return 1 === preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', (string) $value );
	}
}
