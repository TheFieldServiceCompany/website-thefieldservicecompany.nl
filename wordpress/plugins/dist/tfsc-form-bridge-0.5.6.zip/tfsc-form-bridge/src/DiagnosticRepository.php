<?php

namespace TFSC\FormBridge;

final class DiagnosticRepository {
	const TABLE_SUFFIX = 'tfsc_form_bridge_diagnostics';
	const RETENTION_OPTION = 'tfsc_form_bridge_diagnostic_retention_days';
	const MAX_RECORDS_OPTION = 'tfsc_form_bridge_diagnostic_max_records';
	const CLEANUP_HOOK = 'tfsc_form_bridge_cleanup_diagnostics';
	const DEFAULT_RETENTION_DAYS = 30;
	const DEFAULT_MAX_RECORDS = 5000;
	const CLEANUP_BATCH_SIZE = 500;

	public static function allowed_retention_days() {
		return array( 7, 30, 90, 180, 365 );
	}

	public static function allowed_max_records() {
		return array( 1000, 2500, 5000, 10000, 25000 );
	}

	public function start( array $event ) {
		global $wpdb;

		$request_uuid = isset( $event['request_uuid'] ) ? $this->sanitize_uuid( $event['request_uuid'] ) : '';
		$form_key     = isset( $event['form_key'] ) ? $this->sanitize_form_key( $event['form_key'] ) : '';
		if ( '' === $request_uuid || '' === $form_key ) {
			return false;
		}

		$now   = current_time( 'mysql', true );
		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		$data  = array(
			'request_uuid'       => $request_uuid,
			'builder'            => isset( $event['builder'] ) ? sanitize_key( $event['builder'] ) : '',
			'form_key'           => $form_key,
			'form_type'          => isset( $event['form_type'] ) ? sanitize_key( $event['form_type'] ) : '',
			'source'             => isset( $event['source'] ) ? sanitize_key( $event['source'] ) : 'server',
			'stage'              => isset( $event['stage'] ) ? sanitize_key( $event['stage'] ) : 'request_received',
			'status'             => isset( $event['status'] ) ? sanitize_key( $event['status'] ) : 'started',
			'http_status'        => isset( $event['http_status'] ) ? absint( $event['http_status'] ) : null,
			'error_code'         => isset( $event['error_code'] ) ? sanitize_key( $event['error_code'] ) : null,
			'error_fields'       => $this->encode_list( isset( $event['error_fields'] ) ? $event['error_fields'] : array() ),
			'upload_count'       => isset( $event['upload_count'] ) ? absint( $event['upload_count'] ) : 0,
			'upload_bytes'       => isset( $event['upload_bytes'] ) ? absint( $event['upload_bytes'] ) : 0,
			'upload_error_codes' => $this->encode_integer_list( isset( $event['upload_error_codes'] ) ? $event['upload_error_codes'] : array() ),
			'duration_ms'        => isset( $event['duration_ms'] ) ? absint( $event['duration_ms'] ) : null,
			'client_ip'          => isset( $event['client_ip'] ) ? $this->limit_text( $event['client_ip'], 255 ) : null,
			'page_url'           => isset( $event['page_url'] ) ? $this->limit_text( $event['page_url'], 2048 ) : null,
			'previous_url'       => isset( $event['previous_url'] ) ? $this->limit_text( $event['previous_url'], 2048 ) : null,
			'browser_summary'    => isset( $event['browser_summary'] ) ? $this->limit_text( $event['browser_summary'], 255 ) : null,
			'user_agent'         => isset( $event['user_agent'] ) ? $this->limit_text( $event['user_agent'], 512 ) : null,
			'request_data'       => isset( $event['request_data'] ) ? $this->encode_data( $event['request_data'], 32768 ) : null,
			'upload_details'     => isset( $event['upload_details'] ) ? $this->encode_data( $event['upload_details'], 32768 ) : null,
			'response_body'      => isset( $event['response_body'] ) ? $this->limit_text( $event['response_body'], 16384 ) : null,
			'fatal_data'         => isset( $event['fatal_data'] ) ? $this->encode_data( $event['fatal_data'], 8192 ) : null,
			'environment_data'   => isset( $event['environment_data'] ) ? $this->encode_data( $event['environment_data'], 8192 ) : null,
			'submission_uuid'    => isset( $event['submission_uuid'] ) ? $this->sanitize_uuid( $event['submission_uuid'] ) : null,
			'outbox_id'          => isset( $event['outbox_id'] ) ? absint( $event['outbox_id'] ) : null,
			'outbox_status'      => isset( $event['outbox_status'] ) ? sanitize_key( $event['outbox_status'] ) : null,
			'created_at'         => $now,
			'updated_at'         => $now,
		);

		$result = $wpdb->insert( $table, $data, $this->formats_for( $data ) );
		if ( false !== $result ) {
			$this->trim_to_max_records();
		}

		return false === $result ? false : $request_uuid;
	}

	public function update( $request_uuid, array $changes ) {
		global $wpdb;

		$request_uuid = $this->sanitize_uuid( $request_uuid );
		if ( '' === $request_uuid ) {
			return false;
		}

		$data    = array();
		$formats = array();
		foreach ( array( 'stage', 'status', 'error_code', 'outbox_status' ) as $field ) {
			if ( array_key_exists( $field, $changes ) ) {
				$data[ $field ] = null === $changes[ $field ] ? null : sanitize_key( $changes[ $field ] );
				$formats[]      = '%s';
			}
		}
		if ( array_key_exists( 'http_status', $changes ) ) {
			$data['http_status'] = null === $changes['http_status'] ? null : absint( $changes['http_status'] );
			$formats[]           = '%d';
		}
		if ( array_key_exists( 'error_fields', $changes ) ) {
			$data['error_fields'] = $this->encode_list( $changes['error_fields'] );
			$formats[]            = '%s';
		}
		foreach ( array( 'duration_ms', 'outbox_id' ) as $field ) {
			if ( array_key_exists( $field, $changes ) ) {
				$data[ $field ] = null === $changes[ $field ] ? null : absint( $changes[ $field ] );
				$formats[]      = '%d';
			}
		}
		foreach ( array( 'client_ip' => 255, 'page_url' => 2048, 'previous_url' => 2048, 'browser_summary' => 255, 'user_agent' => 512, 'response_body' => 16384 ) as $field => $limit ) {
			if ( array_key_exists( $field, $changes ) ) {
				$data[ $field ] = null === $changes[ $field ] ? null : $this->limit_text( $changes[ $field ], $limit );
				$formats[]      = '%s';
			}
		}
		foreach ( array( 'request_data' => 32768, 'upload_details' => 32768, 'fatal_data' => 8192, 'environment_data' => 8192 ) as $field => $limit ) {
			if ( array_key_exists( $field, $changes ) ) {
				$data[ $field ] = null === $changes[ $field ] ? null : $this->encode_data( $changes[ $field ], $limit );
				$formats[]      = '%s';
			}
		}
		if ( array_key_exists( 'submission_uuid', $changes ) ) {
			$data['submission_uuid'] = null === $changes['submission_uuid'] ? null : $this->sanitize_uuid( $changes['submission_uuid'] );
			$formats[]               = '%s';
		}

		if ( empty( $data ) ) {
			return false;
		}

		$data['updated_at'] = current_time( 'mysql', true );
		$formats[]          = '%s';
		$table              = $wpdb->prefix . self::TABLE_SUFFIX;

		return false !== $wpdb->update(
			$table,
			$data,
			array( 'request_uuid' => $request_uuid ),
			$formats,
			array( '%s' )
		);
	}

	public function recent( $limit = 50 ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		$limit = max( 1, min( 100, absint( $limit ) ) );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT request_uuid, builder, form_key, form_type, source, stage, status,
					http_status, error_code, error_fields, upload_count, upload_bytes,
					upload_error_codes, duration_ms, client_ip, page_url, previous_url,
					browser_summary, user_agent, request_data, upload_details, response_body,
					fatal_data, environment_data, submission_uuid, outbox_id, outbox_status,
					created_at, updated_at
				FROM {$table}
				ORDER BY id DESC
				LIMIT %d",
				$limit
			),
			ARRAY_A
		);

		foreach ( (array) $rows as &$row ) {
			$request_data = json_decode( isset( $row['request_data'] ) ? $row['request_data'] : '', true );
			$row['email'] = $this->find_email( $request_data );
		}
		unset( $row );

		return $rows;
	}

	private function find_email( $value ) {
		if ( ! is_array( $value ) ) {
			return '';
		}

		foreach ( array( 'email', 'e-mail', 'person.email' ) as $key ) {
			if ( isset( $value[ $key ] ) && is_scalar( $value[ $key ] ) ) {
				$email = sanitize_email( (string) $value[ $key ] );
				if ( '' !== $email ) {
					return $email;
				}
			}
		}

		foreach ( $value as $key => $child ) {
			if ( is_scalar( $child ) && false !== stripos( (string) $key, 'mail' ) ) {
				$email = sanitize_email( (string) $child );
				if ( '' !== $email ) {
					return $email;
				}
			}
			if ( is_array( $child ) ) {
				$email = $this->find_email( $child );
				if ( '' !== $email ) {
					return $email;
				}
			}
		}

		return '';
	}

	public function counts() {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		$rows  = $wpdb->get_results( "SELECT status, COUNT(*) total FROM {$table} GROUP BY status", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$result = array();
		foreach ( (array) $rows as $row ) {
			$result[ $row['status'] ] = (int) $row['total'];
		}
		return $result;
	}

	public function clear() {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		return false !== $wpdb->query( "DELETE FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	public function purge_expired( $limit = self::CLEANUP_BATCH_SIZE ) {
		$days = absint( get_option( self::RETENTION_OPTION, self::DEFAULT_RETENTION_DAYS ) );
		if ( ! in_array( $days, self::allowed_retention_days(), true ) ) {
			return 0;
		}

		global $wpdb;
		$table  = $wpdb->prefix . self::TABLE_SUFFIX;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		$limit = max( 1, min( self::CLEANUP_BATCH_SIZE, absint( $limit ) ) );

		return (int) $wpdb->query(
			$wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s ORDER BY id ASC LIMIT %d", $cutoff, $limit ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	public function trim_to_max_records( $limit = self::CLEANUP_BATCH_SIZE ) {
		global $wpdb;

		$max_records = absint( get_option( self::MAX_RECORDS_OPTION, self::DEFAULT_MAX_RECORDS ) );
		if ( ! in_array( $max_records, self::allowed_max_records(), true ) ) {
			$max_records = self::DEFAULT_MAX_RECORDS;
		}

		$table = $wpdb->prefix . self::TABLE_SUFFIX;
		$cutoff_id = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$table} ORDER BY id DESC LIMIT 1 OFFSET %d", $max_records ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
		if ( ! $cutoff_id ) {
			return 0;
		}

		$limit = max( 1, min( self::CLEANUP_BATCH_SIZE, absint( $limit ) ) );
		return (int) $wpdb->query(
			$wpdb->prepare( "DELETE FROM {$table} WHERE id <= %d ORDER BY id ASC LIMIT %d", absint( $cutoff_id ), $limit ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	public function run_cleanup() {
		$expired = $this->purge_expired();
		$excess  = $this->trim_to_max_records();
		if ( self::CLEANUP_BATCH_SIZE === $expired || self::CLEANUP_BATCH_SIZE === $excess ) {
			wp_schedule_single_event( time() + ( 5 * MINUTE_IN_SECONDS ), self::CLEANUP_HOOK );
		}
		return $expired + $excess;
	}

	private function encode_list( $values ) {
		$clean = array();
		foreach ( (array) $values as $value ) {
			$value = sanitize_key( $value );
			if ( '' !== $value ) {
				$clean[] = $value;
			}
		}
		return wp_json_encode( array_values( array_unique( $clean ) ) );
	}

	private function encode_integer_list( $values ) {
		$clean = array_map( 'absint', (array) $values );
		return wp_json_encode( array_values( array_unique( $clean ) ) );
	}

	private function encode_data( $value, $limit = 32768 ) {
		if ( is_string( $value ) ) {
			return $this->limit_text( $value, $limit );
		}
		$encoded = wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return false === $encoded ? null : $this->limit_text( $encoded, $limit );
	}

	private function limit_text( $value, $limit ) {
		$value = (string) $value;
		return strlen( $value ) > $limit ? substr( $value, 0, $limit ) : $value;
	}

	private function formats_for( array $data ) {
		$integer_fields = array( 'http_status', 'upload_count', 'upload_bytes', 'duration_ms', 'outbox_id' );
		$formats        = array();
		foreach ( array_keys( $data ) as $field ) {
			$formats[] = in_array( $field, $integer_fields, true ) ? '%d' : '%s';
		}
		return $formats;
	}

	private function sanitize_uuid( $value ) {
		$value = strtolower( (string) $value );
		return preg_match( '/^[a-f0-9-]{36}$/', $value ) ? $value : '';
	}

	private function sanitize_form_key( $value ) {
		return preg_replace( '/[^a-zA-Z0-9:_-]/', '', (string) $value );
	}
}
