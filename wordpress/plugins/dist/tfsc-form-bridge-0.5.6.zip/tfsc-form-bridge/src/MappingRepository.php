<?php

namespace TFSC\FormBridge;

final class MappingRepository {
	const OPTION_NAME = 'tfsc_form_bridge_mappings';

	/** @var TargetRegistry */
	private $targets;

	public function __construct( TargetRegistry $targets ) {
		$this->targets = $targets;
	}

	public function all() {
		$value = get_option( self::OPTION_NAME, array() );
		return is_array( $value ) ? $value : array();
	}

	public function get( $form_key ) {
		$all = $this->all();
		return isset( $all[ $form_key ] ) && is_array( $all[ $form_key ] ) ? $all[ $form_key ] : null;
	}

	/**
	 * Returns saved source IDs that no longer exist in the discovered form.
	 *
	 * A renamed Elementor/Bricks field must never be silently remapped. The
	 * replacement field stays on "Niet versturen" until an administrator makes
	 * an explicit choice, while the old ID remains visible as a warning.
	 */
	public static function missing_sources( array $mapping, array $current_fields ) {
		$field_map = isset( $mapping['field_map'] ) && is_array( $mapping['field_map'] )
			? $mapping['field_map']
			: array();
		$missing = array();

		foreach ( array_keys( $field_map ) as $source ) {
			$source = sanitize_key( $source );
			if ( '' !== $source && ! array_key_exists( $source, $current_fields ) ) {
				$missing[] = $source;
			}
		}

		sort( $missing );
		return array_values( array_unique( $missing ) );
	}

	public function save( $form_key, $form_type, $enabled, array $field_map, array $actions = array() ) {
		if ( ! is_scalar( $form_key ) || ! is_scalar( $form_type ) ) {
			return new \WP_Error( 'invalid_mapping_identity', 'Formulier of formuliertype is ongeldig.' );
		}

		$form_key  = $this->sanitize_form_key( $form_key );
		$form_type = sanitize_key( $form_type );

		if ( '' === $form_key || ! $this->targets->has_form_type( $form_type ) ) {
			return new \WP_Error( 'invalid_mapping_identity', 'Formulier of formuliertype is ongeldig.' );
		}

		$clean_map = array();
		foreach ( $field_map as $source => $target ) {
			if ( ! is_scalar( $source ) || ! is_scalar( $target ) ) {
				return new \WP_Error( 'invalid_mapping_target', 'De gekozen CRM-bestemming is niet toegestaan.' );
			}

			$source = sanitize_key( $source );
			$target = sanitize_text_field( $target );

			if ( '' === $source || '' === $target || 'not_sent' === $target ) {
				continue;
			}

			if ( ! $this->targets->has_target( $target ) ) {
				return new \WP_Error( 'invalid_mapping_target', 'De gekozen CRM-bestemming is niet toegestaan.' );
			}

			$clean_map[ $source ] = $target;
		}

		ksort( $clean_map );

		$all      = $this->all();
		$previous = isset( $all[ $form_key ] ) && is_array( $all[ $form_key ] ) ? $all[ $form_key ] : array();
		$version  = isset( $previous['version'] ) ? max( 1, (int) $previous['version'] ) : 0;

		$next = array(
			'form_type'       => $form_type,
			'enabled'         => (bool) $enabled,
			'create_candidate' => ! empty( $actions['create_candidate'] ),
			'create_company'   => ! empty( $actions['create_company'] ),
			'field_map'       => $clean_map,
		);

		$previous_comparable = array(
			'form_type'        => isset( $previous['form_type'] ) ? $previous['form_type'] : '',
			'enabled'          => ! empty( $previous['enabled'] ),
			'create_candidate' => ! empty( $previous['create_candidate'] ),
			'create_company'   => ! empty( $previous['create_company'] ),
			'field_map'        => isset( $previous['field_map'] ) && is_array( $previous['field_map'] ) ? $previous['field_map'] : array(),
		);

		if ( $next !== $previous_comparable ) {
			++$version;
		}

		$next['version']    = max( 1, $version );
		$next['updated_at'] = current_time( 'mysql', true );
		$all[ $form_key ]   = $next;

		update_option( self::OPTION_NAME, $all, false );

		return $next;
	}

	private function sanitize_form_key( $form_key ) {
		return preg_replace( '/[^a-zA-Z0-9:_-]/', '', (string) $form_key );
	}
}
