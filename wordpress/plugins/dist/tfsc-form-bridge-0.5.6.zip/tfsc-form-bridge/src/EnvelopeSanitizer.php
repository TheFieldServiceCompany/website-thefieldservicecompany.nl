<?php

namespace TFSC\FormBridge;

/**
 * Removes local upload references before a form envelope leaves WordPress.
 */
final class EnvelopeSanitizer {
	public static function for_receiver( array $envelope ) {
		$file_field_ids = isset( $envelope['file_targets'] ) && is_array( $envelope['file_targets'] )
			? array_keys( $envelope['file_targets'] )
			: array();
		unset( $envelope['files'], $envelope['file_targets'] );

		if ( isset( $envelope['mapped'] ) && is_array( $envelope['mapped'] ) ) {
			unset( $envelope['mapped']['candidate.cv_files'], $envelope['mapped']['company.vacancy_files'] );
		}

		if ( isset( $envelope['fields'] ) && is_array( $envelope['fields'] ) ) {
			foreach ( $envelope['fields'] as $field_id => $field ) {
				if ( ! is_array( $field ) ) {
					continue;
				}

				$type = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : '';
				if ( in_array( $type, array( 'upload', 'file' ), true ) || in_array( $field_id, $file_field_ids, true ) ) {
					$envelope['fields'][ $field_id ]['value'] = array();
				}
			}
		}

		return $envelope;
	}
}
