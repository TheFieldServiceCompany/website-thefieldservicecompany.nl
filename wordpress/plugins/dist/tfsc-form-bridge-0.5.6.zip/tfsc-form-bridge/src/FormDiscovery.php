<?php

namespace TFSC\FormBridge;

final class FormDiscovery {
	const CACHE_KEY = 'tfsc_form_bridge_forms_v1';

	public function all( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$forms = array_merge( $this->elementor_forms(), $this->bricks_forms() );
		ksort( $forms );
		set_transient( self::CACHE_KEY, $forms, 6 * HOUR_IN_SECONDS );

		return $forms;
	}

	public function invalidate() {
		delete_transient( self::CACHE_KEY );
	}

	private function elementor_forms() {
		global $wpdb;

		$forms = array();
		$sql   = "SELECT DISTINCT p.ID
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm
				ON p.ID = pm.post_id AND pm.meta_key = '_elementor_edit_mode'
			WHERE pm.meta_value = 'builder'
				AND p.post_status = 'publish'";

		$post_ids = $wpdb->get_col( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		foreach ( (array) $post_ids as $post_id ) {
			$data = get_post_meta( (int) $post_id, '_elementor_data', true );
			if ( is_string( $data ) ) {
				$data = json_decode( $data, true );
			}

			if ( is_array( $data ) ) {
				$this->collect_elementor_forms( $data, (int) $post_id, $forms );
			}
		}

		return $forms;
	}

	private function collect_elementor_forms( array $elements, $post_id, array &$forms ) {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			if ( isset( $element['widgetType'] ) && 'form' === $element['widgetType'] ) {
				$widget_id = isset( $element['id'] ) ? sanitize_key( $element['id'] ) : '';
				$settings  = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array();
				$form_name = isset( $settings['form_name'] ) ? sanitize_text_field( $settings['form_name'] ) : 'Naamloos formulier';
				$form_key  = 'elementor:' . $post_id . ':' . $widget_id;

				if ( '' !== $widget_id ) {
					$forms[ $form_key ] = array(
						'key'         => $form_key,
						'builder'     => 'elementor',
						'post_id'     => $post_id,
						'form_id'     => $widget_id,
						'form_name'   => $form_name,
						'post_title'  => get_the_title( $post_id ),
						'edit_url'    => admin_url( 'post.php?post=' . $post_id . '&action=elementor' ),
						'fields'      => $this->elementor_fields( isset( $settings['form_fields'] ) ? $settings['form_fields'] : array() ),
					);
				}
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$this->collect_elementor_forms( $element['elements'], $post_id, $forms );
			}
		}
	}

	private function elementor_fields( $fields ) {
		$result = array();
		foreach ( (array) $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$id = isset( $field['custom_id'] ) ? sanitize_key( $field['custom_id'] ) : '';
			if ( '' === $id ) {
				continue;
			}

			$type  = isset( $field['field_type'] ) ? sanitize_key( $field['field_type'] ) : 'text';
			$label = isset( $field['field_label'] ) && '' !== $field['field_label'] ? $field['field_label'] : $id;

			$result[ $id ] = array(
				'id'       => $id,
				'label'    => wp_strip_all_tags( $label ),
				'type'     => $type,
				'required' => isset( $field['required'] ) && in_array( $field['required'], array( true, 'true', 'yes', '1' ), true ),
			);
		}

		return $result;
	}

	private function bricks_forms() {
		global $wpdb;

		$forms     = array();
		$meta_keys = array( '_bricks_page_content_2', '_bricks_page_footer_2', '_bricks_page_header_2' );
		$in        = implode( ',', array_fill( 0, count( $meta_keys ), '%s' ) );
		$sql       = $wpdb->prepare(
			"SELECT DISTINCT p.ID
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
			WHERE p.post_status = 'publish' AND pm.meta_key IN ({$in})",
			$meta_keys
		);

		$post_ids = $wpdb->get_col( $sql );
		foreach ( (array) $post_ids as $post_id ) {
			foreach ( $meta_keys as $meta_key ) {
				$data = get_post_meta( (int) $post_id, $meta_key, true );
				if ( is_array( $data ) ) {
					$this->collect_bricks_forms( $data, (int) $post_id, $forms );
				}
			}
		}

		return $forms;
	}

	private function collect_bricks_forms( array $elements, $post_id, array &$forms ) {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			if ( isset( $element['name'] ) && 'form' === $element['name'] ) {
				$form_id  = isset( $element['id'] ) ? sanitize_key( $element['id'] ) : '';
				$settings = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array();
				$form_key = 'bricks:' . $post_id . ':' . $form_id;

				if ( '' !== $form_id ) {
					$forms[ $form_key ] = array(
						'key'        => $form_key,
						'builder'    => 'bricks',
						'post_id'    => $post_id,
						'form_id'    => $form_id,
						'form_name'  => isset( $element['label'] ) ? sanitize_text_field( $element['label'] ) : 'Naamloos formulier',
						'post_title' => get_the_title( $post_id ),
						'edit_url'   => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
						'fields'     => $this->bricks_fields( isset( $settings['fields'] ) ? $settings['fields'] : array() ),
					);
				}
			}

			if ( ! empty( $element['children'] ) && is_array( $element['children'] ) ) {
				$this->collect_bricks_forms( $element['children'], $post_id, $forms );
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$this->collect_bricks_forms( $element['elements'], $post_id, $forms );
			}
		}
	}

	private function bricks_fields( $fields ) {
		$result = array();
		foreach ( (array) $fields as $field ) {
			if ( ! is_array( $field ) || empty( $field['id'] ) ) {
				continue;
			}

			$id = sanitize_key( $field['id'] );
			$result[ $id ] = array(
				'id'       => $id,
				'label'    => isset( $field['label'] ) ? wp_strip_all_tags( $field['label'] ) : $id,
				'type'     => isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text',
				'required' => ! empty( $field['required'] ),
			);
		}

		return $result;
	}
}
