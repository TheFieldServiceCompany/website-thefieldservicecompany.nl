<?php

namespace TFSC\FormBridge;

final class ElementorDiagnostics {
	const CLIENT_FAILURE_MAX_BYTES   = 65536;
	const CLIENT_FAILURE_RATE_LIMIT  = 10;
	const CLIENT_FAILURE_RATE_WINDOW = 600;

	/** @var MappingRepository */
	private $mappings;

	/** @var DiagnosticRepository */
	private $diagnostics;

	/** @var string */
	private $request_uuid = '';

	/** @var bool */
	private $completed = false;

	/** @var string */
	private $response_buffer = '';

	/** @var float */
	private $started_at = 0.0;

	public function __construct( MappingRepository $mappings, DiagnosticRepository $diagnostics ) {
		$this->mappings    = $mappings;
		$this->diagnostics = $diagnostics;
	}

	public function register() {
		add_action( 'wp_ajax_elementor_pro_forms_send_form', array( $this, 'begin_request' ), 0 );
		add_action( 'wp_ajax_nopriv_elementor_pro_forms_send_form', array( $this, 'begin_request' ), 0 );
		add_action( 'elementor_pro/forms/process', array( $this, 'mark_validated' ), 999, 2 );
		add_action( 'elementor_pro/forms/new_record', array( $this, 'mark_record_created' ), 999, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_client_monitor' ) );
		add_action( 'wp_ajax_tfsc_form_bridge_client_failure', array( $this, 'record_client_failure' ) );
		add_action( 'wp_ajax_nopriv_tfsc_form_bridge_client_failure', array( $this, 'record_client_failure' ) );
		add_action( 'tfsc_form_bridge_outbox_enqueued', array( $this, 'mark_outbox_enqueued' ), 10, 4 );
	}

	public function begin_request() {
		// Count metadata, not multipart document bytes. Skipping logs never blocks a form.
		if ( ! RequestBudget::payload_allowed( array( $_POST, $_FILES ) ) ) { return; }
		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$form_id = isset( $_POST['form_id'] ) ? sanitize_key( wp_unslash( $_POST['form_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$mapping = $this->active_mapping( $post_id, $form_id );
		if ( ! $mapping ) {
			return;
		}
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) && filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP ) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
		if ( ! RequestBudget::consume( 'server|' . $remote . '|elementor:' . $post_id . ':' . $form_id, 30, 600 ) ) { return; }

		$upload_files       = isset( $_FILES['form_fields'] ) ? $_FILES['form_fields'] : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$uploads            = self::summarize_uploads( $upload_files );
		$upload_details     = self::describe_uploads( $upload_files );
		$posted_uuid        = isset( $_POST['tfsc_diagnostic_request_id'] ) ? wp_unslash( $_POST['tfsc_diagnostic_request_id'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$this->request_uuid = wp_generate_uuid4();
		$_POST['tfsc_diagnostic_request_id'] = $this->request_uuid; // Makes the same correlation ID available to the outbox adapter.
		$this->started_at   = microtime( true );
		$context            = self::request_context();
		$context['request_data']['correlation_request_uuid'] = self::valid_uuid( $posted_uuid ) ? strtolower( (string) $posted_uuid ) : '';
		$started            = $this->diagnostics->start(
			array(
				'request_uuid'       => $this->request_uuid,
				'builder'            => 'elementor',
				'form_key'           => 'elementor:' . $post_id . ':' . $form_id,
				'form_type'          => isset( $mapping['form_type'] ) ? $mapping['form_type'] : '',
				'source'             => 'server',
				'stage'              => 'request_received',
				'status'             => 'started',
				'upload_count'       => $uploads['count'],
				'upload_bytes'       => $uploads['bytes'],
				'upload_error_codes' => $uploads['error_codes'],
				'upload_details'     => $upload_details,
				'client_ip'          => self::client_ip_summary(),
				'page_url'           => $context['page_url'],
				'previous_url'       => $context['previous_url'],
				'browser_summary'    => self::browser_summary( $context['user_agent'] ),
				'user_agent'         => $context['user_agent'],
				'request_data'       => $context['request_data'],
				'environment_data'   => self::environment_data(),
			)
		);
		if ( ! $started ) {
			$this->request_uuid = '';
			return;
		}

		ob_start( array( $this, 'capture_response' ) );
		register_shutdown_function( array( $this, 'capture_shutdown' ) );
	}

	public function mark_validated( $record = null, $ajax_handler = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$this->mark_stage( 'validation_passed' );
	}

	public function mark_record_created( $record = null, $ajax_handler = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$this->mark_stage( 'record_created' );
	}

	public function capture_response( $buffer, $phase = 0 ) {
		$this->response_buffer .= (string) $buffer;
		if ( $phase & PHP_OUTPUT_HANDLER_FINAL ) {
			$result = self::classify_response( $this->response_buffer, http_response_code() );
			if ( 'succeeded' === $result['status'] ) {
				$result['stage'] = 'response_sent';
			}
			$result['response_body'] = $this->response_buffer;
			$result['duration_ms']   = $this->duration_ms();
			$this->diagnostics->update( $this->request_uuid, $result );
			$this->completed = true;
		}
		return $buffer;
	}

	public function capture_shutdown() {
		if ( '' === $this->request_uuid ) {
			return;
		}

		$error = error_get_last();
		$fatal = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR );
		if ( is_array( $error ) && in_array( (int) $error['type'], $fatal, true ) ) {
			$this->diagnostics->update(
				$this->request_uuid,
				array(
					'stage'         => 'php_shutdown',
					'status'        => 'fatal',
					'error_code'    => 'php_fatal_' . absint( $error['type'] ),
					'fatal_data'    => array(
						'type'    => (int) $error['type'],
						'message' => isset( $error['message'] ) ? (string) $error['message'] : '',
						'file'    => isset( $error['file'] ) ? (string) $error['file'] : '',
						'line'    => isset( $error['line'] ) ? (int) $error['line'] : 0,
					),
					'duration_ms'   => $this->duration_ms(),
					'response_body' => $this->response_buffer,
				)
			);
			$this->completed = true;
			return;
		}
		if ( $this->completed ) {
			return;
		}

		$this->diagnostics->update(
			$this->request_uuid,
			array(
				'stage'         => 'php_shutdown',
				'status'        => 'failed',
				'error_code'    => 'request_terminated_without_response',
				'duration_ms'   => $this->duration_ms(),
				'response_body' => $this->response_buffer,
			)
		);
		$this->completed = true;
	}

	public function enqueue_client_monitor() {
		wp_enqueue_script(
			'tfsc-form-bridge-diagnostics',
			plugins_url( 'assets/diagnostics.js', TFSC_FORM_BRIDGE_FILE ),
			array( 'jquery' ),
			TFSC_FORM_BRIDGE_VERSION,
			true
		);
		wp_localize_script(
			'tfsc-form-bridge-diagnostics',
			'TFSCFormBridgeDiagnostics',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'tfsc_form_bridge_diagnostic' ),
			)
		);
	}

	public function record_client_failure() {
		if ( ! check_ajax_referer( 'tfsc_form_bridge_diagnostic', 'nonce', false ) ) {
			wp_send_json_error( array( 'code' => 'invalid_nonce' ), 403 );
		}
		if ( ! RequestBudget::payload_allowed( $_POST ) || self::client_payload_bytes( $_POST, isset( $_SERVER['CONTENT_LENGTH'] ) ? $_SERVER['CONTENT_LENGTH'] : 0 ) > self::CLIENT_FAILURE_MAX_BYTES ) {
			wp_send_json_error( array( 'code' => 'payload_too_large' ), 413 );
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		$form_id = isset( $_POST['form_id'] ) ? sanitize_key( wp_unslash( $_POST['form_id'] ) ) : '';
		$mapping = $this->active_mapping( $post_id, $form_id );
		if ( ! $mapping ) {
			wp_send_json_success( array( 'logged' => false ) );
		}

		$form_key = 'elementor:' . $post_id . ':' . $form_id;
		if ( self::client_rate_limited( $form_key ) ) {
			wp_send_json_error( array( 'code' => 'rate_limited' ), 429 );
		}

		$http_status = isset( $_POST['http_status'] ) ? absint( wp_unslash( $_POST['http_status'] ) ) : 0;
		$error_code  = self::client_error_code( $http_status );
		$posted_uuid = isset( $_POST['request_uuid'] ) ? wp_unslash( $_POST['request_uuid'] ) : '';
		// A public correlation value never selects a server-owned database row.
		$request_uuid = wp_generate_uuid4();
		$event = array(
				'request_uuid' => $request_uuid,
				'builder'      => 'elementor',
				'form_key'     => $form_key,
				'form_type'    => isset( $mapping['form_type'] ) ? $mapping['form_type'] : '',
				'source'       => 'browser',
				'stage'        => 'ajax_transport',
				'status'       => 'failed',
				'http_status'  => $http_status,
				'error_code'   => $error_code,
				'client_ip'    => self::client_ip_summary(),
				'page_url'     => isset( $_POST['page_url'] ) ? wp_unslash( $_POST['page_url'] ) : '',
				'previous_url' => isset( $_POST['previous_url'] ) ? wp_unslash( $_POST['previous_url'] ) : '',
				'user_agent'   => isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '',
				'request_data' => array(
					'correlation_request_uuid' => self::valid_uuid( $posted_uuid ) ? strtolower( (string) $posted_uuid ) : '',
					'browser_failure' => self::redact_for_log( wp_unslash( $_POST ) ),
				),
				'response_body' => isset( $_POST['response_text'] ) ? wp_unslash( $_POST['response_text'] ) : '',
				'environment_data' => self::environment_data(),
			);
		$event['browser_summary'] = self::browser_summary( $event['user_agent'] );
		$logged = $this->diagnostics->start( $event );

		wp_send_json_success( array( 'logged' => (bool) $logged ) );
	}

	public static function client_payload_bytes( $post, $content_length = 0 ) {
		$encoded = wp_json_encode( is_array( $post ) ? $post : array() );
		$encoded_bytes = is_string( $encoded ) ? strlen( $encoded ) : self::CLIENT_FAILURE_MAX_BYTES + 1;
		return max( 0, absint( $content_length ), $encoded_bytes );
	}

	public static function client_rate_limit_key( $remote_addr, $form_key ) {
		$remote_addr = filter_var( (string) $remote_addr, FILTER_VALIDATE_IP ) ? (string) $remote_addr : 'unknown';
		$form_key    = preg_replace( '/[^a-zA-Z0-9:_-]/', '', (string) $form_key );
		return 'tfsc_fb_diag_' . hash( 'sha256', $remote_addr . '|' . $form_key );
	}

	private static function client_rate_limited( $form_key ) {
		$remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';
		$key         = self::client_rate_limit_key( $remote_addr, $form_key );
		return ! RequestBudget::consume( $key, self::CLIENT_FAILURE_RATE_LIMIT, self::CLIENT_FAILURE_RATE_WINDOW );
	}

	public function mark_outbox_enqueued( $request_uuid, $submission_uuid, $outbox_id, $outbox_status ) {
		if ( ! self::valid_uuid( $request_uuid ) || '' === $this->request_uuid || ! hash_equals( $this->request_uuid, (string) $request_uuid ) ) {
			return;
		}
		$this->diagnostics->update(
			$request_uuid,
			array(
				'submission_uuid' => $submission_uuid,
				'outbox_id'       => $outbox_id,
				'outbox_status'   => $outbox_status,
			)
		);
	}

	public static function classify_response( $body, $http_status ) {
		$http_status = absint( $http_status );
		$decoded     = json_decode( trim( (string) $body ), true );
		if ( ! is_array( $decoded ) || ! array_key_exists( 'success', $decoded ) ) {
			return array(
				'status'      => 'failed',
				'http_status' => $http_status,
				'error_code'  => 'non_json_response',
			);
		}
		if ( true === $decoded['success'] ) {
			return array(
				'status'       => 'succeeded',
				'http_status'  => $http_status,
				'error_code'   => null,
				'error_fields' => array(),
			);
		}

		$error_fields = array();
		if ( isset( $decoded['data']['errors'] ) && is_array( $decoded['data']['errors'] ) ) {
			$error_fields = array_keys( $decoded['data']['errors'] );
		}
		return array(
			'status'       => 'failed',
			'http_status'  => $http_status,
			'error_code'   => 'elementor_response_failure',
			'error_fields' => $error_fields,
		);
	}

	public static function summarize_uploads( $files ) {
		$summary = array( 'count' => 0, 'bytes' => 0, 'error_codes' => array() );
		foreach ( self::describe_uploads( $files ) as $file ) {
			if ( UPLOAD_ERR_NO_FILE === (int) $file['error'] ) {
				continue;
			}
			++$summary['count'];
			$summary['bytes'] += max( 0, (int) $file['size'] );
			if ( UPLOAD_ERR_OK !== (int) $file['error'] ) {
				$summary['error_codes'][] = (int) $file['error'];
			}
		}
		$summary['error_codes'] = array_values( array_unique( $summary['error_codes'] ) );
		return $summary;
	}

	public static function describe_uploads( $files ) {
		$details = array();
		self::walk_upload_details( $files, $details );
		return $details;
	}

	public static function client_error_code( $http_status ) {
		$http_status = absint( $http_status );
		if ( 0 === $http_status ) {
			return 'browser_network_error';
		}
		if ( in_array( $http_status, array( 401, 403, 404, 413, 429, 500, 502, 503, 504 ), true ) ) {
			return 'browser_http_' . $http_status;
		}
		return 'browser_http_error';
	}

	private static function walk_upload_details( $value, array &$details, $field_path = '' ) {
		if ( ! is_array( $value ) ) {
			return;
		}
		if ( isset( $value['name'], $value['error'] ) && ! is_array( $value['name'] ) && ! is_array( $value['error'] ) ) {
			$name = (string) $value['name'];
			$tmp  = isset( $value['tmp_name'] ) ? (string) $value['tmp_name'] : '';
			$detected_mime = '';
			if ( '' !== $tmp && is_file( $tmp ) && function_exists( 'finfo_open' ) ) {
				$finfo = finfo_open( FILEINFO_MIME_TYPE );
				$detected_mime = $finfo ? (string) finfo_file( $finfo, $tmp ) : '';
				if ( $finfo ) {
					finfo_close( $finfo );
				}
			}
			$details[] = array(
				'field'         => $field_path,
				'name'          => $name,
				'extension'     => strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) ),
				'browser_mime'  => isset( $value['type'] ) ? (string) $value['type'] : '',
				'detected_mime' => $detected_mime,
				'tmp_name'      => $tmp,
				'size'          => isset( $value['size'] ) ? max( 0, (int) $value['size'] ) : 0,
				'error'         => (int) $value['error'],
				'full_path'     => isset( $value['full_path'] ) ? (string) $value['full_path'] : '',
			);
			return;
		}
		if ( isset( $value['name'], $value['error'] ) && is_array( $value['name'] ) ) {
			foreach ( array_keys( $value['name'] ) as $key ) {
				$child = array();
				foreach ( array( 'name', 'type', 'tmp_name', 'error', 'size', 'full_path' ) as $part ) {
					if ( isset( $value[ $part ] ) && is_array( $value[ $part ] ) && array_key_exists( $key, $value[ $part ] ) ) {
						$child[ $part ] = $value[ $part ][ $key ];
					}
				}
				self::walk_upload_details( $child, $details, '' === $field_path ? (string) $key : $field_path . '.' . $key );
			}
			return;
		}
		foreach ( $value as $key => $child ) {
			self::walk_upload_details( $child, $details, '' === $field_path ? (string) $key : $field_path . '.' . $key );
		}
	}

	private static function request_context() {
		$post = self::redact_for_log( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$server_keys = array(
			'REQUEST_METHOD', 'CONTENT_TYPE', 'CONTENT_LENGTH', 'HTTP_ACCEPT', 'HTTP_ACCEPT_LANGUAGE',
			'HTTP_ACCEPT_ENCODING', 'HTTP_ORIGIN', 'HTTP_REFERER', 'HTTP_USER_AGENT', 'HTTP_SEC_CH_UA',
			'HTTP_SEC_CH_UA_MOBILE', 'HTTP_SEC_CH_UA_PLATFORM', 'HTTP_CF_CONNECTING_IP',
			'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_TRUE_CLIENT_IP', 'REMOTE_ADDR', 'SERVER_PROTOCOL',
		);
		$server = array();
		foreach ( $server_keys as $key ) {
			if ( isset( $_SERVER[ $key ] ) ) {
				$server[ $key ] = wp_unslash( $_SERVER[ $key ] );
			}
		}
		$page_url = self::posted_scalar( 'tfsc_diagnostic_page_url' );
		if ( '' === $page_url ) {
			$page_url = self::posted_scalar( 'referrer' );
		}
		if ( '' === $page_url && isset( $_SERVER['HTTP_REFERER'] ) ) {
			$page_url = wp_unslash( $_SERVER['HTTP_REFERER'] );
		}
		return array(
			'page_url'     => $page_url,
			'previous_url' => self::posted_scalar( 'tfsc_diagnostic_previous_url' ),
			'user_agent'   => isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '',
			'request_data' => array(
				'post'       => $post,
				'server'     => $server,
				'client'     => self::decode_posted_json( 'tfsc_diagnostic_client' ),
				'navigation' => self::decode_posted_json( 'tfsc_diagnostic_navigation' ),
			),
		);
	}

	private static function client_ip_summary() {
		$labels = array(
			'remote'       => 'REMOTE_ADDR',
			'cf'           => 'HTTP_CF_CONNECTING_IP',
			'forwarded'    => 'HTTP_X_FORWARDED_FOR',
			'real'         => 'HTTP_X_REAL_IP',
			'true_client'  => 'HTTP_TRUE_CLIENT_IP',
		);
		$values = array();
		foreach ( $labels as $label => $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$values[] = $label . '=' . wp_unslash( $_SERVER[ $key ] );
			}
		}
		return implode( ' | ', $values );
	}

	private static function environment_data() {
		return array(
			'wordpress'        => function_exists( 'get_bloginfo' ) ? get_bloginfo( 'version' ) : '',
			'php'              => PHP_VERSION,
			'plugin'           => defined( 'TFSC_FORM_BRIDGE_VERSION' ) ? TFSC_FORM_BRIDGE_VERSION : '',
			'elementor'        => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '',
			'elementor_pro'    => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : '',
			'web_server'       => isset( $_SERVER['SERVER_SOFTWARE'] ) ? wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) : '',
			'wordpress_memory' => defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : '',
			'php_memory'       => ini_get( 'memory_limit' ),
			'php_upload_max'   => ini_get( 'upload_max_filesize' ),
			'php_post_max'     => ini_get( 'post_max_size' ),
			'php_max_files'    => ini_get( 'max_file_uploads' ),
			'utc_time'         => gmdate( 'c' ),
		);
	}

	private static function browser_summary( $user_agent ) {
		$user_agent = (string) $user_agent;
		$browser = 'Unknown browser';
		foreach ( array( 'Edg/' => 'Edge ', 'OPR/' => 'Opera ', 'Chrome/' => 'Chrome ', 'Firefox/' => 'Firefox ', 'Version/' => 'Safari ' ) as $marker => $name ) {
			if ( preg_match( '#' . preg_quote( $marker, '#' ) . '([0-9.]+)#', $user_agent, $matches ) ) {
				$browser = $name . $matches[1];
				break;
			}
		}
		$os = 'Unknown OS';
		foreach ( array( 'Windows NT' => 'Windows', 'Android' => 'Android', 'iPhone' => 'iOS', 'iPad' => 'iPadOS', 'Macintosh' => 'macOS', 'Linux' => 'Linux' ) as $marker => $name ) {
			if ( false !== stripos( $user_agent, $marker ) ) {
				$os = $name;
				break;
			}
		}
		return $browser . ' / ' . $os;
	}

	private static function decode_posted_json( $key ) {
		$value = self::posted_scalar( $key );
		$decoded = json_decode( $value, true );
		return is_array( $decoded ) ? self::redact_for_log( $decoded ) : $value;
	}

	private static function posted_scalar( $key ) {
		return isset( $_POST[ $key ] ) && is_scalar( $_POST[ $key ] ) ? (string) wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	private static function redact_for_log( $value, $key = '' ) {
		if ( '' !== $key && preg_match( '/password|passwd|\bpwd\b|authorization|cookie|nonce|captcha|api[_-]?key|secret|token/i', $key ) ) {
			return '[not logged: secret]';
		}
		if ( is_array( $value ) ) {
			$result = array();
			foreach ( $value as $child_key => $child ) {
				$result[ $child_key ] = self::redact_for_log( $child, (string) $child_key );
			}
			return $result;
		}
		if ( is_scalar( $value ) || null === $value ) {
			$value = (string) $value;
			return strlen( $value ) > 32768 ? substr( $value, 0, 32768 ) . '[truncated]' : $value;
		}
		return '[unsupported value]';
	}

	private static function valid_uuid( $value ) {
		return is_scalar( $value ) && 1 === preg_match( '/^[a-f0-9-]{36}$/i', (string) $value );
	}

	private function duration_ms() {
		return $this->started_at > 0 ? max( 0, (int) round( ( microtime( true ) - $this->started_at ) * 1000 ) ) : null;
	}

	private function mark_stage( $stage ) {
		if ( '' !== $this->request_uuid && ! $this->completed ) {
			$this->diagnostics->update( $this->request_uuid, array( 'stage' => $stage ) );
		}
	}

	private function active_mapping( $post_id, $form_id ) {
		if ( ! $post_id || '' === $form_id ) {
			return null;
		}
		$mapping = $this->mappings->get( 'elementor:' . $post_id . ':' . $form_id );
		return is_array( $mapping ) && ! empty( $mapping['enabled'] ) ? $mapping : null;
	}
}
