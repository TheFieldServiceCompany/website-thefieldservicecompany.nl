<?php

namespace TFSC\FormBridge;

final class Plugin {
	/** @var self|null */
	private static $instance;

	/** @var FormDiscovery */
	private $discovery;

	private function __construct() {
		Activator::maybe_upgrade();

		$targets     = new TargetRegistry();
		$mappings    = new MappingRepository( $targets );
		$normalizer  = new SubmissionNormalizer( $targets );
		$outbox      = new OutboxRepository();
		$diagnostics = new DiagnosticRepository();
		$this->discovery = new FormDiscovery();

		$delivery = new DeliveryWorker( $outbox );
		$delivery->register();
		add_action( DiagnosticRepository::CLEANUP_HOOK, array( $diagnostics, 'run_cleanup' ) );
		( new ElementorProAdapter( $mappings, $normalizer, $outbox ) )->register();
		( new ElementorDiagnostics( $mappings, $diagnostics ) )->register();
		( new BricksAdapter( $mappings, $normalizer, $outbox ) )->register();
		( new AdminPage( $this->discovery, $mappings, $targets, $outbox, $delivery, $diagnostics ) )->register();

		add_action( 'elementor/document/after_save', array( $this->discovery, 'invalidate' ) );
		add_action( 'save_post', array( $this->discovery, 'invalidate' ) );
		add_action( 'deleted_post', array( $this->discovery, 'invalidate' ) );
		add_action( 'trashed_post', array( $this->discovery, 'invalidate' ) );
	}

	public static function boot() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}
