<?php

namespace TFSC\FormBridge;

final class ElementorProAdapter {
	/** @var MappingRepository */
	private $mappings;

	/** @var SubmissionNormalizer */
	private $normalizer;

	/** @var OutboxRepository */
	private $outbox;

	/** @var callable */
	private $is_uploaded_file;

	/** @var callable */
	private $copy_file;

	/** @var callable */
	private $delete_file;

	/** @var array<string,bool> */
	private static $captured = array();

	/** @var array<string,array<string,array<int,array<string,string>>>> */
	private static $staged_documents = array();

	public function __construct( MappingRepository $mappings, SubmissionNormalizer $normalizer, OutboxRepository $outbox, array $file_operations = array() ) {
		$this->mappings   = $mappings;
		$this->normalizer = $normalizer;
		$this->outbox     = $outbox;
		$this->is_uploaded_file = isset( $file_operations['is_uploaded_file'] ) ? $file_operations['is_uploaded_file'] : 'is_uploaded_file';
		$this->copy_file        = isset( $file_operations['copy_file'] ) ? $file_operations['copy_file'] : 'copy';
		$this->delete_file      = isset( $file_operations['delete_file'] ) ? $file_operations['delete_file'] : 'unlink';
	}

	public function register() {
		add_action( 'elementor_pro/forms/process/upload', array( $this, 'stage_mapped_uploads' ), 5, 3 );
		add_action( 'elementor_pro/forms/new_record', array( $this, 'capture' ), 50, 2 );
	}

	/**
	 * Stage only explicitly mapped CRM documents before Elementor moves them.
	 *
	 * Elementor Pro 4.3.2 can pass an empty destination filename to
	 * move_uploaded_file() on this hosting stack. Copying the verified PHP
	 * upload to Elementor's normal protected directory keeps e-mail,
	 * submission storage and the Form Bridge on the same record contract.
	 */
	public function stage_mapped_uploads( $field, $record, $ajax_handler = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! is_array( $field ) || ! is_object( $record ) || ! method_exists( $record, 'add_file' ) ) {
			return false;
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$form_id = isset( $_POST['form_id'] ) ? sanitize_key( wp_unslash( $_POST['form_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$field_id = isset( $field['id'] ) ? sanitize_key( $field['id'] ) : '';
		if ( ! $post_id || '' === $form_id || '' === $field_id ) {
			return false;
		}

		$form_key = 'elementor:' . $post_id . ':' . $form_id;
		$mapping  = $this->mappings->get( $form_key );
		$target  = is_array( $mapping ) && isset( $mapping['field_map'][ $field_id ] ) ? $mapping['field_map'][ $field_id ] : '';
		if ( ! is_array( $mapping ) || empty( $mapping['enabled'] ) || ! in_array( $target, array( 'candidate.cv_files', 'company.vacancy_files' ), true ) ) {
			return false;
		}

		$files = isset( $_FILES['form_fields'][ $field_id ] ) && is_array( $_FILES['form_fields'][ $field_id ] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			? $_FILES['form_fields'][ $field_id ] // phpcs:ignore WordPress.Security.NonceVerification.Missing
			: array();
		if ( empty( $files ) ) {
			return false;
		}

		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) || empty( $uploads['baseurl'] ) ) {
			return false;
		}

		$directory = apply_filters( 'elementor_pro/forms/upload_path', rtrim( $uploads['basedir'], '/\\' ) . '/elementor/forms' );
		if ( ! is_dir( $directory ) && ! wp_mkdir_p( $directory ) ) {
			return false;
		}
		if ( ! is_writable( $directory ) ) {
			return false;
		}
		if ( ! $this->ensure_upload_protection( $directory ) ) {
			return false;
		}

		$bridge_directory = rtrim( $uploads['basedir'], '/\\' ) . '/tfsc-form-bridge';
		if ( ! is_dir( $bridge_directory ) && ! wp_mkdir_p( $bridge_directory ) ) {
			return false;
		}
		if ( ! is_writable( $bridge_directory ) || ! $this->ensure_private_upload_protection( $bridge_directory ) ) {
			return false;
		}

		$allowed_mimes = array(
			'pdf'  => 'application/pdf',
			'doc'  => 'application/msword',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		);
		$wordpress_max = (int) wp_max_upload_size();
		$max_size      = $wordpress_max > 0 ? min( 20 * 1024 * 1024, $wordpress_max ) : 20 * 1024 * 1024;
		$staged        = array();
		$bridge_staged = array();

		foreach ( $files as $index => $file ) {
			if ( ! is_array( $file ) || UPLOAD_ERR_NO_FILE === ( isset( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE ) ) {
				continue;
			}
			if ( UPLOAD_ERR_OK !== (int) $file['error'] || empty( $file['tmp_name'] ) || ! call_user_func( $this->is_uploaded_file, $file['tmp_name'] ) ) {
				$this->delete_staged_files( array_merge( $staged, $bridge_staged ) );
				return false;
			}

			$name      = isset( $file['name'] ) ? sanitize_file_name( $file['name'] ) : '';
			$extension = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
			$size      = isset( $file['size'] ) ? (int) $file['size'] : 0;
			$checked   = wp_check_filetype_and_ext( $file['tmp_name'], $name, $allowed_mimes );
			if ( ! isset( $allowed_mimes[ $extension ] ) || empty( $checked['ext'] ) || $size < 1 || $size > $max_size ) {
				$this->delete_staged_files( array_merge( $staged, $bridge_staged ) );
				return false;
			}

			$filename = 'tfsc-' . str_replace( '-', '', wp_generate_uuid4() ) . '-' . absint( $index ) . '.' . $extension;
			$path        = rtrim( $directory, '/\\' ) . '/' . $filename;
			$bridge_path = rtrim( $bridge_directory, '/\\' ) . '/' . $filename;
			if ( file_exists( $path ) || file_exists( $bridge_path ) || ! call_user_func( $this->copy_file, $file['tmp_name'], $path ) ) {
				$this->delete_staged_files( array_merge( $staged, $bridge_staged ) );
				return false;
			}
			if ( ! call_user_func( $this->copy_file, $file['tmp_name'], $bridge_path ) ) {
				$this->delete_staged_files( array_merge( $staged, $bridge_staged, array( array( 'path' => $path ) ) ) );
				return false;
			}

			@ chmod( $path, 0644 );
			@ chmod( $bridge_path, 0600 );
			$staged[ $index ] = array(
				'path' => $path,
				'url'  => apply_filters( 'elementor_pro/forms/upload_url', rtrim( $uploads['baseurl'], '/' ) . '/elementor/forms/' . $filename, $filename ),
			);
			$bridge_staged[ $index ] = array(
				'name' => $name,
				'path' => $bridge_path,
				'url'  => '',
			);
		}

		if ( empty( $staged ) || empty( $bridge_staged ) ) {
			$this->delete_staged_files( array_merge( $staged, $bridge_staged ) );
			return false;
		}

		foreach ( $staged as $index => $document ) {
			$record->add_file( $field_id, $index, $document );
			$_FILES['form_fields'][ $field_id ][ $index ]['error'] = UPLOAD_ERR_NO_FILE; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		if ( ! isset( self::$staged_documents[ $form_key ] ) ) {
			self::$staged_documents[ $form_key ] = array();
		}
		self::$staged_documents[ $form_key ][ $field_id ] = $bridge_staged;

		return true;
	}

	private function ensure_upload_protection( $directory ) {
		$files = array(
			'index.php' => "<?php\n// Silence is golden.\n",
			'.htaccess' => "Options -Indexes\n<ifModule mod_headers.c>\n\t<Files *.*>\n\t\tHeader set Content-Disposition attachment\n\t</Files>\n</IfModule>\n",
		);
		foreach ( $files as $name => $content ) {
			$path = rtrim( $directory, '/\\' ) . '/' . $name;
			if ( ! file_exists( $path ) && false === file_put_contents( $path, $content, LOCK_EX ) ) {
				return false;
			}
		}

		return true;
	}

	private function ensure_private_upload_protection( $directory ) {
		$files = array(
			'index.php' => "<?php\n// Silence is golden.\n",
			'.htaccess' => "Options -Indexes\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n",
		);
		foreach ( $files as $name => $content ) {
			$path = rtrim( $directory, '/\\' ) . '/' . $name;
			if ( ! file_exists( $path ) && false === file_put_contents( $path, $content, LOCK_EX ) ) {
				return false;
			}
		}

		return true;
	}

	private function delete_staged_files( array $staged ) {
		foreach ( $staged as $document ) {
			if ( isset( $document['path'] ) && is_file( $document['path'] ) ) {
				call_user_func( $this->delete_file, $document['path'] );
			}
		}
	}

	public function capture( $record, $ajax_handler = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! is_object( $record ) || ! method_exists( $record, 'get' ) ) {
			return;
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$form_id = isset( $_POST['form_id'] ) ? sanitize_key( wp_unslash( $_POST['form_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! $post_id || '' === $form_id ) {
			return;
		}

		$form_key = 'elementor:' . $post_id . ':' . $form_id;
		$mapping  = $this->mappings->get( $form_key );
		if ( ! is_array( $mapping ) || empty( $mapping['enabled'] ) ) {
			return;
		}

		$guard_key = $form_key . ':' . spl_object_hash( $record );
		if ( isset( self::$captured[ $guard_key ] ) ) {
			return;
		}
		self::$captured[ $guard_key ] = true;

		$record_fields = $record->get( 'fields' );
		$fields        = array();
		foreach ( (array) $record_fields as $field_id => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field_id = isset( $field['id'] ) ? sanitize_key( $field['id'] ) : sanitize_key( $field_id );
			if ( '' === $field_id ) {
				continue;
			}

			$value = array_key_exists( 'raw_value', $field ) ? $field['raw_value'] : ( isset( $field['value'] ) ? $field['value'] : '' );
			$fields[ $field_id ] = array(
				'label'    => isset( $field['title'] ) ? $field['title'] : $field_id,
				'type'     => isset( $field['type'] ) ? $field['type'] : 'text',
				'value'    => $value,
				'required' => ! empty( $field['required'] ),
			);
		}

		$fields = $this->merge_staged_documents( $form_key, $fields );

		$form_name = '';
		if ( method_exists( $record, 'get_form_settings' ) ) {
			$form_name = (string) $record->get_form_settings( 'form_name' );
		}

		$source   = $this->source_metadata( $post_id, $form_id, $form_name );
		$trusted_files = self::$staged_documents[ $form_key ] ?? array();
		$envelope = $this->normalizer->normalize( $source, $fields, $mapping, $trusted_files );
		$result   = $this->outbox->enqueue( $envelope );

		if ( is_wp_error( $result ) ) {
			$this->forget_staged_documents( $form_key, true );
			// Deliberately log only a fixed error code; never applicant data.
			error_log( 'TFSC Form Bridge Elementor capture failed: ' . sanitize_key( $result->get_error_code() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			return;
		}

		$diagnostic_request_id = isset( $_POST['tfsc_diagnostic_request_id'] ) ? wp_unslash( $_POST['tfsc_diagnostic_request_id'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		do_action(
			'tfsc_form_bridge_outbox_enqueued',
			$diagnostic_request_id,
			isset( $envelope['submission_id'] ) ? $envelope['submission_id'] : '',
			isset( $result['id'] ) ? (int) $result['id'] : 0,
			isset( $result['status'] ) ? $result['status'] : ''
		);

		$this->forget_staged_documents( $form_key, false );
	}

	private function merge_staged_documents( $form_key, array $fields ) {
		if ( empty( self::$staged_documents[ $form_key ] ) ) {
			return $fields;
		}

		foreach ( self::$staged_documents[ $form_key ] as $field_id => $documents ) {
			if ( ! isset( $fields[ $field_id ] ) || ! is_array( $documents ) ) {
				continue;
			}

			$fields[ $field_id ]['type']  = 'upload';
			$fields[ $field_id ]['value'] = array_values( $documents );
		}

		return $fields;
	}

	private function forget_staged_documents( $form_key, $delete_files ) {
		if ( empty( self::$staged_documents[ $form_key ] ) ) {
			return;
		}

		if ( $delete_files ) {
			foreach ( self::$staged_documents[ $form_key ] as $documents ) {
				$this->delete_staged_files( (array) $documents );
			}
		}

		unset( self::$staged_documents[ $form_key ] );
	}

	private function source_metadata( $post_id, $form_id, $form_name ) {
		$page_url = isset( $_POST['tfsc_diagnostic_page_url'] ) ? wp_unslash( $_POST['tfsc_diagnostic_page_url'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( '' === $page_url && isset( $_POST['referrer'] ) ) {
			$page_url = wp_unslash( $_POST['referrer'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		if ( '' === $page_url && isset( $_SERVER['HTTP_REFERER'] ) ) {
			$page_url = wp_unslash( $_SERVER['HTTP_REFERER'] );
		}
		$referrer = isset( $_POST['tfsc_diagnostic_previous_url'] ) ? wp_unslash( $_POST['tfsc_diagnostic_previous_url'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( '' === $referrer && isset( $_SERVER['HTTP_REFERER'] ) && wp_unslash( $_SERVER['HTTP_REFERER'] ) !== $page_url ) {
			$referrer = wp_unslash( $_SERVER['HTTP_REFERER'] );
		}

		$source = array(
			'builder'    => 'elementor',
			'form_key'   => 'elementor:' . $post_id . ':' . $form_id,
			'form_id'    => $form_id,
			'form_name'  => $form_name,
			'post_id'    => $post_id,
			'site_url'   => home_url( '/' ),
			'page_title' => get_the_title( $post_id ),
			'page_url'   => $page_url,
			'referrer'   => $referrer,
			'remote_ip'  => isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '',
			'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '',
			'diagnostic_request_id' => isset( $_POST['tfsc_diagnostic_request_id'] ) ? wp_unslash( $_POST['tfsc_diagnostic_request_id'] ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Missing
		);


		$entry_json = isset( $_POST['tfsc_entry_context'] ) && is_scalar( $_POST['tfsc_entry_context'] )
			? substr( wp_unslash( $_POST['tfsc_entry_context'] ), 0, 8192 ) : '';
		$entry = json_decode( $entry_json, true );
		if ( is_array( $entry ) && isset( $entry['version'] ) && 1 === (int) $entry['version'] ) {
			foreach ( array( 'entry_page_url', 'entry_referrer', 'entry_at', 'entry_utm_source', 'entry_utm_medium', 'entry_utm_campaign', 'entry_utm_content', 'entry_utm_term', 'traffic_class' ) as $key ) {
				if ( isset( $entry[ $key ] ) && is_scalar( $entry[ $key ] ) ) {
					$source[ $key ] = substr( (string) $entry[ $key ], 0, in_array( $key, array( 'entry_page_url', 'entry_referrer' ), true ) ? 2048 : 200 );
				}
			}
		}

		$url_tracking = self::tracking_parameters_from_urls( $page_url, $referrer );
		foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'gclid' ) as $tracking_key ) {
			$request_value = isset( $_REQUEST[ $tracking_key ] ) && is_scalar( $_REQUEST[ $tracking_key ] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				? wp_unslash( $_REQUEST[ $tracking_key ] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				: '';
			if ( '' !== trim( (string) $request_value ) ) {
				$source[ $tracking_key ] = $request_value;
			} elseif ( isset( $url_tracking[ $tracking_key ] ) ) {
				$source[ $tracking_key ] = $url_tracking[ $tracking_key ];
			}
		}

		return $source;
	}

	public static function tracking_parameters_from_urls( $page_url, $referrer = '' ) {
		$allowed = array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'gclid' );
		$result  = array();

		foreach ( array( $page_url, $referrer ) as $url ) {
			$query = wp_parse_url( (string) $url, PHP_URL_QUERY );
			if ( ! is_string( $query ) || '' === $query ) {
				continue;
			}

			$parameters = array();
			parse_str( $query, $parameters );
			foreach ( $allowed as $key ) {
				if ( isset( $result[ $key ] ) || ! isset( $parameters[ $key ] ) || ! is_scalar( $parameters[ $key ] ) ) {
					continue;
				}

				$value = trim( (string) $parameters[ $key ] );
				if ( '' !== $value ) {
					$result[ $key ] = $value;
				}
			}
		}

		return $result;
	}
}
