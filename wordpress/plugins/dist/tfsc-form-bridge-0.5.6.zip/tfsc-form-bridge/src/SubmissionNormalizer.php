<?php

namespace TFSC\FormBridge;

final class SubmissionNormalizer {
	const SCHEMA_VERSION = 1;

	/** @var TargetRegistry */
	private $targets;

	public function __construct( TargetRegistry $targets ) {
		$this->targets = $targets;
	}

	public function normalize( array $source, array $fields, array $mapping, array $trusted_files = array() ) {
		$submission_id = wp_generate_uuid4();
		$form_type     = isset( $mapping['form_type'] ) ? sanitize_key( $mapping['form_type'] ) : '';
		$field_map     = isset( $mapping['field_map'] ) && is_array( $mapping['field_map'] ) ? $mapping['field_map'] : array();
		$mapped        = array();
		$raw_fields    = array();
		$files         = array();
		$file_targets  = array();
		$review_codes  = array();

		foreach ( $fields as $field_id => $field ) {
			$field_id = sanitize_key( $field_id );
			if ( '' === $field_id || ! is_array( $field ) ) {
				continue;
			}

			$type  = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text';
			$value = isset( $field['value'] ) ? $field['value'] : null;
			$mapped_target = $field_map[ $field_id ] ?? '';
			$is_document = in_array( $type, array( 'upload', 'file' ), true ) || in_array( $mapped_target, array( 'candidate.cv_files', 'company.vacancy_files' ), true );

			$raw_fields[ $field_id ] = array(
				'type'  => $type,
				'label' => isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : $field_id,
				'value' => $is_document ? array() : $this->sanitize_raw_value( $value, $type ),
			);

			$normalized_files = $is_document
				? $this->normalize_file_references( $trusted_files[ $field_id ] ?? array() )
				: null;

			if ( is_array( $normalized_files ) ) {
				foreach ( $normalized_files as $index => &$file ) {
					$file['upload_proof'] = UploadProvenance::seal( $submission_id, $field_id, $index, $file );
				}
				unset( $file );
				$raw_fields[ $field_id ]['value'] = $normalized_files;
				$files[ $field_id ] = $normalized_files;
			}

			if ( empty( $field_map[ $field_id ] ) ) {
				if ( ! empty( $field['required'] ) ) {
					$review_codes[] = 'unmapped_required_field:' . $field_id;
				}
				continue;
			}

			$target = $field_map[ $field_id ];
			if ( ! is_scalar( $target ) ) {
				$review_codes[] = 'unknown_target:' . $field_id;
				continue;
			}
			$target = (string) $target;
			$config = $this->targets->get( $target );
			if ( ! is_array( $config ) ) {
				$review_codes[] = 'unknown_target:' . $field_id;
				continue;
			}

			if ( 'file_list' === $config['type'] && ! is_array( $normalized_files ) ) {
				$normalized_files    = array();
				$files[ $field_id ] = $normalized_files;
			}

			$normalized = 'file_list' === $config['type']
				? $normalized_files
				: $this->normalize_for_target( $value, $config['type'], $target );
			if ( array_key_exists( $target, $mapped ) ) {
				$review_codes[] = 'duplicate_target:' . $target;
				continue;
			}

			$mapped[ $target ] = $normalized;
			if ( 'file_list' === $config['type'] ) {
				$file_targets[ $field_id ] = $target;
			}
		}

		foreach ( array_keys( $field_map ) as $mapped_source ) {
			$mapped_source = sanitize_key( $mapped_source );
			if ( '' !== $mapped_source && ! array_key_exists( $mapped_source, $fields ) ) {
				$review_codes[] = 'mapped_source_missing:' . $mapped_source;
			}
		}

		if ( ! $this->targets->has_form_type( $form_type ) ) {
			$review_codes[] = 'unknown_form_type';
		}

		if ( empty( $mapped ) ) {
			$review_codes[] = 'no_mapped_fields';
		}

		return array(
			'schema_version'  => self::SCHEMA_VERSION,
			'submission_id'   => $submission_id,
			'captured_at'     => gmdate( 'c' ),
			'form_type'       => $form_type,
			'mapping_version' => isset( $mapping['version'] ) ? max( 1, (int) $mapping['version'] ) : 1,
			'actions'         => array(
				'create_candidate' => ! empty( $mapping['create_candidate'] ),
				'create_company'   => ! empty( $mapping['create_company'] ),
			),
			'source'          => $this->sanitize_source( $source ),
			'fields'          => $raw_fields,
			'mapped'          => $mapped,
			'files'           => array_filter( $files ),
			'file_targets'    => $file_targets,
			'review_codes'    => array_values( array_unique( $review_codes ) ),
		);
	}

	private function normalize_for_target( $value, $type, $target = '' ) {
		switch ( $type ) {
			case 'email':
				return sanitize_email( is_scalar( $value ) ? (string) $value : '' );
			case 'phone':
				$value = is_scalar( $value ) ? (string) $value : '';
				return preg_replace( '/[^0-9+().\-\s]/', '', $value );
			case 'url':
				return esc_url_raw( is_scalar( $value ) ? (string) $value : '' );
			case 'boolean':
				$value = is_array( $value ) ? reset( $value ) : $value;
				return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes', 'ja', 'on', 'accepted' ), true );
			case 'list':
				$values = is_array( $value ) ? $value : preg_split( '/\r\n|\r|\n|,/', (string) $value );
				$values = array_values( array_filter( array_map( 'sanitize_text_field', $values ), 'strlen' ) );
				if ( in_array( $target, array( 'candidate.employment_preferences', 'mailing.employment_types' ), true ) ) {
					$values = array_map( array( $this, 'normalize_employment_type' ), $values );
				}
				return array_values( array_unique( $values ) );
			case 'file_list':
				return $this->normalize_file_references( $value );
			case 'multiline':
				return sanitize_textarea_field( is_scalar( $value ) ? (string) $value : '' );
			case 'string':
			default:
				return sanitize_text_field( is_scalar( $value ) ? (string) $value : '' );
		}
	}

	/**
	 * Convert display-label variants to the canonical CRM values.
	 *
	 * Form builders are free to vary letter case and whitespace. Those visual
	 * differences must not create a review item or a second business value.
	 * Unknown values remain intact so the receiver can still flag them for
	 * explicit review instead of silently guessing.
	 */
	private function normalize_employment_type( $value ) {
		$value = sanitize_text_field( $value );
		$key   = strtolower( trim( preg_replace( '/\s+/', ' ', $value ) ) );
		$key   = preg_replace( '/\s*\/\s*/', '/', $key );

		$canonical = array(
			'vast dienstverband' => 'Vast dienstverband',
			'freelance/zzp'      => 'Freelance / ZZP',
		);

		return isset( $canonical[ $key ] ) ? $canonical[ $key ] : $value;
	}

	private function sanitize_raw_value( $value, $type ) {
		if ( in_array( $type, array( 'upload', 'file' ), true ) ) {
			return $this->normalize_file_references( $value );
		}

		if ( is_array( $value ) ) {
			return array_values( array_map( array( $this, 'sanitize_raw_scalar' ), $value ) );
		}

		return $this->sanitize_raw_scalar( $value );
	}

	public function sanitize_raw_scalar( $value ) {
		return is_scalar( $value ) ? sanitize_textarea_field( (string) $value ) : '';
	}

	private function normalize_file_references( $value ) {
		$values = is_array( $value ) ? $value : array( $value );
		$files  = array();

		foreach ( $values as $item ) {
			if ( is_array( $item ) ) {
				$url  = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';
				$path = isset( $item['path'] ) ? wp_normalize_path( (string) $item['path'] ) : '';
				$name = isset( $item['name'] ) ? sanitize_file_name( $item['name'] ) : ( $path ? basename( $path ) : '' );
			} else {
				$item = is_scalar( $item ) ? trim( (string) $item ) : '';
				$url  = filter_var( $item, FILTER_VALIDATE_URL ) ? esc_url_raw( $item ) : '';
				$path = $url ? '' : wp_normalize_path( $item );
				$name = sanitize_file_name( basename( $url ? wp_parse_url( $url, PHP_URL_PATH ) : $path ) );
			}

			if ( '' === $url && '' === $path ) {
				continue;
			}

			$files[] = array(
				'name' => $name,
				'url'  => $url,
				'path' => $path,
			);
		}

		return $files;
	}

	private function sanitize_source( array $source ) {
		$allowed = array(
			'builder', 'form_key', 'form_id', 'form_name', 'post_id', 'site_url', 'page_title',
			'page_url', 'referrer', 'remote_ip', 'user_agent', 'utm_source',
			'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'gclid',
			'entry_page_url', 'entry_referrer', 'entry_at', 'entry_utm_source', 'entry_utm_medium',
			'entry_utm_campaign', 'entry_utm_content', 'entry_utm_term', 'traffic_class',
		);
		$result = array();

		foreach ( $allowed as $key ) {
			if ( ! array_key_exists( $key, $source ) ) {
				continue;
			}

			$value = $source[ $key ];
			if ( in_array( $key, array( 'site_url', 'page_url', 'referrer', 'entry_page_url', 'entry_referrer' ), true ) ) {
				$result[ $key ] = esc_url_raw( (string) $value );
			} elseif ( 'post_id' === $key ) {
				$result[ $key ] = absint( $value );
			} else {
				$result[ $key ] = sanitize_text_field( (string) $value );
			}
		}

		return $result;
	}
}
