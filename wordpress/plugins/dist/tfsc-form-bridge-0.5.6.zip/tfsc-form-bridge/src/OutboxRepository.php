<?php

namespace TFSC\FormBridge;

final class OutboxRepository {
	public function enqueue( array $envelope ) {
		global $wpdb;

		if ( empty( $envelope['submission_id'] ) || empty( $envelope['source']['form_key'] ) ) {
			return new \WP_Error( 'invalid_envelope', 'De inzending mist een unieke ID of formulierverwijzing.' );
		}

		$table  = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		$now    = current_time( 'mysql', true );
		$status = 'pending';
		$json   = wp_json_encode( $envelope, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		if ( false === $json ) {
			return new \WP_Error( 'payload_encoding_failed', 'De inzending kon niet veilig worden gecodeerd.' );
		}

		$result = $wpdb->insert(
			$table,
			array(
				'submission_uuid' => $envelope['submission_id'],
				'builder'         => isset( $envelope['source']['builder'] ) ? $envelope['source']['builder'] : '',
				'form_key'        => $envelope['source']['form_key'],
				'form_type'       => isset( $envelope['form_type'] ) ? $envelope['form_type'] : '',
				'mapping_version' => isset( $envelope['mapping_version'] ) ? (int) $envelope['mapping_version'] : 1,
				'payload'         => $json,
				'status'          => $status,
				'attempts'        => 0,
				'created_at'      => $now,
				'updated_at'      => $now,
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s' )
		);

		if ( false === $result ) {
			return new \WP_Error( 'outbox_insert_failed', 'De inzending kon niet in de lokale outbox worden opgeslagen.' );
		}

		if ( function_exists( 'wp_schedule_single_event' ) ) {
			wp_schedule_single_event( time() + 10, DeliveryWorker::HOOK );
		}

		return array(
			'id'     => (int) $wpdb->insert_id,
			'status' => $status,
		);
	}

	public function claim_due( $limit = 10 ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		$limit = max( 1, min( 25, absint( $limit ) ) );
		$now   = current_time( 'mysql', true );
		$stale = gmdate( 'Y-m-d H:i:s', time() - ( 15 * MINUTE_IN_SECONDS ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, submission_uuid, payload, document_state, attempts
				FROM {$table}
				WHERE (
					(status IN ('pending', 'retry') AND (next_attempt_at IS NULL OR next_attempt_at <= %s))
					OR (status = 'processing' AND updated_at <= %s)
				)
				ORDER BY id ASC
				LIMIT %d",
				$now,
				$stale,
				$limit
			),
			ARRAY_A
		);

		$claimed = array();
		foreach ( (array) $rows as $row ) {
			$updated = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table}
					SET status = 'processing', attempts = attempts + 1,
						next_attempt_at = NULL, updated_at = %s
					WHERE id = %d
						AND (
							status IN ('pending', 'retry')
							OR (status = 'processing' AND updated_at <= %s)
						)",
					$now,
					(int) $row['id'],
					$stale
				)
			);

			if ( 1 === $updated ) {
				$row['attempts'] = (int) $row['attempts'] + 1;
				$claimed[]       = $row;
			}
		}

		return $claimed;
	}

	public function save_document_state( $id, array $documents ) {
		global $wpdb;

		$json = wp_json_encode( $documents, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $json ) {
			return false;
		}

		$table = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		return false !== $wpdb->update(
			$table,
			array(
				'document_state' => $json,
				'updated_at'     => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	public function mark_delivered( $id, $requires_review = false ) {
		return $this->set_result(
			$id,
			$requires_review ? 'review' : 'delivered',
			null,
			null,
			null
		);
	}

	public function mark_review( $id, $error_code ) {
		return $this->set_result( $id, 'review', $error_code, 'Handmatige documentcontrole nodig.', null );
	}

	public function mark_retry( $id, $error_code, $delay_seconds ) {
		$next_attempt_at = gmdate( 'Y-m-d H:i:s', time() + max( 60, (int) $delay_seconds ) );
		return $this->set_result( $id, 'retry', $error_code, 'Tijdelijke afleverfout.', $next_attempt_at );
	}

	public function mark_failed( $id, $error_code ) {
		return $this->set_result( $id, 'failed', $error_code, 'Definitieve afleverfout.', null );
	}

	public function requeue_recoverable_document_reviews() {
		global $wpdb;

		$table = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		$codes = array( 'b2_not_configured', 'b2_key_not_allowed', 'b2_bucket_not_allowed', 'b2_prefix_not_allowed', 'candidate_document_target_missing' );
		$count = 0;

		foreach ( $codes as $code ) {
			$updated = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table}
					SET status = 'retry', next_attempt_at = NULL,
						last_error_code = NULL, last_error_message = NULL, updated_at = %s
					WHERE status = 'review' AND last_error_code = %s",
					current_time( 'mysql', true ),
					$code
				)
			);
			if ( false !== $updated ) {
				$count += (int) $updated;
			}
		}

		return $count;
	}

	private function set_result( $id, $status, $error_code, $error_message, $next_attempt_at ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		return $wpdb->update(
			$table,
			array(
				'status'             => $status,
				'next_attempt_at'    => $next_attempt_at,
				'last_error_code'    => $error_code,
				'last_error_message' => $error_message,
				'updated_at'         => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $id ) ),
			array( '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public function recent( $limit = 50 ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		$limit = max( 1, min( 100, absint( $limit ) ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, submission_uuid, builder, form_key, form_type, mapping_version,
					status, attempts, next_attempt_at, last_error_code, created_at, updated_at, payload
				FROM {$table}
				ORDER BY id DESC
				LIMIT %d",
				$limit
			),
			ARRAY_A
		);

		foreach ( (array) $rows as &$row ) {
			$payload = json_decode( isset( $row['payload'] ) ? $row['payload'] : '', true );
			$email   = is_array( $payload ) && isset( $payload['mapped']['person.email'] )
				? sanitize_email( (string) $payload['mapped']['person.email'] )
				: '';
			$row['email'] = $email;
			unset( $row['payload'] );
		}
		unset( $row );

		return $rows;
	}

	public function counts() {
		global $wpdb;

		$table = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		$rows  = $wpdb->get_results( "SELECT status, COUNT(*) total FROM {$table} GROUP BY status", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$result = array();

		foreach ( (array) $rows as $row ) {
			$result[ $row['status'] ] = (int) $row['total'];
		}

		return $result;
	}
}
