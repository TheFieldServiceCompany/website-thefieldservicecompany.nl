<?php

namespace TFSC\FormBridge;

/**
 * Minimal Backblaze B2 Native API client for private, prefix-restricted writes.
 */
final class BackblazeClient {
	const DEFAULT_BUCKET_NAME = 'tfsc-documents-prod';
	const DEFAULT_REGION = 'eu-central-003';
	const MAX_IMMEDIATE_UPLOAD_ATTEMPTS = 2;

	/** @var array|null */
	private $authorization;

	public static function is_configured() {
		return defined( 'TFSC_B2_APPLICATION_KEY_ID' )
			&& '' !== trim( (string) TFSC_B2_APPLICATION_KEY_ID )
			&& defined( 'TFSC_B2_APPLICATION_KEY' )
			&& '' !== (string) TFSC_B2_APPLICATION_KEY
			&& defined( 'TFSC_B2_BUCKET_ID' )
			&& '' !== trim( (string) TFSC_B2_BUCKET_ID );
	}

	public static function bucket_name() {
		return defined( 'TFSC_B2_BUCKET_NAME' ) && '' !== trim( (string) TFSC_B2_BUCKET_NAME )
			? trim( (string) TFSC_B2_BUCKET_NAME )
			: self::DEFAULT_BUCKET_NAME;
	}

	public static function region() {
		return defined( 'TFSC_B2_REGION' ) && '' !== trim( (string) TFSC_B2_REGION )
			? trim( (string) TFSC_B2_REGION )
			: self::DEFAULT_REGION;
	}

	public static function encode_object_key( $object_key ) {
		return implode( '/', array_map( 'rawurlencode', explode( '/', (string) $object_key ) ) );
	}

	public function upload( array $document ) {
		if ( ! self::is_configured() ) {
			return new \WP_Error( 'b2_not_configured', 'Backblaze B2 is niet geconfigureerd.' );
		}

		$validated = $this->validate_local_document( $document );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$authorized = $this->authorize();
		if ( is_wp_error( $authorized ) ) {
			return $authorized;
		}

		$object_key = isset( $document['object_key'] ) ? (string) $document['object_key'] : '';
		if ( 0 !== strpos( $object_key, 'documents/' ) ) {
			return new \WP_Error( 'b2_object_key_invalid', 'Ongeldige Backblaze-objectverwijzing.' );
		}

		$allowed_prefix = isset( $authorized['name_prefix'] ) ? (string) $authorized['name_prefix'] : '';
		if ( '' !== $allowed_prefix && 0 !== strpos( $object_key, $allowed_prefix ) ) {
			return new \WP_Error( 'b2_prefix_not_allowed', 'De Backblaze-sleutel staat dit objectpad niet toe.' );
		}

		$bytes = file_get_contents( $validated['path'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $bytes ) {
			return new \WP_Error( 'document_read_failed', 'Het lokale document kon niet worden gelezen.' );
		}

		$size_bytes = strlen( $bytes );
		if ( $size_bytes < 1 || $size_bytes > $validated['maximum_size'] ) {
			unset( $bytes );
			return new \WP_Error( 'document_size_not_allowed', 'Het document is leeg of groter dan de toegestane uploadlimiet van maximaal 20 MB.' );
		}

		$sha1       = sha1( $bytes );
		$decoded    = null;
		$last_error = null;
		for ( $attempt = 1; $attempt <= self::MAX_IMMEDIATE_UPLOAD_ATTEMPTS; ++$attempt ) {
			$upload_target = $this->get_upload_url( $authorized );
			if ( is_wp_error( $upload_target ) ) {
				$last_error = $upload_target;
				break;
			}

			$result = $this->upload_bytes( $upload_target, $object_key, $validated['mime_type'], $bytes, $size_bytes, $sha1 );
			if ( ! is_wp_error( $result ) ) {
				$decoded = $result;
				break;
			}

			$last_error = $result;
			$error_data = $result->get_error_data();
			if ( $attempt >= self::MAX_IMMEDIATE_UPLOAD_ATTEMPTS || ! is_array( $error_data ) || empty( $error_data['retry_with_new_upload_url'] ) ) {
				break;
			}
		}
		unset( $bytes );

		if ( ! is_array( $decoded ) ) {
			return is_wp_error( $last_error )
				? $last_error
				: new \WP_Error( 'b2_upload_failed', 'Backblaze heeft het verzoek niet geaccepteerd.' );
		}

		if ( empty( $decoded['fileId'] ) || empty( $decoded['fileName'] ) || $decoded['fileName'] !== $object_key ) {
			return new \WP_Error( 'b2_upload_response_invalid', 'Backblaze gaf geen geldige uploadbevestiging.' );
		}

		$response_sha1 = isset( $decoded['contentSha1'] ) ? strtolower( sanitize_key( $decoded['contentSha1'] ) ) : '';
		return array(
			'b2_file_id'  => sanitize_text_field( $decoded['fileId'] ),
			'content_sha1' => 1 === preg_match( '/^[0-9a-f]{40}$/', $response_sha1 ) ? $response_sha1 : $sha1,
			'mime_type'   => $validated['mime_type'],
			'size_bytes'  => $size_bytes,
		);
	}

	private function upload_bytes( array $upload_target, $object_key, $mime_type, $bytes, $size_bytes, $sha1 ) {
		$response = wp_remote_post(
			$upload_target['upload_url'],
			array(
				'timeout'     => 60,
				'redirection' => 0,
				'sslverify'   => true,
				'headers'     => array(
					'Authorization'     => $upload_target['authorization_token'],
					'Content-Type'      => $mime_type,
					'Content-Length'    => (string) $size_bytes,
					'X-Bz-File-Name'    => self::encode_object_key( $object_key ),
					'X-Bz-Content-Sha1' => $sha1,
					'User-Agent'        => self::user_agent(),
				),
				'body'        => $bytes,
				'data_format' => 'body',
			)
		);

		if ( is_wp_error( $response ) ) {
			$transport_code = sanitize_key( $response->get_error_code() );
			return new \WP_Error(
				self::diagnostic_error_code( 'b2_upload_failed', 0, $transport_code ? 'transport_' . $transport_code : 'transport' ),
				'De Backblaze-verbinding is tijdelijk niet beschikbaar.',
				array( 'retry_with_new_upload_url' => true )
			);
		}

		$status    = (int) wp_remote_retrieve_response_code( $response );
		$decoded   = json_decode( wp_remote_retrieve_body( $response ), true );
		$b2_code   = is_array( $decoded ) && isset( $decoded['code'] ) ? sanitize_key( $decoded['code'] ) : '';
		$retryable = 408 === $status
			|| 429 === $status
			|| $status >= 500
			|| ( 401 === $status && in_array( $b2_code, array( 'bad_auth_token', 'expired_auth_token' ), true ) );

		if ( $status < 200 || $status >= 300 || ! is_array( $decoded ) ) {
			return new \WP_Error(
				self::diagnostic_error_code( 'b2_upload_failed', $status, $b2_code ? $b2_code : 'invalid_response' ),
				'Backblaze heeft het verzoek niet geaccepteerd.',
				array( 'retry_with_new_upload_url' => $retryable )
			);
		}

		return $decoded;
	}

	private function validate_local_document( array $document ) {
		if ( ! UploadProvenance::verify_document( $document ) ) {
			return new \WP_Error( 'document_provenance_invalid', 'Het document mist een geldig serverbewijs voor deze inzending.' );
		}
		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) || empty( $uploads['baseurl'] ) ) {
			return new \WP_Error( 'uploads_directory_unavailable', 'De WordPress-uploadmap is niet beschikbaar.' );
		}

		$path = isset( $document['local_path'] ) ? (string) $document['local_path'] : '';
		$url  = isset( $document['local_url'] ) ? (string) $document['local_url'] : '';
		$base_url = rtrim( (string) $uploads['baseurl'], '/' );
		if ( '' === $path && '' !== $url && 0 === strpos( $url, $base_url . '/' ) ) {
			$url_path  = (string) wp_parse_url( $url, PHP_URL_PATH );
			$base_path = rtrim( (string) wp_parse_url( $base_url, PHP_URL_PATH ), '/' );
			$relative  = rawurldecode( substr( $url_path, strlen( $base_path ) ) );
			$path     = rtrim( $uploads['basedir'], '/\\' ) . '/' . ltrim( $relative, '/\\' );
		}

		$base_real = realpath( $uploads['basedir'] );
		$path_real = $path ? realpath( $path ) : false;
		if ( false === $base_real || false === $path_real ) {
			return new \WP_Error( 'document_path_missing', 'Het lokale document bestaat niet.' );
		}

		$base_real = rtrim( wp_normalize_path( $base_real ), '/' ) . '/';
		$path_real = wp_normalize_path( $path_real );
		if ( 0 !== strpos( $path_real, $base_real ) || ! is_file( $path_real ) || ! is_readable( $path_real ) ) {
			return new \WP_Error( 'document_path_not_allowed', 'Het document staat niet in de WordPress-uploadmap.' );
		}

		$extension = isset( $document['extension'] ) ? strtolower( (string) $document['extension'] ) : '';
		$types = array(
			'pdf'  => 'application/pdf',
			'doc'  => 'application/msword',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		);
		if ( ! isset( $types[ $extension ] ) ) {
			return new \WP_Error( 'document_type_not_allowed', 'Alleen PDF-, DOC- en DOCX-documenten zijn toegestaan.' );
		}

		if ( function_exists( 'wp_check_filetype_and_ext' ) ) {
			$checked = wp_check_filetype_and_ext(
				$path_real,
				isset( $document['original_filename'] ) ? (string) $document['original_filename'] : basename( $path_real ),
				array(
					'pdf'  => 'application/pdf',
					'doc'  => 'application/msword',
					'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				)
			);
			if ( empty( $checked['ext'] ) || strtolower( (string) $checked['ext'] ) !== $extension ) {
				return new \WP_Error( 'document_content_not_allowed', 'De documentinhoud past niet bij de bestandsextensie.' );
			}
		}

		$size          = filesize( $path_real );
		$wordpress_max = function_exists( 'wp_max_upload_size' ) ? (int) wp_max_upload_size() : 0;
		$maximum_size  = $wordpress_max > 0 ? min( $wordpress_max, 20 * 1024 * 1024 ) : 20 * 1024 * 1024;
		if ( false === $size || $size < 1 || $size > $maximum_size ) {
			return new \WP_Error( 'document_size_not_allowed', 'Het document is leeg of groter dan de toegestane uploadlimiet van maximaal 20 MB.' );
		}

		return array(
			'path'         => $path_real,
			'mime_type'    => $types[ $extension ],
			'size_bytes'   => (int) $size,
			'maximum_size' => $maximum_size,
		);
	}

	private function authorize() {
		if ( is_array( $this->authorization ) ) {
			return $this->authorization;
		}

		$response = wp_remote_get(
			'https://api.backblazeb2.com/b2api/v4/b2_authorize_account',
			array(
				'timeout'     => 20,
				'redirection' => 0,
				'sslverify'   => true,
				'headers'     => array(
					'Authorization' => 'Basic ' . base64_encode( TFSC_B2_APPLICATION_KEY_ID . ':' . TFSC_B2_APPLICATION_KEY ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
					'User-Agent'    => self::user_agent(),
				),
			)
		);

		$decoded = $this->decode_response( $response, 'b2_authorization_failed' );
		if ( is_wp_error( $decoded ) ) {
			return $decoded;
		}

		$storage_api = isset( $decoded['apiInfo']['storageApi'] ) && is_array( $decoded['apiInfo']['storageApi'] )
			? $decoded['apiInfo']['storageApi']
			: array();
		$allowed = isset( $storage_api['allowed'] ) && is_array( $storage_api['allowed'] ) ? $storage_api['allowed'] : array();
		$caps    = isset( $allowed['capabilities'] ) && is_array( $allowed['capabilities'] ) ? $allowed['capabilities'] : array();

		if ( empty( $decoded['authorizationToken'] ) || empty( $storage_api['apiUrl'] ) || ! in_array( 'writeFiles', $caps, true ) ) {
			return new \WP_Error( 'b2_key_not_allowed', 'De Backblaze-sleutel mist de vereiste schrijfrechten.' );
		}

		$bucket_id = trim( (string) TFSC_B2_BUCKET_ID );
		$allowed_bucket_ids = array();
		if ( isset( $allowed['buckets'] ) && is_array( $allowed['buckets'] ) ) {
			foreach ( $allowed['buckets'] as $bucket ) {
				if ( is_array( $bucket ) && isset( $bucket['id'] ) && is_scalar( $bucket['id'] ) ) {
					$allowed_bucket_ids[] = trim( (string) $bucket['id'] );
				}
			}
		}

		// Compatibility with v3 authorization responses. The production client
		// uses v4, where bucket restrictions live in allowed.buckets[].id.
		if ( isset( $allowed['bucketId'] ) && is_scalar( $allowed['bucketId'] ) ) {
			$allowed_bucket_ids[] = trim( (string) $allowed['bucketId'] );
		}
		$allowed_bucket_ids = array_values( array_unique( array_filter( $allowed_bucket_ids, 'strlen' ) ) );
		if ( 1 !== count( $allowed_bucket_ids ) || $allowed_bucket_ids[0] !== $bucket_id ) {
			return new \WP_Error( 'b2_bucket_not_allowed', 'De Backblaze-sleutel is niet aan de ingestelde bucket gekoppeld.' );
		}

		if ( ! isset( $allowed['namePrefix'] ) || 'documents/' !== (string) $allowed['namePrefix'] ) {
			return new \WP_Error( 'b2_prefix_not_allowed', 'De Backblaze-sleutel moet exact tot documents/ beperkt zijn.' );
		}

		$this->authorization = array(
			'authorization_token' => (string) $decoded['authorizationToken'],
			'api_url'             => rtrim( (string) $storage_api['apiUrl'], '/' ),
			'bucket_id'           => $bucket_id,
			'name_prefix'         => isset( $allowed['namePrefix'] ) ? (string) $allowed['namePrefix'] : '',
		);

		return $this->authorization;
	}

	private function get_upload_url( array $authorized ) {
		$url = $authorized['api_url'] . '/b2api/v4/b2_get_upload_url?bucketId=' . rawurlencode( $authorized['bucket_id'] );
		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 20,
				'redirection' => 0,
				'sslverify'   => true,
				'headers'     => array(
					'Authorization' => $authorized['authorization_token'],
					'User-Agent'    => self::user_agent(),
				),
			)
		);

		$decoded = $this->decode_response( $response, 'b2_upload_url_failed' );
		if ( is_wp_error( $decoded ) ) {
			return $decoded;
		}

		if ( empty( $decoded['uploadUrl'] ) || empty( $decoded['authorizationToken'] ) ) {
			return new \WP_Error( 'b2_upload_url_invalid', 'Backblaze gaf geen geldige upload-URL.' );
		}

		return array(
			'upload_url'          => (string) $decoded['uploadUrl'],
			'authorization_token' => (string) $decoded['authorizationToken'],
		);
	}

	private function decode_response( $response, $error_code ) {
		if ( is_wp_error( $response ) ) {
			$transport_code = sanitize_key( $response->get_error_code() );
			return new \WP_Error(
				self::diagnostic_error_code( $error_code, 0, $transport_code ? 'transport_' . $transport_code : 'transport' ),
				'De Backblaze-verbinding is tijdelijk niet beschikbaar.'
			);
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$decoded  = json_decode( wp_remote_retrieve_body( $response ), true );
		$b2_code  = is_array( $decoded ) && isset( $decoded['code'] ) ? sanitize_key( $decoded['code'] ) : '';
		if ( $status < 200 || $status >= 300 || ! is_array( $decoded ) ) {
			return new \WP_Error(
				self::diagnostic_error_code( $error_code, $status, $b2_code ? $b2_code : 'invalid_response' ),
				'Backblaze heeft het verzoek niet geaccepteerd.'
			);
		}

		return $decoded;
	}

	private static function diagnostic_error_code( $base, $status, $remote_code ) {
		$parts = array( sanitize_key( $base ) );
		if ( (int) $status > 0 ) {
			$parts[] = 'http_' . (int) $status;
		}
		$remote_code = sanitize_key( $remote_code );
		if ( '' !== $remote_code ) {
			$parts[] = $remote_code;
		}

		return substr( implode( '_', $parts ), 0, 64 );
	}

	private static function user_agent() {
		$version = defined( 'TFSC_FORM_BRIDGE_VERSION' ) ? (string) TFSC_FORM_BRIDGE_VERSION : 'unknown';
		$version = preg_replace( '/[^0-9A-Za-z._-]/', '', $version );
		return 'tfsc-form-bridge/' . ( $version ? $version : 'unknown' ) . ' WordPress';
	}
}
