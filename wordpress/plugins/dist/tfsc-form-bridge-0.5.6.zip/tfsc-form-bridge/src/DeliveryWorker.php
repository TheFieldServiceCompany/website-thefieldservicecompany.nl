<?php

namespace TFSC\FormBridge;

final class DeliveryWorker {
	const HOOK = 'tfsc_form_bridge_deliver';
	const SCHEDULE = 'tfsc_form_bridge_five_minutes';
	const MAX_ATTEMPTS = 8;

	/** @var OutboxRepository */
	private $outbox;

	/** @var BackblazeClient */
	private $backblaze;

	public function __construct( OutboxRepository $outbox ) {
		$this->outbox    = $outbox;
		$this->backblaze = new BackblazeClient();
	}

	public function register() {
		add_filter( 'cron_schedules', array( $this, 'add_schedule' ) );
		add_action( self::HOOK, array( $this, 'run' ) );
		add_action( 'init', array( $this, 'ensure_scheduled' ) );
	}

	public function add_schedule( array $schedules ) {
		$schedules[ self::SCHEDULE ] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => 'Iedere vijf minuten (TFSC Form Bridge)',
		);
		return $schedules;
	}

	public function ensure_scheduled() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::SCHEDULE, self::HOOK );
		}
	}

	public function run() {
		$config = $this->configuration();
		if ( is_wp_error( $config ) ) {
			return 0;
		}

		$rows = $this->outbox->claim_due( 10 );
		foreach ( $rows as $row ) {
			$this->deliver_row( $row, $config );
		}

		return count( $rows );
	}

	public static function signature( $secret, $timestamp, $body ) {
		return 'v1=' . hash_hmac( 'sha256', (string) $timestamp . '.' . (string) $body, (string) $secret );
	}

	public static function is_configured() {
		$endpoint = defined( 'TFSC_FORM_BRIDGE_ENDPOINT' ) ? trim( (string) TFSC_FORM_BRIDGE_ENDPOINT ) : '';
		$secret   = defined( 'TFSC_FORM_BRIDGE_HMAC_SECRET' ) ? (string) TFSC_FORM_BRIDGE_HMAC_SECRET : '';

		return '' !== $endpoint
			&& 'https' === wp_parse_url( $endpoint, PHP_URL_SCHEME )
			&& strlen( $secret ) >= 32;
	}

	public static function classify_response( $http_code, $payload ) {
		$http_code = (int) $http_code;
		$payload   = is_array( $payload ) ? $payload : array();

		if ( in_array( $http_code, array( 200, 202 ), true ) && ! empty( $payload['ok'] ) ) {
			return array(
				'action'          => 'delivered',
				'requires_review' => ! empty( $payload['requires_review'] ) || ( isset( $payload['processing_status'] ) && 'review' === $payload['processing_status'] ),
				'code'            => '',
			);
		}

		if ( in_array( $http_code, array( 400, 401, 403, 405, 413, 415 ), true ) ) {
			return array( 'action' => 'failed', 'requires_review' => false, 'code' => 'remote_http_' . $http_code );
		}

		if ( 422 === $http_code || 429 === $http_code || $http_code >= 500 || 0 === $http_code ) {
			return array( 'action' => 'retry', 'requires_review' => false, 'code' => 'remote_http_' . $http_code );
		}

		return array( 'action' => 'failed', 'requires_review' => false, 'code' => 'remote_http_' . $http_code );
	}

	/**
	 * Bounded retry schedule. Null means the item reached its final attempt.
	 */
	public static function retry_delay_seconds( $attempts ) {
		$attempts = max( 1, (int) $attempts );
		if ( $attempts >= self::MAX_ATTEMPTS ) {
			return null;
		}

		$delays = array( 60, 300, 900, 3600, 21600, 43200, 86400 );
		$index  = max( 0, min( count( $delays ) - 1, $attempts - 1 ) );
		return $delays[ $index ];
	}

	/**
	 * Proves endpoint reachability and HMAC agreement without creating intake data.
	 *
	 * The receiver authenticates this dedicated request type and returns HTTP
	 * 200 before any database client or intake processing is used.
	 *
	 * @return true|\WP_Error
	 */
	public function test_connection() {
		$config = $this->configuration();
		if ( is_wp_error( $config ) ) {
			return $config;
		}

		$submission_id = '00000000-0000-4000-8000-000000000000';
		$response = $this->post_signed_json(
			$config,
			$submission_id,
			array(
				'request_type'  => 'connection_test',
				'submission_id' => $submission_id,
			)
		);

		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'connection_test_transport', 'De ontvanger kon niet via HTTPS worden bereikt.' );
		}

		$status  = wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		$code    = is_array( $decoded ) && isset( $decoded['code'] ) ? (string) $decoded['code'] : '';

		if ( 200 === (int) $status && ! empty( $decoded['ok'] ) && 'connection_ok' === $code && isset( $decoded['database_touched'] ) && false === $decoded['database_touched'] ) {
			return true;
		}

		if ( 401 === (int) $status ) {
			return new \WP_Error( 'connection_test_auth', 'De ontvanger is bereikbaar, maar de HMAC-sleutels komen niet overeen.' );
		}

		return new \WP_Error(
			'connection_test_unexpected',
			sprintf( 'De ontvanger gaf een onverwacht antwoord (HTTP %d, %s).', (int) $status, $code ? $code : 'geen foutcode' )
		);
	}

	private function configuration() {
		$endpoint = defined( 'TFSC_FORM_BRIDGE_ENDPOINT' ) ? trim( (string) TFSC_FORM_BRIDGE_ENDPOINT ) : '';
		$secret   = defined( 'TFSC_FORM_BRIDGE_HMAC_SECRET' ) ? (string) TFSC_FORM_BRIDGE_HMAC_SECRET : '';

		if ( '' === $endpoint || 'https' !== wp_parse_url( $endpoint, PHP_URL_SCHEME ) ) {
			return new \WP_Error( 'delivery_endpoint_missing', 'De beveiligde HTTPS-ontvanger is niet geconfigureerd.' );
		}

		if ( strlen( $secret ) < 32 ) {
			return new \WP_Error( 'delivery_secret_missing', 'Het aflevergeheim is niet geconfigureerd.' );
		}

		return array(
			'endpoint' => $endpoint,
			'secret'   => $secret,
		);
	}

	private function deliver_row( array $row, array $config ) {
		$local_body    = isset( $row['payload'] ) ? (string) $row['payload'] : '';
		$submission_id = isset( $row['submission_uuid'] ) ? (string) $row['submission_uuid'] : '';
		$attempts      = isset( $row['attempts'] ) ? (int) $row['attempts'] : 1;

		$envelope = json_decode( $local_body, true );
		if ( '' === $local_body || '' === $submission_id || ! is_array( $envelope ) ) {
			$this->outbox->mark_failed( $row['id'], 'invalid_outbox_row' );
			return;
		}

		$remote_envelope = EnvelopeSanitizer::for_receiver( $envelope );
		$response        = $this->post_signed_json( $config, $submission_id, $remote_envelope );

		if ( is_wp_error( $response ) ) {
			$this->retry_or_fail( $row['id'], $attempts, 'remote_transport_error' );
			return;
		}

		$http_code = wp_remote_retrieve_response_code( $response );
		$decoded   = json_decode( wp_remote_retrieve_body( $response ), true );
		$result    = self::classify_response( $http_code, $decoded );

		if ( 'delivered' === $result['action'] ) {
			$documents_result = $this->process_documents( $row, $envelope, $decoded, $config );
			if ( is_wp_error( $documents_result ) ) {
				$error_code = $documents_result->get_error_code();
				if ( $this->is_permanent_document_error( $error_code ) ) {
					$this->outbox->mark_review( $row['id'], $error_code );
				} else {
					$this->retry_or_fail( $row['id'], $attempts, $error_code );
				}
				return;
			}

			$this->outbox->mark_delivered( $row['id'], $result['requires_review'] );
			return;
		}

		if ( 'retry' === $result['action'] ) {
			$this->retry_or_fail( $row['id'], $attempts, $result['code'] );
			return;
		}

		$this->outbox->mark_failed( $row['id'], $result['code'] );
	}

	private function process_documents( array $row, array $envelope, array $receipt, array $config ) {
		if ( isset( $row['document_state'] ) && '' !== (string) $row['document_state'] ) {
			$documents = json_decode( $row['document_state'], true );
			if ( ! is_array( $documents ) ) {
				return new \WP_Error( 'document_state_invalid', 'De lokale documentstatus is ongeldig.' );
			}
		} else {
			$documents = DocumentManifest::from_envelope( $envelope );
			if ( ! $this->outbox->save_document_state( $row['id'], $documents ) ) {
				return new \WP_Error( 'document_state_save_failed', 'De lokale documentstatus kon niet worden opgeslagen.' );
			}
		}

		foreach ( $documents as $index => $document ) {
			if ( ! is_array( $document ) || 'registered' === ( isset( $document['status'] ) ? $document['status'] : '' ) ) {
				continue;
			}
			if ( ! UploadProvenance::verify_document( $document ) ) {
				return new \WP_Error( 'document_provenance_invalid', 'Het document moet gecontroleerd worden voordat het kan worden verwerkt.' );
			}

			$is_candidate_document = 'candidate.cv_files' === $document['target'];
			$is_vacancy_document   = 'company.vacancy_files' === $document['target'];

			if ( $is_vacancy_document && empty( $receipt['company_id'] ) ) {
				return new \WP_Error( 'vacancy_document_target_missing', 'De vacaturebijlage kan niet aan een werkgever worden gekoppeld.' );
			}

			if ( ! $is_candidate_document && ! $is_vacancy_document ) {
				return new \WP_Error( 'document_target_invalid', 'Het documentdoel wordt niet ondersteund.' );
			}

			if ( 'uploaded' !== ( isset( $document['status'] ) ? $document['status'] : '' ) ) {
				$upload = $this->backblaze->upload( $document );
				if ( is_wp_error( $upload ) ) {
					return $upload;
				}

				$document = array_merge( $document, $upload, array( 'status' => 'uploaded' ) );
				$documents[ $index ] = $document;
				if ( ! $this->outbox->save_document_state( $row['id'], $documents ) ) {
					return new \WP_Error( 'document_state_save_failed', 'De uploadstatus kon niet worden opgeslagen.' );
				}
			}

			$registration = array(
				'request_type'      => $is_candidate_document ? 'candidate_document_registration' : 'vacancy_document_registration',
				'submission_id'     => (string) $row['submission_uuid'],
				'document_id'       => $document['document_id'],
				'original_filename' => $document['original_filename'],
				'mime_type'         => $document['mime_type'],
				'size_bytes'        => (int) $document['size_bytes'],
				'object_key'        => $document['object_key'],
				'storage_bucket'    => BackblazeClient::bucket_name(),
				'storage_region'    => BackblazeClient::region(),
				'b2_file_id'        => $document['b2_file_id'],
				'content_sha1'      => $document['content_sha1'],
			);

			if ( $is_candidate_document && ! empty( $receipt['candidate_profile_id'] ) ) {
				$registration['candidate_profile_id'] = (string) $receipt['candidate_profile_id'];
			} else {
				$registration['company_id'] = (string) $receipt['company_id'];
			}

			$response = $this->post_signed_json( $config, (string) $row['submission_uuid'], $registration );
			if ( is_wp_error( $response ) ) {
				return new \WP_Error( 'document_registration_unavailable', 'De documentregistratie is tijdelijk niet beschikbaar.' );
			}

			$status  = wp_remote_retrieve_response_code( $response );
			$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( ! in_array( (int) $status, array( 200, 202 ), true ) || empty( $decoded['ok'] ) ) {
				return new \WP_Error( 'document_registration_failed', 'De documentmetadata is niet geaccepteerd.' );
			}

			$documents[ $index ]['status'] = 'registered';
			if ( $is_vacancy_document && ! empty( $decoded['vacancy_id'] ) ) {
				$documents[ $index ]['vacancy_id'] = (string) $decoded['vacancy_id'];
			}
			if ( ! $this->outbox->save_document_state( $row['id'], $documents ) ) {
				return new \WP_Error( 'document_state_save_failed', 'De documentregistratie kon lokaal niet worden bevestigd.' );
			}

			if ( $this->delete_private_staging_file( $documents[ $index ] ) ) {
				$documents[ $index ]['local_path'] = '';
				$this->outbox->save_document_state( $row['id'], $documents );
			}
		}

		return true;
	}

	private function delete_private_staging_file( array $document ) {
		$path = isset( $document['local_path'] ) ? (string) $document['local_path'] : '';
		if ( '' === $path ) {
			return false;
		}

		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) ) {
			return false;
		}

		$staging_real = realpath( rtrim( $uploads['basedir'], '/\\' ) . '/tfsc-form-bridge' );
		$path_real    = realpath( $path );
		if ( false === $staging_real || false === $path_real ) {
			return false;
		}

		$staging_real = rtrim( wp_normalize_path( $staging_real ), '/' ) . '/';
		$path_real    = wp_normalize_path( $path_real );
		if ( 0 !== strpos( $path_real, $staging_real ) || ! is_file( $path_real ) ) {
			return false;
		}

		if ( function_exists( 'wp_delete_file' ) ) {
			wp_delete_file( $path_real );
			return ! file_exists( $path_real );
		}

		return @unlink( $path_real );
	}

	private function post_signed_json( array $config, $submission_id, array $payload ) {
		$body = wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $body ) {
			return new \WP_Error( 'payload_encoding_failed', 'Het afleververzoek kon niet worden gecodeerd.' );
		}

		$timestamp = time();
		return wp_remote_post(
			$config['endpoint'],
			array(
				'timeout'     => 20,
				'redirection' => 0,
				'sslverify'   => true,
				'headers'     => array(
					'Content-Type'         => 'application/json',
					'X-TFSC-Timestamp'     => (string) $timestamp,
					'X-TFSC-Signature'     => self::signature( $config['secret'], $timestamp, $body ),
					'X-TFSC-Submission-ID' => (string) $submission_id,
				),
				'body'        => $body,
				'data_format' => 'body',
			)
		);
	}

	private function is_permanent_document_error( $error_code ) {
		$error_code = (string) $error_code;
		if ( in_array(
			$error_code,
			array(
				'document_state_invalid',
				'document_provenance_invalid',
				'vacancy_document_target_missing',
				'document_target_invalid',
				'document_path_missing',
				'document_path_not_allowed',
				'document_type_not_allowed',
				'document_content_not_allowed',
				'document_size_not_allowed',
				'b2_object_key_invalid',
				'b2_prefix_not_allowed',
				'b2_key_not_allowed',
				'b2_bucket_not_allowed',
			),
			true
		) ) {
			return true;
		}

		if ( 1 === preg_match( '/^b2_upload_failed_http_401_(?:bad_auth_token|expired_auth_token)$/', $error_code ) ) {
			return false;
		}

		return 1 === preg_match(
			'/^b2_(?:authorization|upload_url)_failed_http_(?:400|401|403)(?:_|$)|^b2_upload_failed_http_(?:400|401|403|405|411|415)(?:_|$)/',
			$error_code
		);
	}

	private function retry_or_fail( $id, $attempts, $error_code ) {
		$delay = self::retry_delay_seconds( $attempts );
		if ( null === $delay ) {
			$this->outbox->mark_failed( $id, $error_code );
			return;
		}

		$this->outbox->mark_retry( $id, $error_code, $delay );
	}
}
