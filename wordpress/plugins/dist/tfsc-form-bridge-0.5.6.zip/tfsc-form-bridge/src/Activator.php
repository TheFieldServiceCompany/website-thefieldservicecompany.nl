<?php

namespace TFSC\FormBridge;

final class Activator {
	public static function maybe_upgrade() {
		if ( TFSC_FORM_BRIDGE_VERSION !== get_option( 'tfsc_form_bridge_db_version' ) ) {
			self::activate();
		}
	}

	public static function activate() {
		global $wpdb;

		$table_name       = $wpdb->prefix . 'tfsc_form_bridge_outbox';
		$diagnostic_table = $wpdb->prefix . DiagnosticRepository::TABLE_SUFFIX;
		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			submission_uuid char(36) NOT NULL,
			builder varchar(32) NOT NULL,
			form_key varchar(191) NOT NULL,
			form_type varchar(64) NOT NULL,
			mapping_version bigint(20) unsigned NOT NULL DEFAULT 1,
			payload longtext NOT NULL,
			document_state longtext NULL,
			status varchar(24) NOT NULL DEFAULT 'pending',
			attempts smallint(5) unsigned NOT NULL DEFAULT 0,
			next_attempt_at datetime NULL,
			last_error_code varchar(64) NULL,
			last_error_message varchar(255) NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY submission_uuid (submission_uuid),
			KEY status_next (status, next_attempt_at),
			KEY form_created (form_key, created_at)
		) {$charset_collate};";

		dbDelta( $sql );

		$diagnostic_sql = "CREATE TABLE {$diagnostic_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			request_uuid char(36) NOT NULL,
			builder varchar(32) NOT NULL,
			form_key varchar(191) NOT NULL,
			form_type varchar(64) NOT NULL,
			source varchar(24) NOT NULL DEFAULT 'server',
			stage varchar(48) NOT NULL DEFAULT 'request_received',
			status varchar(24) NOT NULL DEFAULT 'started',
			http_status smallint(5) unsigned NULL,
			error_code varchar(96) NULL,
			error_fields text NULL,
			upload_count smallint(5) unsigned NOT NULL DEFAULT 0,
			upload_bytes bigint(20) unsigned NOT NULL DEFAULT 0,
			upload_error_codes text NULL,
			duration_ms bigint(20) unsigned NULL,
			client_ip varchar(255) NULL,
			page_url text NULL,
			previous_url text NULL,
			browser_summary varchar(255) NULL,
			user_agent text NULL,
			request_data longtext NULL,
			upload_details longtext NULL,
			response_body longtext NULL,
			fatal_data longtext NULL,
			environment_data text NULL,
			submission_uuid char(36) NULL,
			outbox_id bigint(20) unsigned NULL,
			outbox_status varchar(24) NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY request_uuid (request_uuid),
			KEY status_created (status, created_at),
			KEY form_created (form_key, created_at),
			KEY submission_uuid (submission_uuid)
		) {$charset_collate};";

		dbDelta( $diagnostic_sql );

		add_option( MappingRepository::OPTION_NAME, array(), '', false );
		$retention = absint( get_option( DiagnosticRepository::RETENTION_OPTION, 0 ) );
		if ( ! in_array( $retention, DiagnosticRepository::allowed_retention_days(), true ) ) {
			update_option( DiagnosticRepository::RETENTION_OPTION, DiagnosticRepository::DEFAULT_RETENTION_DAYS, false );
		}
		$max_records = absint( get_option( DiagnosticRepository::MAX_RECORDS_OPTION, 0 ) );
		if ( ! in_array( $max_records, DiagnosticRepository::allowed_max_records(), true ) ) {
			update_option( DiagnosticRepository::MAX_RECORDS_OPTION, DiagnosticRepository::DEFAULT_MAX_RECORDS, false );
		}
		update_option( 'tfsc_form_bridge_db_version', TFSC_FORM_BRIDGE_VERSION, false );

		if ( ! wp_next_scheduled( DiagnosticRepository::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', DiagnosticRepository::CLEANUP_HOOK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( DeliveryWorker::HOOK );
		wp_clear_scheduled_hook( DiagnosticRepository::CLEANUP_HOOK );
	}
}
