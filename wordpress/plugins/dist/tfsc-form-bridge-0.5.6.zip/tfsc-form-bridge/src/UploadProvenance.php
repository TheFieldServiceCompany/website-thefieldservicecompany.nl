<?php
namespace TFSC\FormBridge;

/** Private server proof for documents accepted by a builder's upload adapter. */
final class UploadProvenance {
 const KEY_OPTION = '_tfsc_fb_upload_proof_key';
 private static function key( $create = false ) {
  $key = get_option( self::KEY_OPTION, '' );
  if ( ! $key && $create ) {
   try { $generated = bin2hex( random_bytes( 32 ) ); } catch ( \Exception $error ) { return ''; }
   global $wpdb;
   $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')", self::KEY_OPTION, $generated ) );
   wp_cache_delete( self::KEY_OPTION, 'options' ); wp_cache_delete( 'notoptions', 'options' );
   $key = get_option( self::KEY_OPTION, '' );
  }
  return is_string( $key ) && preg_match( '/^[a-f0-9]{64}$/D', $key ) ? $key : '';
 }
 private static function signature( $submission, $field, $index, $name, $path, $url, $key ) {
  return hash_hmac( 'sha256', wp_json_encode( [ get_current_blog_id(), (string) $submission, (string) $field, (int) $index, (string) $name, (string) $path, (string) $url ] ), $key );
 }
 /** Only called with the adapter's server-owned upload list, never posted fields. */
 public static function seal( $submission, $field, $index, array $file ) {
  $key = self::key( true );
  return $key ? self::signature( $submission, $field, $index, $file['name'], $file['path'], $file['url'], $key ) : '';
 }
 public static function verify_document( array $document ) {
  $key = self::key();
  $proof = $document['upload_proof'] ?? null;
  if ( ! $key || ! is_string( $proof ) || ! preg_match( '/^[a-f0-9]{64}$/D', $proof ) ) { return false; }
  foreach ( [ 'submission_id', 'source_field', 'source_index', 'original_filename', 'local_path', 'local_url' ] as $field ) {
   if ( ! isset( $document[$field] ) || ! is_scalar( $document[$field] ) ) { return false; }
  }
  return hash_equals( self::signature( $document['submission_id'], $document['source_field'], $document['source_index'], $document['original_filename'], $document['local_path'], $document['local_url'], $key ), $proof );
 }
}
