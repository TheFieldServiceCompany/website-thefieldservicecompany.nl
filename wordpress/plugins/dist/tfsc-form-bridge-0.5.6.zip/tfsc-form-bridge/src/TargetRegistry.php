<?php

namespace TFSC\FormBridge;

final class TargetRegistry {
	public function form_types() {
		return array(
			'vacancy_application'  => 'Sollicitatie op vacature',
			'advice_request'       => 'Adviesaanvraag',
			'question'             => 'Algemene vraag of vacaturevraag',
			'open_registration'    => 'Open registratie/inschrijving',
			'mailing_subscription' => 'Mailingregistratie',
			'employer_request'     => 'Werkgeversaanvraag',
		);
	}

	public function form_type_defaults( $form_type ) {
		$defaults = array(
			'vacancy_application'  => array( 'create_candidate' => true, 'create_company' => false ),
			'advice_request'       => array( 'create_candidate' => true, 'create_company' => false ),
			'question'             => array( 'create_candidate' => true, 'create_company' => false ),
			'open_registration'    => array( 'create_candidate' => true, 'create_company' => false ),
			'mailing_subscription' => array( 'create_candidate' => true, 'create_company' => false ),
			'employer_request'     => array( 'create_candidate' => false, 'create_company' => true ),
		);

		return isset( $defaults[ $form_type ] ) ? $defaults[ $form_type ] : array(
			'create_candidate' => false,
			'create_company'   => false,
		);
	}

	public function targets() {
		return array(
			'person.first_name'               => array( 'label' => 'Persoon - voornaam', 'group' => 'Persoon', 'type' => 'string' ),
			'person.last_name'                => array( 'label' => 'Persoon - achternaam', 'group' => 'Persoon', 'type' => 'string' ),
			'person.email'                    => array( 'label' => 'Persoon - e-mail', 'group' => 'Persoon', 'type' => 'email' ),
			'person.mobile'                   => array( 'label' => 'Persoon - mobiel', 'group' => 'Persoon', 'type' => 'phone' ),
			'person.phone'                    => array( 'label' => 'Persoon - vast telefoonnummer', 'group' => 'Persoon', 'type' => 'phone' ),
			'person.city'                     => array( 'label' => 'Persoon - woonplaats (primair adres)', 'group' => 'Persoon', 'type' => 'string' ),
			'person.linkedin_url'             => array( 'label' => 'Persoon - LinkedIn-profiel', 'group' => 'Persoon', 'type' => 'url' ),
			'candidate.cv_files'              => array( 'label' => 'Kandidaat - cv naar Backblaze', 'group' => 'Kandidaat', 'type' => 'file_list' ),
			'candidate.ambition'              => array( 'label' => 'Kandidaat - wensen/ambitie', 'group' => 'Kandidaat', 'type' => 'multiline' ),
			'candidate.employment_preferences' => array( 'label' => 'Kandidaat - gewenst dienstverband', 'group' => 'Kandidaat', 'type' => 'list' ),
			'vacancy.number'                  => array( 'label' => 'Vacature - vacaturenummer', 'group' => 'Vacaturecontext', 'type' => 'string' ),
			'interaction.message'             => array( 'label' => 'Contact - vraag/opmerking', 'group' => 'Contact', 'type' => 'multiline' ),
			'privacy.accepted'                => array( 'label' => 'Privacyverklaring akkoord', 'group' => 'Toestemming', 'type' => 'boolean' ),
			'mailing.employment_types'        => array( 'label' => 'Mailing - dienstverbanden', 'group' => 'Mailing', 'type' => 'list' ),
			'mailing.work_areas'              => array( 'label' => 'Mailing - werkgebieden', 'group' => 'Mailing', 'type' => 'list' ),
			'company.name'                    => array( 'label' => 'Werkgever - bedrijfsnaam', 'group' => 'Werkgever', 'type' => 'string' ),
			'company.vacancy_url'             => array( 'label' => 'Werkgever - vacaturelink', 'group' => 'Werkgever', 'type' => 'url' ),
			'company.vacancy_files'           => array( 'label' => 'Werkgever - vacaturebijlagen naar Backblaze', 'group' => 'Werkgever', 'type' => 'file_list' ),
			'source.page_title'               => array( 'label' => 'Bron - oorspronkelijke paginatitel', 'group' => 'Bron', 'type' => 'string' ),
			'source.page_url'                 => array( 'label' => 'Bron - oorspronkelijke pagina-URL', 'group' => 'Bron', 'type' => 'url' ),
		);
	}

	public function has_target( $target ) {
		return isset( $this->targets()[ $target ] );
	}

	public function get( $target ) {
		$targets = $this->targets();
		return isset( $targets[ $target ] ) ? $targets[ $target ] : null;
	}

	public function has_form_type( $form_type ) {
		return isset( $this->form_types()[ $form_type ] );
	}

	public function suggested_target( $field_id, $field_type, $form_type = '' ) {
		$field_id = strtolower( (string) $field_id );

		$exact = array(
			'first_name'       => 'person.first_name',
			'voornaam'         => 'person.first_name',
			'last_name'        => 'person.last_name',
			'surname'          => 'person.last_name',
			'achternaam'       => 'person.last_name',
			'email'            => 'person.email',
			'mobile'           => 'person.mobile',
			'mobiel'           => 'person.mobile',
			'phone'            => 'person.phone',
			'telefoon_vast'    => 'person.phone',
			'city'             => 'person.city',
			'woonplaats'       => 'person.city',
			'linkedin_url'     => 'person.linkedin_url',
			'linkedin'         => 'person.linkedin_url',
			'cv'               => 'candidate.cv_files',
			'cv_upload'        => 'candidate.cv_files',
			'ambition'         => 'candidate.ambition',
			'wensen'           => 'candidate.ambition',
			'employment_preferences' => 'candidate.employment_preferences',
			'wens_dienstverband' => 'candidate.employment_preferences',
			'vacancy_number'   => 'vacancy.number',
			'vacaturenummer'   => 'vacancy.number',
			'vraag'            => 'interaction.message',
			'message'          => 'interaction.message',
			'privacy_consent'  => 'privacy.accepted',
			'form_privacy'     => 'privacy.accepted',
			'field_944d626'    => 'privacy.accepted',
			'field_cadabc8'    => 'privacy.accepted',
			'companyname'      => 'company.name',
			'field_ef49d3a'    => 'company.vacancy_url',
			'vacatures'        => 'company.vacancy_files',
			'posttitle'        => 'source.page_title',
			'posturl'          => 'source.page_url',
		);

		if ( 'mailing_subscription' === $form_type ) {
			if ( in_array( $field_id, array( 'dienstverband', 'mailing_employment_types' ), true ) ) {
				return 'mailing.employment_types';
			}
			if ( in_array( $field_id, array( 'werkgebied', 'mailing_work_areas' ), true ) ) {
				return 'mailing.work_areas';
			}
		}

		if ( 'employer_request' === $form_type ) {
			if ( 'company_name' === $field_id ) {
				return 'company.name';
			}
			if ( 'vacancy_url' === $field_id ) {
				return 'company.vacancy_url';
			}
			if ( 'vacancy_files' === $field_id ) {
				return 'company.vacancy_files';
			}
		}

		return isset( $exact[ $field_id ] ) ? $exact[ $field_id ] : '';
	}
}
