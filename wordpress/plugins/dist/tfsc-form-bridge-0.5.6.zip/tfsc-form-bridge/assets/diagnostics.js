(function ($) {
	'use strict';

	var navigationKey = 'tfsc_form_bridge_navigation';

	function field(data, key) {
		if (window.FormData && data instanceof window.FormData) {
			return data.get(key) || '';
		}
		if (typeof data === 'string') {
			return new URLSearchParams(data).get(key) || '';
		}
		return data && data[key] ? data[key] : '';
	}

	function newRequestId() {
		if (window.crypto && typeof window.crypto.randomUUID === 'function') {
			return window.crypto.randomUUID();
		}
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (character) {
			var random = Math.random() * 16 | 0;
			var value = character === 'x' ? random : (random & 0x3 | 0x8);
			return value.toString(16);
		});
	}

	function readNavigation() {
		try {
			var history = JSON.parse(window.sessionStorage.getItem(navigationKey) || '[]');
			return Array.isArray(history) ? history : [];
		} catch (_error) {
			return [];
		}
	}

	function recordNavigation() {
		var history = readNavigation();
		var current = String(window.location.href);
		var previous = document.referrer ? String(document.referrer) : '';
		if (previous && (!history.length || history[history.length - 1].url !== previous)) {
			history.push({ url: previous, observed_at: new Date().toISOString(), kind: 'document_referrer' });
		}
		if (!history.length || history[history.length - 1].url !== current) {
			history.push({ url: current, observed_at: new Date().toISOString(), kind: 'page' });
		}
		history = history.slice(-15);
		try {
			window.sessionStorage.setItem(navigationKey, JSON.stringify(history));
		} catch (_error) {}
		return history;
	}

	function previousUrl() {
		if (document.referrer) {
			return String(document.referrer);
		}
		var history = readNavigation();
		var current = String(window.location.href);
		for (var index = history.length - 1; index >= 0; index -= 1) {
			if (history[index] && history[index].url && history[index].url !== current) {
				return String(history[index].url);
			}
		}
		return '';
	}


	// Per-tab attribution only. This does not create a persistent visitor identity.
	function entryContext() {
		var key = 'tfsc_form_bridge_entry_v1';
		var context = null;
		try { context = JSON.parse(window.sessionStorage.getItem(key) || 'null'); } catch (_error) {}
		if (!context || context.version !== 1) {
			var query = new URLSearchParams(window.location.search || '');
			context = {
				version: 1,
				entry_page_url: String(window.location.href),
				entry_referrer: document.referrer ? String(document.referrer) : '',
				entry_at: new Date().toISOString()
			};
			['source', 'medium', 'campaign', 'content', 'term'].forEach(function (name) {
				context['entry_utm_' + name] = String(query.get('utm_' + name) || '').slice(0, 200);
			});
		}
		var currentQuery = new URLSearchParams(window.location.search || '');
		if (currentQuery.has('tfsc_test') || currentQuery.has('gtm_latency')) {
			context.traffic_class = 'internal_test';
		}
		try { window.sessionStorage.setItem(key, JSON.stringify(context)); } catch (_error) {}
		return context;
	}

	function clientContext() {
		var connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection || {};
		var userAgentData = navigator.userAgentData && typeof navigator.userAgentData.toJSON === 'function'
			? navigator.userAgentData.toJSON()
			: null;
		var plugins = [];
		try {
			plugins = Array.prototype.map.call(navigator.plugins || [], function (plugin) {
				return { name: plugin.name, filename: plugin.filename, description: plugin.description };
			});
		} catch (_error) {}
		return {
			captured_at: new Date().toISOString(),
			page_url: String(window.location.href),
			document_referrer: document.referrer ? String(document.referrer) : '',
			user_agent: navigator.userAgent || '',
			user_agent_data: userAgentData,
			platform: navigator.platform || '',
			vendor: navigator.vendor || '',
			language: navigator.language || '',
			languages: navigator.languages || [],
			timezone: window.Intl && Intl.DateTimeFormat ? Intl.DateTimeFormat().resolvedOptions().timeZone : '',
			timezone_offset_minutes: new Date().getTimezoneOffset(),
			screen: {
				width: window.screen ? window.screen.width : null,
				height: window.screen ? window.screen.height : null,
				available_width: window.screen ? window.screen.availWidth : null,
				available_height: window.screen ? window.screen.availHeight : null,
				color_depth: window.screen ? window.screen.colorDepth : null,
				pixel_depth: window.screen ? window.screen.pixelDepth : null
			},
			viewport: { width: window.innerWidth, height: window.innerHeight },
			device_pixel_ratio: window.devicePixelRatio || 1,
			touch_points: navigator.maxTouchPoints || 0,
			cookies_enabled: navigator.cookieEnabled,
			online: navigator.onLine,
			do_not_track: navigator.doNotTrack || '',
			connection: {
				effective_type: connection.effectiveType || '',
				downlink: connection.downlink || null,
				rtt: connection.rtt || null,
				save_data: connection.saveData || false
			},
			browser_plugins: plugins
		};
	}

	function setHidden(form, name, value) {
		var input = form.querySelector('input[type="hidden"][name="' + name + '"]');
		if (!input) {
			input = document.createElement('input');
			input.type = 'hidden';
			input.name = name;
			form.appendChild(input);
		}
		input.value = value;
	}

	function enrich(form) {
		var requestId = newRequestId();
		setHidden(form, 'tfsc_diagnostic_request_id', requestId);
		setHidden(form, 'tfsc_diagnostic_page_url', String(window.location.href));
		setHidden(form, 'tfsc_diagnostic_previous_url', previousUrl());
		setHidden(form, 'tfsc_entry_context', JSON.stringify(entryContext()));
		setHidden(form, 'tfsc_diagnostic_navigation', JSON.stringify(recordNavigation()));
		setHidden(form, 'tfsc_diagnostic_client', JSON.stringify(clientContext()));
		return requestId;
	}

	document.addEventListener('submit', function (event) {
		var form = event.target;
		if (form && form.matches && form.matches('form.elementor-form')) {
			enrich(form);
		}
	}, true);

	recordNavigation();
	entryContext();

	$(document).ajaxError(function (_event, xhr, settings, thrownError) {
		var config = window.TFSCFormBridgeDiagnostics || {};
		var action = field(settings && settings.data, 'action');
		if (action !== 'elementor_pro_forms_send_form' || !config.ajaxUrl || !config.nonce) {
			return;
		}

		var payload = new URLSearchParams();
		payload.set('action', 'tfsc_form_bridge_client_failure');
		payload.set('nonce', config.nonce);
		payload.set('post_id', field(settings.data, 'post_id'));
		payload.set('form_id', field(settings.data, 'form_id'));
		payload.set('request_uuid', field(settings.data, 'tfsc_diagnostic_request_id'));
		payload.set('page_url', field(settings.data, 'tfsc_diagnostic_page_url') || String(window.location.href));
		payload.set('previous_url', field(settings.data, 'tfsc_diagnostic_previous_url') || previousUrl());
		payload.set('http_status', xhr && xhr.status ? String(xhr.status) : '0');
		payload.set('status_text', xhr && xhr.statusText ? String(xhr.statusText) : '');
		payload.set('thrown_error', thrownError ? String(thrownError) : '');
		payload.set('response_text', xhr && xhr.responseText ? String(xhr.responseText).slice(0, 262144) : '');
		payload.set('client', field(settings.data, 'tfsc_diagnostic_client') || JSON.stringify(clientContext()));
		payload.set('navigation', field(settings.data, 'tfsc_diagnostic_navigation') || JSON.stringify(recordNavigation()));

		if (navigator.sendBeacon) {
			navigator.sendBeacon(config.ajaxUrl, payload);
			return;
		}
		fetch(config.ajaxUrl, {
			method: 'POST',
			body: payload,
			credentials: 'same-origin',
			keepalive: true
		}).catch(function () {});
	});
})(jQuery);
