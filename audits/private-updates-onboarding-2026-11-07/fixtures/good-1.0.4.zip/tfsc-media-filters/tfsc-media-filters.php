<?php
/**
 * Plugin Name: TFSC Mediafilters
 * Version: 1.0.4
 * Requires at least: 6.5
 * Requires PHP: 8.1
 */
defined('ABSPATH') || exit;
