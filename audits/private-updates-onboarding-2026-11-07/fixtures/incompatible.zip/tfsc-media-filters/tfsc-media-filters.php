<?php
/**
 * Plugin Name: TFSC Mediafilters
 * Version: 2.0.0
 * Requires at least: 6.5
 * Requires PHP: 99.0
 */
defined('ABSPATH') || exit;
